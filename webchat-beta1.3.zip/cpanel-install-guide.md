# 🚀 راهنمای نصب روی cPanel

این راهنما مخصوص نصب وب‌چت روی هاست‌های cPanel است.

## مرحله 1: آپلود فایل‌ها

1. وارد cPanel شوید
2. به File Manager بروید
3. به پوشه `public_html` بروید
4. تمام فایل‌های پروژه را آپلود کنید
5. فایل‌های zip را extract کنید

## مرحله 2: ساخت دیتابیس

1. در cPanel به بخش "MySQL Databases" بروید
2. یک دیتابیس جدید بسازید (مثل: `username_webchat`)
3. یک کاربر دیتابیس بسازید
4. کاربر را به دیتابیس اضافه کنید با تمام مجوزها

## مرحله 3: تنظیم مجوزات

فایل‌های زیر باید مجوز 644 داشته باشند:
- تمام فایل‌های .php
- تمام فایل‌های .css و .js
- فایل .htaccess

پوشه‌های زیر باید مجوز 755 داشته باشند:
- config/
- api/
- assets/

## مرحله 4: اجرای نصب

1. سایت خود را در مرورگر باز کنید
2. به صورت خودکار به install.php منتقل می‌شوید
3. اطلاعات دیتابیس را وارد کنید:
   - Host: معمولاً `localhost`
   - Database Name: نام دیتابیسی که ساختید
   - Username: نام کاربری دیتابیس
   - Password: رمز عبور دیتابیس
   - Port: معمولاً `3306`

## نکات مهم برای cPanel:

### تنظیمات PHP
در cPanel > Select PHP Version:
- نسخه PHP: 7.4 یا بالاتر
- Extensions فعال: pdo, pdo_mysql, json, session

### SSL Certificate
برای تماس صوتی/تصویری:
- SSL رایگان Let's Encrypt را فعال کنید
- یا از Cloudflare استفاده کنید

### محدودیت‌های منابع
اگر هاست محدودیت دارد:
- `max_execution_time` را به 300 تنظیم کنید
- `memory_limit` را به 256M تنظیم کنید

### Cron Jobs (اختیاری)
برای پاک‌سازی خودکار:
```bash
# هر روز ساعت 2 شب - پاک کردن پیام‌های قدیمی (بیش از 30 روز)
0 2 * * * /usr/bin/php /home/username/public_html/cleanup.php
```

## عیب‌یابی مشکلات رایج:

### خطای 500
- مجوزات فایل‌ها را بررسی کنید
- فایل .htaccess را موقتاً تغییر نام دهید

### خطای اتصال دیتابیس
- نام دیتابیس باید شامل prefix کاربری باشد
- مثال: `username_webchat`

### مشکل در نمایش فونت‌ها
- مطمئن شوید CDN فونت‌ها در دسترس است
- یا فونت‌ها را local آپلود کنید

## بهینه‌سازی برای cPanel:

### کش کردن
در .htaccess اضافه کنید:
```apache
<IfModule mod_expires.c>
    ExpiresActive On
    ExpiresByType text/css "access plus 1 month"
    ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

### فشرده‌سازی
```apache
<IfModule mod_deflate.c>
    AddOutputFilterByType DEFLATE text/css
    AddOutputFilterByType DEFLATE application/javascript
</IfModule>
```

## امنیت:

1. فایل `test.php` را پس از تست حذف کنید
2. مجوزات `config/db.php` را به 600 تنظیم کنید
3. از رمزهای قوی استفاده کنید
4. به صورت منظم backup بگیرید

## پشتیبانی:

اگر مشکلی داشتید:
1. فایل `test.php` را اجرا کنید
2. لاگ‌های خطای cPanel را بررسی کنید
3. مجوزات و تنظیمات PHP را چک کنید