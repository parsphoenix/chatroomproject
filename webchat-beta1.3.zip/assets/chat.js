/**
 * JavaScript پیشرفته برای مدیریت چت
 */

class ChatManager {
    constructor(targetUserId, currentUserId, targetUsername, enableNotifications = true) {
        this.targetUserId = targetUserId;
        this.currentUserId = currentUserId;
        this.targetUsername = targetUsername;
        this.enableNotifications = enableNotifications;
        this.lastMessageId = 0;
        this.isLoading = false;
        this.isSending = false;
        this.isSelectMode = false;
        this.selectedMessages = new Set();
        this.notificationAudio = new Audio('assets/notification.mp3'); // Sound file needed
        this.pageSize = 30;
        this.oldestMessageId = 0;
        this.newestMessageId = 0;
        this.latestMessageId = 0;
        this.isViewingLatest = true;
        this.hasOlderMessages = true;
        this.hasNewerMessages = false;
        this.scrollThreshold = 80;

        this.init();
    }

    init() {
        console.log('ChatManager initialized for user:', this.targetUsername);

        // بارگذاری پیام‌های اولیه
        this.loadMessages();

        // شروع polling برای پیام‌های جدید
        this.startPolling();

        // آپدیت فعالیت کاربر
        this.startActivityUpdate();

        // چک وضعیت کاربر مقصد
        this.startStatusCheck();

        // Event listeners
        this.setupEventListeners();
        this.setupScrollPagination();

        // چک دسترسی به دوربین/میکروفون
        this.checkDeviceAccess();

        // مدیریت خطاهای global
        this.setupErrorHandling();

        // چک وضعیت بلاک
        this.checkIfBlocked(this.targetUsername);
    }

    // مدیریت خطاهای global
    setupErrorHandling() {
        window.addEventListener('error', (event) => {
            console.error('JavaScript Error:', event.error);
            this.showNotification('خطای غیرمنتظره رخ داد', 'error');
        });

        window.addEventListener('unhandledrejection', (event) => {
            console.error('Unhandled Promise Rejection:', event.reason);
            this.showNotification('خطا در اتصال به سرور', 'error');
        });
    }

    setupEventListeners() {
        // Enter برای ارسال پیام
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }

        // دکمه ارسال
        const sendBtn = document.querySelector('.send-btn');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => this.sendMessage());
        }

        // آپلود فایل
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => this.handleFileUpload(e));
        }
    }

    // چک دسترسی به دوربین و میکروفون
    async checkDeviceAccess() {
        try {
            const devices = await navigator.mediaDevices.enumerateDevices();
            const hasCamera = devices.some(device => device.kind === 'videoinput');
            const hasMicrophone = devices.some(device => device.kind === 'audioinput');

            const videoBtn = document.getElementById('videoCallBtn');
            const audioBtn = document.getElementById('audioCallBtn');

            if (!hasCamera && videoBtn) {
                videoBtn.title = 'دوربین یافت نشد - فقط می‌توانید تصویر دریافت کنید';
                videoBtn.style.opacity = '0.7';
            }

            if (!hasMicrophone && audioBtn) {
                audioBtn.title = 'میکروفون یافت نشد - فقط می‌توانید صدا دریافت کنید';
                audioBtn.style.opacity = '0.7';
            }

        } catch (error) {
            console.error('خطا در چک کردن دستگاه‌ها:', error);
        }
    }

    // بارگذاری پیام‌ها
    async loadMessages(options = {}) {
        if (this.isLoading) return;

        this.isLoading = true;
        const previousLastMessageId = this.lastMessageId;
        console.log('Loading messages, lastMessageId:', this.lastMessageId);

        try {
            const beforeMessageId = options.beforeMessageId || 0;
            const afterMessageId = options.afterMessageId || 0;
            const isPagination = beforeMessageId > 0 || afterMessageId > 0;
            const bodyParts = [
                `target_user_id=${this.targetUserId}`,
                `limit=${this.pageSize}`
            ];

            if (beforeMessageId > 0) {
                bodyParts.push(`before_message_id=${beforeMessageId}`);
            } else if (afterMessageId > 0) {
                bodyParts.push(`after_message_id=${afterMessageId}`);
            } else {
                bodyParts.push(`last_message_id=${this.lastMessageId}`);
            }

            const response = await fetch('api/get_messages.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: bodyParts.join('&')
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            console.log('Messages response:', data);

            if (data.success) {
                if (data.status_updates && data.status_updates.length > 0) {
                    this.updateMessageStatuses(data.status_updates);
                }

                if (data.messages && data.messages.length > 0) {
                    const messageIds = data.messages.map(m => parseInt(m.id));
                    const maxId = Math.max(...messageIds);
                    const minId = Math.min(...messageIds);
                    this.latestMessageId = Math.max(this.latestMessageId, maxId);

                    if (isPagination) {
                        this.replaceMessages(data.messages);
                        this.oldestMessageId = minId;
                        this.newestMessageId = maxId;
                        if (beforeMessageId > 0) {
                            this.hasOlderMessages = data.messages.length === this.pageSize;
                            this.hasNewerMessages = true;
                            this.isViewingLatest = false;
                            this.scrollToTop();
                        } else if (afterMessageId > 0) {
                            const hasMoreNewer = this.newestMessageId < this.latestMessageId;
                            this.hasNewerMessages = data.messages.length === this.pageSize || hasMoreNewer;
                            this.isViewingLatest = !this.hasNewerMessages;
                            this.scrollToBottom();
                        }
                    } else if (this.isViewingLatest) {
                        this.displayMessages(data.messages);
                        this.trimMessageWindow();
                        this.oldestMessageId = this.getOldestMessageId();
                        this.newestMessageId = this.getNewestMessageId();
                        this.lastMessageId = Math.max(this.lastMessageId, maxId);
                    } else {
                        this.lastMessageId = Math.max(this.lastMessageId, maxId);
                    }

                    // چک کردن پیام جدید برای نوتیفیکیشن
                    const newMessages = data.messages.filter(m => parseInt(m.id) > previousLastMessageId && m.sender_id != this.currentUserId);
                    if (newMessages.length > 0) {
                        const lastMsg = newMessages[newMessages.length - 1];
                        let msgText = lastMsg.message;
                        if (lastMsg.type === 'file') msgText = '📎 فایل جدید';
                        else if (lastMsg.type === 'call_log') msgText = '📞 گزارش تماس';

                        this.notifyNewMessage(msgText, this.targetUsername);
                    }

                    if (!isPagination && previousLastMessageId === 0) {
                        this.oldestMessageId = minId;
                        this.newestMessageId = maxId;
                        this.latestMessageId = maxId;
                        this.hasOlderMessages = data.messages.length === this.pageSize;
                        this.isViewingLatest = true;
                    }
                } else if (this.lastMessageId === 0) {
                    // اولین بار و پیامی نیست
                    const chatMessages = document.getElementById('chatMessages');
                    chatMessages.innerHTML = '<div class="alert info">هنوز پیامی رد و بدل نشده است. اولین پیام را بفرستید!</div>';
                }
            } else {
                console.error('خطا در بارگذاری پیام‌ها:', data.message);
                if (this.lastMessageId === 0) {
                    const chatMessages = document.getElementById('chatMessages');
                    chatMessages.innerHTML = '<div class="alert error">خطا در بارگذاری پیام‌ها: ' + (data.message || 'خطای نامشخص') + '</div>';
                }
            }
        } catch (error) {
            console.error('خطا در بارگذاری پیام‌ها:', error);
            if (this.lastMessageId === 0) {
                const chatMessages = document.getElementById('chatMessages');
                chatMessages.innerHTML = '<div class="alert error">خطا در اتصال به سرور. لطفاً صفحه را رفرش کنید.</div>';
            }
        } finally {
            this.isLoading = false;
        }
    }

    // بروزرسانی وضعیت پیام‌های ارسالی (تیک‌ها)
    updateMessageStatuses(updates) {
        updates.forEach(update => {
            const messageElement = document.querySelector(`.message[data-message-id="${update.id}"]`);
            if (messageElement) {
                const statusElement = messageElement.querySelector('.message-status');
                if (statusElement) {
                    statusElement.className = `message-status status-${update.status}`;
                    // آپدیت محتوای تیک
                    if (update.status === 'sent') statusElement.textContent = '✓';
                    else if (update.status === 'delivered') statusElement.textContent = '✓✓';
                    else if (update.status === 'read') statusElement.textContent = '✓✓'; // CSS will make it blue
                }
            }
        });
    }

    // نمایش پیام‌ها
    displayMessages(messages) {
        const chatMessages = document.getElementById('chatMessages');

        if (this.lastMessageId === 0) {
            // اولین بار - پاک کردن loading
            chatMessages.innerHTML = '';
        }

        messages.forEach(message => {
            const messageDiv = this.createMessageElement(message);
            chatMessages.appendChild(messageDiv);
        });

        if (this.isSelectMode) {
            this.addMessageCheckboxes();
        }

        // اسکرول به پایین
        this.scrollToBottom();
    }

    replaceMessages(messages) {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = '';
        messages.forEach(message => {
            const messageDiv = this.createMessageElement(message);
            chatMessages.appendChild(messageDiv);
        });
        if (this.isSelectMode) {
            this.addMessageCheckboxes();
        }
    }

    // ساخت element پیام
    createMessageElement(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${message.sender_id == this.currentUserId ? 'sent' : 'received'}`;
        messageDiv.setAttribute('data-message-id', message.id);

        const messageTime = this.formatTime(message.created_at);

        // مدیریت انواع پیام (متن، فایل، لاگ تماس)
        if (message.type === 'call_log') {
            messageDiv.className = 'message message-system call-log';
            // برای سیستم مسیج‌ها، استایل خاص لازم است
            // محتوا قبلاً در سرور فرمت شده است
            messageDiv.innerHTML = `
                <div class="system-message-content">
                    <span class="system-icon">📞</span>
                    <span class="system-text">${this.escapeHtml(message.message)}</span>
                    <span class="message-time">${messageTime}</span>
                </div>
            `;
            return messageDiv;
        }

        let messageContent = this.escapeHtml(message.message);

        // چک کردن اینکه آیا پیام حاوی فایل است
        if (message.type === 'file' || messageContent.includes('📎 فایل ارسال شد:')) {
            const fileName = message.type === 'file' ? message.message : messageContent.replace('📎 فایل ارسال شد: ', '');
            messageContent = this.createFileMessage(fileName, message.id);
        }

        // وضعیت پیام (تیک‌ها) - فقط برای پیام‌های ارسالی من
        let statusHtml = '';
        if (message.sender_id == this.currentUserId) {
            let statusClass = message.status || 'sent';
            let statusIcon = '✓';
            if (statusClass === 'delivered' || statusClass === 'read') statusIcon = '✓✓';

            statusHtml = `<span class="message-status status-${statusClass}">${statusIcon}</span>`;
        }

        messageDiv.innerHTML = `
            <div class="message-content">
                ${messageContent}
                <div class="message-meta">
                    <span class="message-time">${messageTime}</span>
                    ${statusHtml}
                </div>
            </div>
        `;

        // انیمیشن ورود پیام جدید
        messageDiv.style.opacity = '0';
        messageDiv.style.transform = 'translateY(20px)';

        setTimeout(() => {
            messageDiv.style.transition = 'all 0.3s ease';
            messageDiv.style.opacity = '1';
            messageDiv.style.transform = 'translateY(0)';
        }, 10);

        return messageDiv;
    }

    // ساخت نمایش فایل
    createFileMessage(fileName, messageId) {
        const fileExtension = fileName.split('.').pop().toLowerCase();
        let fileIcon = '📄';

        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExtension)) {
            fileIcon = '🖼️';
        } else if (['pdf'].includes(fileExtension)) {
            fileIcon = '📕';
        } else if (['doc', 'docx'].includes(fileExtension)) {
            fileIcon = '📘';
        } else if (['zip', 'rar'].includes(fileExtension)) {
            fileIcon = '📦';
        }

        return `
            <div class="message-file">
                <div class="file-icon">${fileIcon}</div>
                <div class="file-info">
                    <div class="file-name">${fileName}</div>
                    <div class="file-size">فایل ضمیمه</div>
                </div>
                <a href="api/download_file.php?id=${messageId}" class="file-download" target="_blank">
                    دانلود
                </a>
            </div>
        `;
    }

    // ارسال پیام
    async sendMessage() {
        if (this.isSending) return;

        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();

        if (message === '') return;

        this.isSending = true;
        console.log('Sending message:', message);

        // غیرفعال کردن input تا ارسال کامل شود
        messageInput.disabled = true;
        const sendBtn = document.querySelector('.send-btn');
        if (!sendBtn) return; // Guard clause

        const originalText = sendBtn.textContent;
        sendBtn.textContent = 'در حال ارسال...';
        sendBtn.disabled = true;

        try {
            const response = await fetch('api/send_message.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `target_user_id=${this.targetUserId}&message=${encodeURIComponent(message)}`
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            console.log('Send message response:', data);

            if (data.success) {
                messageInput.value = '';
                // بارگذاری مجدد برای نمایش پیام ارسالی
                setTimeout(() => this.loadMessages(), 500);
            } else {
                this.showNotification('خطا در ارسال پیام: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('خطا در ارسال پیام:', error);
            this.showNotification('خطا در ارسال پیام', 'error');
        } finally {
            // فعال کردن مجدد input
            this.isSending = false;
            messageInput.disabled = false;
            messageInput.focus();
            sendBtn.textContent = originalText;
            sendBtn.disabled = false;
        }
    }

    // مدیریت آپلود فایل
    async handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        // بررسی حجم فایل
        if (file.size > 5 * 1024 * 1024) {
            this.showNotification('حجم فایل نباید بیش از 5 مگابایت باشد', 'error');
            event.target.value = '';
            return;
        }

        const formData = new FormData();
        formData.append('file', file);
        formData.append('target_user_id', this.targetUserId);

        try {
            this.showNotification('در حال آپلود فایل...', 'info');

            const response = await fetch('api/upload_file.php', {
                method: 'POST',
                body: formData
            });

            const data = await response.json();

            if (data.success) {
                this.showNotification('فایل با موفقیت ارسال شد', 'success');
                setTimeout(() => this.loadMessages(), 500);
            } else {
                this.showNotification('خطا در آپلود: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('خطا در آپلود فایل:', error);
            this.showNotification('خطا در آپلود فایل', 'error');
        } finally {
            event.target.value = '';
        }
    }

    // تغییر حالت انتخاب پیام‌ها
    toggleSelectMode() {
        this.isSelectMode = !this.isSelectMode;
        const btn = document.getElementById('selectModeBtn');
        const bulkActions = document.getElementById('bulkActions');

        if (this.isSelectMode) {
            btn.textContent = '❌ لغو انتخاب';
            btn.style.background = '#e53e3e';
            this.addMessageCheckboxes();
        } else {
            btn.textContent = '✅ انتخاب پیام‌ها';
            btn.style.background = '';
            this.removeMessageCheckboxes();
            bulkActions.classList.remove('show');
            this.selectedMessages.clear();
        }
    }

    // اضافه کردن چک باکس به پیام‌ها
    addMessageCheckboxes() {
        const messages = document.querySelectorAll('.message.sent');
        messages.forEach(message => {
            if (!message.querySelector('.message-checkbox')) {
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'message-checkbox';
                checkbox.addEventListener('change', (e) => this.handleMessageSelect(e, message));
                message.style.position = 'relative';
                message.appendChild(checkbox);
            }
        });
    }

    // حذف چک باکس‌ها
    removeMessageCheckboxes() {
        const checkboxes = document.querySelectorAll('.message-checkbox');
        checkboxes.forEach(checkbox => checkbox.remove());

        const messages = document.querySelectorAll('.message');
        messages.forEach(message => {
            message.classList.remove('selected');
            message.style.position = '';
        });
    }

    // مدیریت انتخاب پیام
    handleMessageSelect(event, messageElement) {
        if (!messageElement.classList.contains('sent')) {
            event.target.checked = false;
            return;
        }
        const messageId = messageElement.getAttribute('data-message-id');

        if (event.target.checked) {
            this.selectedMessages.add(messageId);
            messageElement.classList.add('selected');
        } else {
            this.selectedMessages.delete(messageId);
            messageElement.classList.remove('selected');
        }

        this.updateBulkActions();
    }

    // بروزرسانی نوار عملیات گروهی
    updateBulkActions() {
        const bulkActions = document.getElementById('bulkActions');
        const selectedCount = document.getElementById('selectedCount');

        if (this.selectedMessages.size > 0) {
            bulkActions.classList.add('show');
            selectedCount.textContent = `${this.selectedMessages.size} پیام انتخاب شده`;
        } else {
            bulkActions.classList.remove('show');
        }
    }

    // حذف پیام‌های انتخاب شده
    async deleteSelectedMessages(deleteType) {
        if (this.selectedMessages.size === 0) {
            this.showNotification('هیچ پیامی انتخاب نشده است', 'warning');
            return;
        }

        const confirmMessage = deleteType === 'for_both'
            ? 'آیا مطمئن هستید که می‌خواهید این پیام‌ها را برای هر دو طرف حذف کنید؟'
            : 'آیا مطمئن هستید که می‌خواهید این پیام‌ها را حذف کنید؟';

        if (!confirm(confirmMessage)) return;

        try {
            const messageIdsArray = Array.from(this.selectedMessages);
            console.log('Deleting messages:', messageIdsArray);

            const formData = new URLSearchParams();

            // ارسال message_ids به صورت آرایه
            messageIdsArray.forEach(id => {
                formData.append('message_ids[]', id);
            });
            formData.append('delete_type', deleteType);
            formData.append('target_user_id', this.targetUserId);

            this.showNotification('در حال حذف پیام‌ها...', 'info');

            const response = await fetch('api/delete_messages.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });

            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            console.log('Delete response:', data);

            if (data.success) {
                this.showNotification(`${data.deleted_count || messageIdsArray.length} پیام با موفقیت حذف شد`, 'success');
                this.toggleSelectMode();
                this.lastMessageId = 0; // ریست برای بارگذاری مجدد کامل
                setTimeout(() => this.loadMessages(), 500);
            } else {
                this.showNotification('خطا در حذف: ' + (data.message || 'خطای نامشخص'), 'error');
            }
        } catch (error) {
            console.error('خطا در حذف پیام‌ها:', error);
            this.showNotification('خطا در حذف پیام‌ها: ' + error.message, 'error');
        }
    }

    // لغو انتخاب
    cancelSelection() {
        this.toggleSelectMode();
    }

    setupScrollPagination() {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        chatMessages.addEventListener('scroll', () => {
            if (this.isLoading) return;

            const atTop = chatMessages.scrollTop <= this.scrollThreshold;
            const atBottom = (chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight) <= this.scrollThreshold;

            if (atTop && this.hasOlderMessages && this.oldestMessageId > 0) {
                this.loadMessages({ beforeMessageId: this.oldestMessageId });
            } else if (atBottom && !this.isViewingLatest && this.newestMessageId > 0) {
                this.loadMessages({ afterMessageId: this.newestMessageId });
            }
        });
    }

    trimMessageWindow() {
        const chatMessages = document.getElementById('chatMessages');
        const messages = Array.from(chatMessages.querySelectorAll('.message'));
        if (messages.length <= this.pageSize) return;
        const excess = messages.length - this.pageSize;
        for (let i = 0; i < excess; i++) {
            messages[i].remove();
        }
    }

    getOldestMessageId() {
        const messages = document.querySelectorAll('.message');
        if (messages.length === 0) return 0;
        const first = messages[0];
        return parseInt(first.getAttribute('data-message-id')) || 0;
    }

    getNewestMessageId() {
        const messages = document.querySelectorAll('.message');
        if (messages.length === 0) return 0;
        const last = messages[messages.length - 1];
        return parseInt(last.getAttribute('data-message-id')) || 0;
    }

    scrollToTop() {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            chatMessages.scrollTop = 0;
        }
    }

    // بلاک/آنبلاک کردن کاربر
    async blockUser(username) {
        // ابتدا چک کنیم که آیا کاربر بلاک شده یا نه
        const isBlocked = await this.checkIfBlocked(username);

        if (isBlocked) {
            if (!confirm('آیا مطمئن هستید که می‌خواهید این کاربر را آنبلاک کنید؟')) return;
            await this.unblockUser(username);
        } else {
            if (!confirm('آیا مطمئن هستید که می‌خواهید این کاربر را بلاک کنید؟')) return;
            await this.performBlock(username);
        }
    }

    // چک کردن وضعیت بلاک
    async checkIfBlocked(username) {
        try {
            const response = await fetch('api/check_block_status.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `username=${encodeURIComponent(username)}`
            });

            const data = await response.json();

            if (data.success) {
                // بروزرسانی دکمه
                const blockBtn = document.getElementById('blockBtn');
                if (blockBtn) {
                    if (data.is_blocked) {
                        blockBtn.innerHTML = '🔓 آنبلاک';
                        blockBtn.title = 'آنبلاک کردن کاربر';
                    } else {
                        blockBtn.innerHTML = '🚫 بلاک';
                        blockBtn.title = 'بلاک کردن کاربر';
                    }
                }
                return data.is_blocked;
            }
            return false;
        } catch (error) {
            console.error('خطا در چک وضعیت بلاک:', error);
            return false;
        }
    }

    // بلاک کردن
    async performBlock(username) {
        try {
            const response = await fetch('api/block_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `username=${encodeURIComponent(username)}`
            });

            const data = await response.json();

            if (data.success) {
                this.showNotification('کاربر با موفقیت بلاک شد', 'success');
                await this.checkIfBlocked(username); // بروزرسانی دکمه
            } else {
                this.showNotification('خطا: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('خطا در بلاک کردن:', error);
            this.showNotification('خطا در بلاک کردن کاربر', 'error');
        }
    }

    // آنبلاک کردن
    async unblockUser(username) {
        try {
            const response = await fetch('api/unblock_user.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `username=${encodeURIComponent(username)}`
            });

            const data = await response.json();

            if (data.success) {
                this.showNotification('کاربر با موفقیت آنبلاک شد', 'success');
                await this.checkIfBlocked(username); // بروزرسانی دکمه
            } else {
                this.showNotification('خطا: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('خطا در آنبلاک کردن:', error);
            this.showNotification('خطا در آنبلاک کردن کاربر', 'error');
        }
    }

    // شروع polling برای پیام‌های جدید
    startPolling() {
        setInterval(() => {
            this.loadMessages();
        }, 2000); // هر 2 ثانیه
    }

    // شروع آپدیت فعالیت
    startActivityUpdate() {
        // آپدیت فوری
        this.updateActivity();

        // آپدیت هر 30 ثانیه
        setInterval(() => {
            this.updateActivity();
        }, 30000);
    }

    // آپدیت فعالیت کاربر
    async updateActivity() {
        try {
            await fetch('api/update_activity.php', {
                method: 'POST'
            });
        } catch (error) {
            console.error('خطا در آپدیت فعالیت:', error);
        }
    }

    // شروع چک وضعیت کاربر مقصد
    startStatusCheck() {
        setInterval(() => {
            this.checkUserStatus();
        }, 10000); // هر 10 ثانیه
    }

    // چک وضعیت کاربر مقصد
    async checkUserStatus() {
        try {
            const response = await fetch('api/search_users.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `query=${encodeURIComponent(this.targetUsername)}`
            });

            const data = await response.json();

            if (data.success && data.users.length > 0) {
                const user = data.users.find(u => u.username === this.targetUsername);
                if (user) {
                    this.updateUserStatus(user.is_online);
                }
            }
        } catch (error) {
            console.error('خطا در چک وضعیت:', error);
        }
    }

    // آپدیت نمایش وضعیت کاربر
    updateUserStatus(isOnline) {
        const statusElement = document.getElementById('userStatus');
        const statusText = document.getElementById('statusText');
        const indicator = statusElement?.querySelector('span');

        if (statusElement && statusText && indicator) {
            if (isOnline) {
                statusElement.className = 'user-status status-online';
                statusText.textContent = 'آنلاین';
                indicator.className = 'online-indicator';
            } else {
                statusElement.className = 'user-status status-offline';
                statusText.textContent = 'آفلاین';
                indicator.className = 'offline-indicator';
            }
        }
    }

    // اسکرول به پایین
    scrollToBottom() {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }

    // فرمت کردن زمان
    formatTime(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;

        // اگر کمتر از 24 ساعت باشد، فقط ساعت نمایش بده
        if (diff < 24 * 60 * 60 * 1000) {
            return date.toLocaleTimeString('fa-IR', {
                hour: '2-digit',
                minute: '2-digit'
            });
        } else {
            // اگر بیشتر از 24 ساعت باشد، تاریخ و ساعت
            return date.toLocaleString('fa-IR', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            });
        }
    }

    // Escape HTML
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // نمایش نوتیفیکیشن
    showNotification(message, type = 'info') {
        const container = document.getElementById('notificationContainer');
        if (!container) return;

        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div>${message}</div>
            <button onclick="this.parentElement.remove()" style="background: none; border: none; float: left; cursor: pointer;">×</button>
        `;

        container.appendChild(notification);

        // نمایش انیمیشن
        setTimeout(() => notification.classList.add('show'), 100);

        // حذف خودکار بعد از 5 ثانیه
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }

    // پخش صدای نوتیفیکیشن و نمایش اعلان دسکتاپ
    notifyNewMessage(message, sender) {
        if (!this.enableNotifications) return;

        // پخش صدا (Beep)
        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                const ctx = new AudioContext();
                const oscillator = ctx.createOscillator();
                const gain = ctx.createGain();

                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(800, ctx.currentTime);
                gain.gain.setValueAtTime(0.1, ctx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.5);

                oscillator.connect(gain);
                gain.connect(ctx.destination);

                oscillator.start();
                oscillator.stop(ctx.currentTime + 0.5);
            }
        } catch (e) {
            console.error('Error playing notification sound:', e);
        }

        // نمایش اعلان دسکتاپ
        if (document.hidden || true) {
            if ('Notification' in window && Notification.permission === 'granted') {
                new Notification(`پیام جدید از ${sender}`, {
                    body: message,
                    icon: 'assets/img/icon.png', // آیکون پیش‌فرض
                    tag: 'chat-message'
                });
            }
        }
    }
}

// متغیر global برای مدیریت چت
let chatManager = null;

// تابع مقداردهی اولیه چت
function initChat(targetUserId, currentUserId, targetUsername, enableNotifications = true) {
    console.log('Initializing chat with:', { targetUserId, currentUserId, targetUsername, enableNotifications });
    chatManager = new ChatManager(targetUserId, currentUserId, targetUsername, enableNotifications);
}

// توابع کمکی برای استفاده در HTML
function sendMessage() {
    if (chatManager) {
        chatManager.sendMessage();
    }
}

function toggleSelectMode() {
    if (chatManager) {
        chatManager.toggleSelectMode();
    }
}

function deleteSelectedMessages(deleteType) {
    if (chatManager) {
        chatManager.deleteSelectedMessages(deleteType);
    }
}

function cancelSelection() {
    if (chatManager) {
        chatManager.cancelSelection();
    }
}

function blockUser(username) {
    if (chatManager) {
        chatManager.blockUser(username);
    }
}

// نمایش notification برای پیام جدید
function showNotification(message, sender) {
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`پیام جدید از ${sender}`, {
            body: message,
            icon: '/favicon.ico'
        });
    }
}

// درخواست مجوز notification
function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}
