/**
 * JavaScript برای مدیریت چت گروهی
 */

class GroupChatManager {
    constructor(groupId, currentUserId, groupName) {
        this.groupId = groupId;
        this.currentUserId = currentUserId;
        this.groupName = groupName;
        this.lastMessageId = 0;
        this.isLoading = false;
        this.isSending = false;
        this.isSelectMode = false;
        this.selectedMessages = new Set();
        this.pageSize = 30;
        this.oldestMessageId = 0;
        this.newestMessageId = 0;
        this.latestMessageId = 0;
        this.isViewingLatest = true;
        this.hasOlderMessages = true;
        this.hasNewerMessages = false;
        this.scrollThreshold = 80;
        
        this.init();
    }
    
    init() {
        console.log('GroupChatManager initialized for group:', this.groupName);
        
        // بارگذاری پیام‌های اولیه
        this.loadMessages();
        
        // شروع polling برای پیام‌های جدید
        this.startPolling();
        
        // آپدیت فعالیت کاربر
        this.startActivityUpdate();
        
        // Event listeners
        this.setupEventListeners();
        this.setupScrollPagination();
    }
    
    setupEventListeners() {
        // Enter برای ارسال پیام
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            messageInput.addEventListener('keypress', (e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    this.sendMessage();
                }
            });
        }
        
        // دکمه ارسال
        const sendBtn = document.querySelector('.send-btn');
        if (sendBtn) {
            sendBtn.addEventListener('click', () => this.sendMessage());
        }
        
        // آپلود فایل
        const fileInput = document.getElementById('fileInput');
        if (fileInput) {
            fileInput.addEventListener('change', (e) => this.handleFileUpload(e));
        }
    }
    
    // بارگذاری پیام‌ها
    async loadMessages(options = {}) {
        if (this.isLoading) return;
        
        this.isLoading = true;
        const previousLastMessageId = this.lastMessageId;
        console.log('Loading group messages, lastMessageId:', this.lastMessageId);
        
        try {
            const beforeMessageId = options.beforeMessageId || 0;
            const afterMessageId = options.afterMessageId || 0;
            const isPagination = beforeMessageId > 0 || afterMessageId > 0;
            const bodyParts = [
                `group_id=${this.groupId}`,
                `limit=${this.pageSize}`
            ];

            if (beforeMessageId > 0) {
                bodyParts.push(`before_message_id=${beforeMessageId}`);
            } else if (afterMessageId > 0) {
                bodyParts.push(`after_message_id=${afterMessageId}`);
            } else {
                bodyParts.push(`last_message_id=${this.lastMessageId}`);
            }

            const response = await fetch('api/get_group_messages.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: bodyParts.join('&')
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('Group messages response:', data);
            
            if (data.success) {
                if (data.messages && data.messages.length > 0) {
                    const messageIds = data.messages.map(m => parseInt(m.id));
                    const maxId = Math.max(...messageIds);
                    const minId = Math.min(...messageIds);
                    this.latestMessageId = Math.max(this.latestMessageId, maxId);

                    if (isPagination) {
                        this.replaceMessages(data.messages);
                        this.oldestMessageId = minId;
                        this.newestMessageId = maxId;
                        if (beforeMessageId > 0) {
                            this.hasOlderMessages = data.messages.length === this.pageSize;
                            this.hasNewerMessages = true;
                            this.isViewingLatest = false;
                            this.scrollToTop();
                        } else if (afterMessageId > 0) {
                            const hasMoreNewer = this.newestMessageId < this.latestMessageId;
                            this.hasNewerMessages = data.messages.length === this.pageSize || hasMoreNewer;
                            this.isViewingLatest = !this.hasNewerMessages;
                            this.scrollToBottom();
                        }
                    } else if (this.isViewingLatest) {
                        this.displayMessages(data.messages);
                        this.trimMessageWindow();
                        this.oldestMessageId = this.getOldestMessageId();
                        this.newestMessageId = this.getNewestMessageId();
                        this.lastMessageId = Math.max(this.lastMessageId, maxId);
                    } else {
                        this.lastMessageId = Math.max(this.lastMessageId, maxId);
                    }

                    if (!isPagination && previousLastMessageId === 0) {
                        this.oldestMessageId = minId;
                        this.newestMessageId = maxId;
                        this.latestMessageId = maxId;
                        this.hasOlderMessages = data.messages.length === this.pageSize;
                        this.isViewingLatest = true;
                    }
                } else if (this.lastMessageId === 0) {
                    // اولین بار و پیامی نیست
                    const chatMessages = document.getElementById('chatMessages');
                    chatMessages.innerHTML = '<div class="alert info">هنوز پیامی در گروه ارسال نشده است. اولین پیام را بفرستید!</div>';
                }
            } else {
                console.error('خطا در بارگذاری پیام‌های گروهی:', data.message);
                if (this.lastMessageId === 0) {
                    const chatMessages = document.getElementById('chatMessages');
                    chatMessages.innerHTML = '<div class="alert error">خطا در بارگذاری پیام‌ها: ' + (data.message || 'خطای نامشخص') + '</div>';
                }
            }
        } catch (error) {
            console.error('خطا در بارگذاری پیام‌های گروهی:', error);
            if (this.lastMessageId === 0) {
                const chatMessages = document.getElementById('chatMessages');
                chatMessages.innerHTML = '<div class="alert error">خطا در اتصال به سرور. لطفاً صفحه را رفرش کنید.</div>';
            }
        } finally {
            this.isLoading = false;
        }
    }
    
    // نمایش پیام‌ها
    displayMessages(messages) {
        const chatMessages = document.getElementById('chatMessages');
        
        if (this.lastMessageId === 0) {
            // اولین بار - پاک کردن loading
            chatMessages.innerHTML = '';
        }
        
        messages.forEach(message => {
            const messageDiv = this.createMessageElement(message);
            chatMessages.appendChild(messageDiv);
        });
        
        if (this.isSelectMode) {
            this.addMessageCheckboxes();
        }

        // اسکرول به پایین
        this.scrollToBottom();
    }

    replaceMessages(messages) {
        const chatMessages = document.getElementById('chatMessages');
        chatMessages.innerHTML = '';
        messages.forEach(message => {
            const messageDiv = this.createMessageElement(message);
            chatMessages.appendChild(messageDiv);
        });
        if (this.isSelectMode) {
            this.addMessageCheckboxes();
        }
    }
    
    // ساخت element پیام
    createMessageElement(message) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${message.sender_id == this.currentUserId ? 'sent' : 'received'}`;
        messageDiv.setAttribute('data-message-id', message.id);
        
        const messageTime = this.formatTime(message.created_at);
        let messageContent = this.escapeHtml(message.message);
        
        // چک کردن اینکه آیا پیام حاوی فایل است
        if (messageContent.includes('📎 فایل ارسال شد:')) {
            const fileName = messageContent.replace('📎 فایل ارسال شد: ', '');
            messageContent = this.createFileMessage(fileName, message.id);
        }
        
        messageDiv.innerHTML = `
            <div class="message-content">
                <div class="message-sender">${this.escapeHtml(message.sender_name)}</div>
                ${messageContent}
                <div class="message-time">${messageTime}</div>
            </div>
        `;
        
        // انیمیشن ورود پیام جدید
        messageDiv.style.opacity = '0';
        messageDiv.style.transform = 'translateY(20px)';
        
        setTimeout(() => {
            messageDiv.style.transition = 'all 0.3s ease';
            messageDiv.style.opacity = '1';
            messageDiv.style.transform = 'translateY(0)';
        }, 10);
        
        return messageDiv;
    }
    
    // ساخت نمایش فایل
    createFileMessage(fileName, messageId) {
        const fileExtension = fileName.split('.').pop().toLowerCase();
        let fileIcon = '📄';
        
        if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(fileExtension)) {
            fileIcon = '🖼️';
        } else if (['pdf'].includes(fileExtension)) {
            fileIcon = '📕';
        } else if (['doc', 'docx'].includes(fileExtension)) {
            fileIcon = '📘';
        } else if (['zip', 'rar'].includes(fileExtension)) {
            fileIcon = '📦';
        }
        
        return `
            <div class="message-file">
                <div class="file-icon">${fileIcon}</div>
                <div class="file-info">
                    <div class="file-name">${fileName}</div>
                    <div class="file-size">فایل ضمیمه</div>
                </div>
                <a href="api/download_group_file.php?id=${messageId}" class="file-download" target="_blank">
                    دانلود
                </a>
            </div>
        `;
    }
    
    // ارسال پیام
    async sendMessage() {
        if (this.isSending) return;
        
        const messageInput = document.getElementById('messageInput');
        const message = messageInput.value.trim();
        
        if (message === '') return;
        
        this.isSending = true;
        console.log('Sending group message:', message);
        
        // غیرفعال کردن input تا ارسال کامل شود
        messageInput.disabled = true;
        const sendBtn = document.querySelector('.send-btn');
        if (!sendBtn) return; // Guard clause
        
        const originalText = sendBtn.textContent;
        sendBtn.textContent = 'در حال ارسال...';
        sendBtn.disabled = true;
        
        try {
            const response = await fetch('api/send_group_message.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `group_id=${this.groupId}&message=${encodeURIComponent(message)}`
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('Send group message response:', data);
            
            if (data.success) {
                messageInput.value = '';
                // بارگذاری مجدد برای نمایش پیام ارسالی
                setTimeout(() => this.loadMessages(), 500);
            } else {
                this.showNotification('خطا در ارسال پیام: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('خطا در ارسال پیام گروهی:', error);
            this.showNotification('خطا در ارسال پیام', 'error');
        } finally {
            // فعال کردن مجدد input
            this.isSending = false;
            messageInput.disabled = false;
            messageInput.focus();
            sendBtn.textContent = originalText;
            sendBtn.disabled = false;
        }
    }
    
    // مدیریت آپلود فایل
    async handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
        
        // بررسی حجم فایل
        if (file.size > 5 * 1024 * 1024) {
            this.showNotification('حجم فایل نباید بیش از 5 مگابایت باشد', 'error');
            event.target.value = '';
            return;
        }
        
        const formData = new FormData();
        formData.append('file', file);
        formData.append('group_id', this.groupId);
        
        try {
            this.showNotification('در حال آپلود فایل...', 'info');
            
            const response = await fetch('api/upload_group_file.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            
            if (data.success) {
                this.showNotification('فایل با موفقیت ارسال شد', 'success');
                setTimeout(() => this.loadMessages(), 500);
            } else {
                this.showNotification('خطا در آپلود: ' + data.message, 'error');
            }
        } catch (error) {
            console.error('خطا در آپلود فایل گروهی:', error);
            this.showNotification('خطا در آپلود فایل', 'error');
        } finally {
            event.target.value = '';
        }
    }
    
    // تغییر حالت انتخاب پیام‌ها
    toggleSelectMode() {
        this.isSelectMode = !this.isSelectMode;
        const btn = document.getElementById('selectModeBtn');
        const bulkActions = document.getElementById('bulkActions');
        
        if (this.isSelectMode) {
            btn.textContent = '❌ لغو انتخاب';
            btn.style.background = '#e53e3e';
            this.addMessageCheckboxes();
        } else {
            btn.textContent = '✅ انتخاب پیام‌ها';
            btn.style.background = '';
            this.removeMessageCheckboxes();
            bulkActions.classList.remove('show');
            this.selectedMessages.clear();
        }
    }
    
    // اضافه کردن چک باکس به پیام‌ها
    addMessageCheckboxes() {
        const messages = document.querySelectorAll('.message.sent');
        messages.forEach(message => {
            if (!message.querySelector('.message-checkbox')) {
                const checkbox = document.createElement('input');
                checkbox.type = 'checkbox';
                checkbox.className = 'message-checkbox';
                checkbox.addEventListener('change', (e) => this.handleMessageSelect(e, message));
                message.style.position = 'relative';
                message.appendChild(checkbox);
            }
        });
    }
    
    // حذف چک باکس‌ها
    removeMessageCheckboxes() {
        const checkboxes = document.querySelectorAll('.message-checkbox');
        checkboxes.forEach(checkbox => checkbox.remove());
        
        const messages = document.querySelectorAll('.message');
        messages.forEach(message => {
            message.classList.remove('selected');
            message.style.position = '';
        });
    }
    
    // مدیریت انتخاب پیام
    handleMessageSelect(event, messageElement) {
        if (!messageElement.classList.contains('sent')) {
            event.target.checked = false;
            return;
        }
        const messageId = messageElement.getAttribute('data-message-id');
        
        if (event.target.checked) {
            this.selectedMessages.add(messageId);
            messageElement.classList.add('selected');
        } else {
            this.selectedMessages.delete(messageId);
            messageElement.classList.remove('selected');
        }
        
        this.updateBulkActions();
    }
    
    // بروزرسانی نوار عملیات گروهی
    updateBulkActions() {
        const bulkActions = document.getElementById('bulkActions');
        const selectedCount = document.getElementById('selectedCount');
        
        if (this.selectedMessages.size > 0) {
            bulkActions.classList.add('show');
            selectedCount.textContent = `${this.selectedMessages.size} پیام انتخاب شده`;
        } else {
            bulkActions.classList.remove('show');
        }
    }
    
    // حذف پیام‌های انتخاب شده
    async deleteSelectedMessages(deleteType) {
        if (this.selectedMessages.size === 0) {
            this.showNotification('هیچ پیامی انتخاب نشده است', 'warning');
            return;
        }
        
        const confirmMessage = deleteType === 'for_all' 
            ? 'آیا مطمئن هستید که می‌خواهید این پیام‌ها را برای همه حذف کنید؟'
            : 'آیا مطمئن هستید که می‌خواهید این پیام‌ها را حذف کنید؟';
            
        if (!confirm(confirmMessage)) return;
        
        try {
            const messageIdsArray = Array.from(this.selectedMessages);
            console.log('Deleting group messages:', messageIdsArray);
            
            const formData = new URLSearchParams();
            
            // ارسال message_ids به صورت آرایه
            messageIdsArray.forEach(id => {
                formData.append('message_ids[]', id);
            });
            formData.append('delete_type', deleteType);
            formData.append('group_id', this.groupId);
            
            this.showNotification('در حال حذف پیام‌ها...', 'info');
            
            const response = await fetch('api/delete_group_messages.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: formData
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const data = await response.json();
            console.log('Delete group messages response:', data);
            
            if (data.success) {
                this.showNotification(`${data.deleted_count || messageIdsArray.length} پیام با موفقیت حذف شد`, 'success');
                this.toggleSelectMode();
                this.lastMessageId = 0; // ریست برای بارگذاری مجدد کامل
                setTimeout(() => this.loadMessages(), 500);
            } else {
                this.showNotification('خطا در حذف: ' + (data.message || 'خطای نامشخص'), 'error');
            }
        } catch (error) {
            console.error('خطا در حذف پیام‌های گروهی:', error);
            this.showNotification('خطا در حذف پیام‌ها: ' + error.message, 'error');
        }
    }
    
    // لغو انتخاب
    cancelSelection() {
        this.toggleSelectMode();
    }

    setupScrollPagination() {
        const chatMessages = document.getElementById('chatMessages');
        if (!chatMessages) return;

        chatMessages.addEventListener('scroll', () => {
            if (this.isLoading) return;

            const atTop = chatMessages.scrollTop <= this.scrollThreshold;
            const atBottom = (chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight) <= this.scrollThreshold;

            if (atTop && this.hasOlderMessages && this.oldestMessageId > 0) {
                this.loadMessages({ beforeMessageId: this.oldestMessageId });
            } else if (atBottom && !this.isViewingLatest && this.newestMessageId > 0) {
                this.loadMessages({ afterMessageId: this.newestMessageId });
            }
        });
    }

    trimMessageWindow() {
        const chatMessages = document.getElementById('chatMessages');
        const messages = Array.from(chatMessages.querySelectorAll('.message'));
        if (messages.length <= this.pageSize) return;
        const excess = messages.length - this.pageSize;
        for (let i = 0; i < excess; i++) {
            messages[i].remove();
        }
    }

    getOldestMessageId() {
        const messages = document.querySelectorAll('.message');
        if (messages.length === 0) return 0;
        const first = messages[0];
        return parseInt(first.getAttribute('data-message-id')) || 0;
    }

    getNewestMessageId() {
        const messages = document.querySelectorAll('.message');
        if (messages.length === 0) return 0;
        const last = messages[messages.length - 1];
        return parseInt(last.getAttribute('data-message-id')) || 0;
    }

    scrollToTop() {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            chatMessages.scrollTop = 0;
        }
    }
    
    // شروع polling برای پیام‌های جدید
    startPolling() {
        setInterval(() => {
            this.loadMessages();
        }, 3000); // هر 3 ثانیه
    }
    
    // شروع آپدیت فعالیت
    startActivityUpdate() {
        // آپدیت فوری
        this.updateActivity();
        
        // آپدیت هر 30 ثانیه
        setInterval(() => {
            this.updateActivity();
        }, 30000);
    }
    
    // آپدیت فعالیت کاربر
    async updateActivity() {
        try {
            await fetch('api/update_activity.php', {
                method: 'POST'
            });
        } catch (error) {
            console.error('خطا در آپدیت فعالیت:', error);
        }
    }
    
    // اسکرول به پایین
    scrollToBottom() {
        const chatMessages = document.getElementById('chatMessages');
        if (chatMessages) {
            chatMessages.scrollTop = chatMessages.scrollHeight;
        }
    }
    
    // فرمت کردن زمان
    formatTime(dateString) {
        const date = new Date(dateString);
        const now = new Date();
        const diff = now - date;
        
        // اگر کمتر از 24 ساعت باشد، فقط ساعت نمایش بده
        if (diff < 24 * 60 * 60 * 1000) {
            return date.toLocaleTimeString('fa-IR', {
                hour: '2-digit',
                minute: '2-digit'
            });
        } else {
            // اگر بیشتر از 24 ساعت باشد، تاریخ و ساعت
            return date.toLocaleString('fa-IR', {
                year: 'numeric',
                month: '2-digit',
                day: '2-digit',
                hour: '2-digit',
                minute: '2-digit'
            });
        }
    }
    
    // Escape HTML
    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    // نمایش نوتیفیکیشن
    showNotification(message, type = 'info') {
        const container = document.getElementById('notificationContainer');
        if (!container) return;
        
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.innerHTML = `
            <div>${message}</div>
            <button onclick="this.parentElement.remove()" style="background: none; border: none; float: left; cursor: pointer;">×</button>
        `;
        
        container.appendChild(notification);
        
        // نمایش انیمیشن
        setTimeout(() => notification.classList.add('show'), 100);
        
        // حذف خودکار بعد از 5 ثانیه
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => notification.remove(), 300);
        }, 5000);
    }
}

// متغیر global برای مدیریت چت گروهی
let groupChatManager = null;

// تابع مقداردهی اولیه چت گروهی
function initGroupChat(groupId, currentUserId, groupName) {
    console.log('Initializing group chat with:', { groupId, currentUserId, groupName });
    groupChatManager = new GroupChatManager(groupId, currentUserId, groupName);
}

// توابع کمکی برای استفاده در HTML
function sendMessage() {
    if (groupChatManager) {
        groupChatManager.sendMessage();
    }
}

function toggleSelectMode() {
    if (groupChatManager) {
        groupChatManager.toggleSelectMode();
    }
}

function deleteSelectedMessages(deleteType) {
    if (groupChatManager) {
        groupChatManager.deleteSelectedMessages(deleteType);
    }
}

function cancelSelection() {
    if (groupChatManager) {
        groupChatManager.cancelSelection();
    }
}

// نمایش اعضای گروه
function showGroupMembers() {
    document.getElementById('groupMembersModal').style.display = 'block';
    loadGroupMembers();
}

function hideGroupMembers() {
    document.getElementById('groupMembersModal').style.display = 'none';
}

function loadGroupMembers() {
    const membersList = document.getElementById('groupMembersList');
    membersList.innerHTML = '<div class="loading">در حال بارگذاری...</div>';
    
    fetch('api/get_group_members.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: `group_id=${groupChatManager.groupId}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            let html = '';
            data.members.forEach(member => {
                const statusClass = member.is_online ? 'online' : 'offline';
                const statusText = member.is_online ? 'آنلاین' : 'آفلاین';
                
                html += `
                    <div class="member-item">
                        <div class="member-avatar">${member.username.charAt(0).toUpperCase()}</div>
                        <div class="member-info">
                            <div class="member-name">${member.username}</div>
                            <div class="member-status ${statusClass}">${statusText}</div>
                        </div>
                    </div>
                `;
            });
            membersList.innerHTML = html;
        } else {
            membersList.innerHTML = '<div class="error">خطا در بارگذاری اعضا</div>';
        }
    })
    .catch(error => {
        console.error('خطا در بارگذاری اعضای گروه:', error);
        membersList.innerHTML = '<div class="error">خطا در اتصال به سرور</div>';
    });
}

class GroupCallManager {
    constructor(groupId, currentUserId, groupName) {
        this.groupId = groupId;
        this.currentUserId = currentUserId;
        this.groupName = groupName;
        this.peers = {}; // targetUserId -> RTCPeerConnection
        this.localStream = null;
        this.isMuted = false;
        this.isVideoOff = false;
        this.isCallActive = false;
        
        // تنظیمات WebRTC
        this.iceServers = [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' }
        ];
    }

    async startCall() {
        if (this.isCallActive) return;
        this.isCallActive = true;
        
        document.getElementById('groupVideoCallModal').style.display = 'block';
        this.updateStatus('در حال دسترسی به دوربین و میکروفون...');

        try {
            this.localStream = await navigator.mediaDevices.getUserMedia({
                video: { width: 480, height: 360, frameRate: 20 },
                audio: true
            });
            
            this.addVideoElement(this.currentUserId, 'شما (خودتان)', this.localStream, true);
            this.updateStatus('در حال اتصال به اعضای گروه...');
            
            // ارسال سیگنال شروع تماس به همه اعضا (از طریق پیام سیستمی یا سیگنالینگ)
            // در اینجا برای سادگی، ما به همه اعضای آنلاین اطلاع می‌دهیم
            this.broadcastCallInitiation();
            
            // شروع دریافت سیگنال‌ها
            this.startSignalingPolling();
            
        } catch (error) {
            console.error('خطا در شروع تماس گروهی:', error);
            this.updateStatus('خطا در دسترسی به دوربین/میکروفون', 'error');
            this.endCall();
        }
    }

    updateStatus(message, type = 'info') {
        const statusEl = document.getElementById('callStatus');
        if (statusEl) {
            statusEl.textContent = message;
            statusEl.className = `call-status ${type}`;
        }
    }

    addVideoElement(userId, userName, stream, isLocal = false) {
        const container = document.getElementById('groupVideoContainer');
        let wrapper = document.getElementById(`video-wrapper-${userId}`);
        
        if (!wrapper) {
            wrapper = document.createElement('div');
            wrapper.id = `video-wrapper-${userId}`;
            wrapper.className = 'video-wrapper';
            
            const video = document.createElement('video');
            video.id = `video-${userId}`;
            video.autoplay = true;
            video.playsInline = true;
            if (isLocal) video.muted = true;
            
            const label = document.createElement('div');
            label.className = 'video-label';
            label.textContent = userName;
            
            wrapper.appendChild(video);
            wrapper.appendChild(label);
            container.appendChild(wrapper);
            
            video.srcObject = stream;
        }
    }

    removeVideoElement(userId) {
        const wrapper = document.getElementById(`video-wrapper-${userId}`);
        if (wrapper) wrapper.remove();
    }

    async broadcastCallInitiation() {
        // ارسال یک سیگنال خاص به گروه برای دعوت به تماس
        // در این نسخه ساده، ما از سیستم سیگنالینگ موجود استفاده می‌کنیم
        // ابتدا اعضای گروه را می‌گیریم
        const response = await fetch('api/get_group_members.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `group_id=${this.groupId}`
        });
        const data = await response.json();
        
        if (data.success) {
            data.members.forEach(member => {
                if (member.id != this.currentUserId && member.is_online) {
                    this.initiatePeerConnection(member.id, member.username, true);
                }
            });
        }
    }

    async initiatePeerConnection(targetUserId, targetUsername, isOffer) {
        if (this.peers[targetUserId]) return;

        const pc = new RTCPeerConnection({ iceServers: this.iceServers });
        this.peers[targetUserId] = pc;

        // اضافه کردن استریم محلی
        this.localStream.getTracks().forEach(track => {
            pc.addTrack(track, this.localStream);
        });

        pc.onicecandidate = (event) => {
            if (event.candidate) {
                this.sendSignal(targetUserId, 'group-ice', JSON.stringify(event.candidate));
            }
        };

        pc.ontrack = (event) => {
            this.addVideoElement(targetUserId, targetUsername, event.streams[0]);
        };

        pc.onconnectionstatechange = () => {
            if (pc.connectionState === 'disconnected' || pc.connectionState === 'failed') {
                this.removeVideoElement(targetUserId);
                delete this.peers[targetUserId];
            }
        };

        if (isOffer) {
            const offer = await pc.createOffer();
            await pc.setLocalDescription(offer);
            this.sendSignal(targetUserId, 'group-offer', JSON.stringify(offer));
        }
    }

    sendSignal(toUserId, type, data) {
        fetch('api/send_signal.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `to_user_id=${toUserId}&signal_type=${type}&signal_data=${encodeURIComponent(data)}`
        });
    }

    startSignalingPolling() {
        this.pollingInterval = setInterval(() => {
            this.checkForSignals();
        }, 1500);
    }

    async checkForSignals() {
        // برای سادگی از یک API کلی استفاده می‌کنیم (باید در بک‌اند اصلاح شود یا فیلتر شود)
        // در اینجا ما سیگنال‌های با نوع group-* را پردازش می‌کنیم
        fetch('api/get_signal.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: `from_user_id=0&signal_type_prefix=group-` // دریافت فقط سیگنال‌های گروهی
        })
        .then(res => res.json())
        .then(data => {
            if (data.success && data.signals) {
                data.signals.forEach(signal => this.processSignal(signal));
            }
        });
    }

    async processSignal(signal) {
        const fromId = signal.from_user_id;
        const data = JSON.parse(signal.signal_data);

        switch (signal.signal_type) {
            case 'group-offer':
                if (!this.isCallActive) {
                    // نمایش دعوت به تماس گروهی (اختیاری)
                    // برای سادگی مستقیماً وصل می‌شویم اگر کاربر بخواهد
                }
                await this.handleOffer(fromId, data);
                break;
            case 'group-answer':
                await this.handleAnswer(fromId, data);
                break;
            case 'group-ice':
                await this.handleIce(fromId, data);
                break;
        }
    }

    async handleOffer(fromId, offer) {
        if (!this.isCallActive) return; // کاربر باید دکمه پیوستن را زده باشد
        
        await this.initiatePeerConnection(fromId, `کاربر ${fromId}`, false);
        const pc = this.peers[fromId];
        await pc.setRemoteDescription(new RTCSessionDescription(offer));
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        this.sendSignal(fromId, 'group-answer', JSON.stringify(answer));
    }

    async handleAnswer(fromId, answer) {
        const pc = this.peers[fromId];
        if (pc) {
            await pc.setRemoteDescription(new RTCSessionDescription(answer));
        }
    }

    async handleIce(fromId, candidate) {
        const pc = this.peers[fromId];
        if (pc) {
            await pc.addIceCandidate(new RTCIceCandidate(candidate));
        }
    }

    endCall() {
        this.isCallActive = false;
        clearInterval(this.pollingInterval);
        
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
        }
        
        Object.values(this.peers).forEach(pc => pc.close());
        this.peers = {};
        
        document.getElementById('groupVideoContainer').innerHTML = '';
        document.getElementById('groupVideoCallModal').style.display = 'none';
    }
}

let groupCallManager = null;

// تابع شروع تماس گروهی
function startGroupVideoCall() {
    if (!groupCallManager) {
        groupCallManager = new GroupCallManager(
            groupChatManager.groupId, 
            groupChatManager.currentUserId, 
            groupChatManager.groupName
        );
    }
    groupCallManager.startCall();
}

function endGroupCall() {
    if (groupCallManager) {
        groupCallManager.endCall();
    }
}

function toggleMute() {
    if (groupCallManager && groupCallManager.localStream) {
        groupCallManager.isMuted = !groupCallManager.isMuted;
        groupCallManager.localStream.getAudioTracks()[0].enabled = !groupCallManager.isMuted;
        document.getElementById('groupMuteBtn').textContent = groupCallManager.isMuted ? '🔇' : '🎤';
    }
}

function toggleVideo() {
    if (groupCallManager && groupCallManager.localStream) {
        groupCallManager.isVideoOff = !groupCallManager.isVideoOff;
        groupCallManager.localStream.getVideoTracks()[0].enabled = !groupCallManager.isVideoOff;
        document.getElementById('groupVideoBtn').textContent = groupCallManager.isVideoOff ? '🚫' : '📹';
    }
}

// نمایش notification برای پیام جدید
function showNotification(message, sender) {
    if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(`پیام جدید در گروه از ${sender}`, {
            body: message,
            icon: '/favicon.ico'
        });
    }
}

// درخواست مجوز notification
function requestNotificationPermission() {
    if ('Notification' in window && Notification.permission === 'default') {
        Notification.requestPermission();
    }
}
