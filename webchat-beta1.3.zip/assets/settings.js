/**
 * JavaScript برای صفحه تنظیمات
 */

document.addEventListener('DOMContentLoaded', () => {
    // مقداردهی اولیه وضعیت اعلان‌ها
    checkNotificationPermission();
});

/**
 * سوئیچ بین تب‌های تنظیمات
 */
function switchTab(tabId) {
    // حذف کلاس active از تمام دکمه‌ها و محتواها
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));

    // فعال کردن تب مورد نظر
    const targetBtn = document.querySelector(`.tab-btn[onclick="switchTab('${tabId}')"]`);
    const targetContent = document.getElementById(`${tabId}Tab`);

    if (targetBtn) targetBtn.classList.add('active');
    if (targetContent) targetContent.classList.add('active');
}

/**
 * آپلود تصویر پروفایل
 */
async function uploadProfilePicture(input) {
    if (!input.files || !input.files[0]) return;

    const file = input.files[0];

    // چک حجم فایل (3 مگابایت)
    if (file.size > 3 * 1024 * 1024) {
        alert('حجم فایل نباید بیشتر از 3 مگابایت باشد');
        return;
    }

    const formData = new FormData();
    formData.append('profile_pic', file);

    showLoading(true);

    try {
        const response = await fetch('api/upload_profile_picture.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();

        if (result.success) {
            // بروزرسانی تصویر در صفحه
            const profileDisplay = document.getElementById('profileDisplay');
            profileDisplay.innerHTML = `<img src="uploads/profile_pics/${result.profile_picture}" alt="Profile">`;
            alert(result.message);
        } else {
            alert(result.message);
        }
    } catch (error) {
        console.error('Error uploading profile picture:', error);
        alert('خطا در آپلود تصویر');
    } finally {
        showLoading(false);
    }
}

/**
 * فرم تغییر اطلاعات حساب
 */
document.getElementById('accountForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const formData = new FormData(e.target);
    formData.append('type', 'account');

    showLoading(true);

    try {
        const response = await fetch('api/update_settings.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        alert(result.message);

        if (result.success) {
            location.reload();
        }
    } catch (error) {
        alert('خطا در بروزرسانی اطلاعات');
    } finally {
        showLoading(false);
    }
});

/**
 * فرم تغییر رمز عبور
 */
document.getElementById('passwordForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();

    const newPass = document.getElementById('newPassword').value;
    const confirmPass = document.getElementById('confirmPassword').value;

    if (newPass !== confirmPass) {
        alert('رمز عبور جدید و تکرار آن مطابقت ندارند');
        return;
    }

    const formData = new FormData(e.target);

    showLoading(true);

    try {
        const response = await fetch('api/change_password.php', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        alert(result.message);

        if (result.success) {
            e.target.reset();
        }
    } catch (error) {
        alert('خطا در تغییر رمز عبور');
    } finally {
        showLoading(false);
    }
});

/**
 * تغییر وضعیت نمایش آنلاین
 */
document.getElementById('showOnlineStatus')?.addEventListener('change', async (e) => {
    const formData = new FormData();
    formData.append('type', 'privacy');
    formData.append('value', e.target.checked);

    try {
        const response = await fetch('api/update_settings.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        if (!result.success) alert(result.message);
    } catch (error) {
        alert('خطا در ذخیره تنظیمات');
    }
});

/**
 * تغییر تم
 */
document.querySelectorAll('input[name="theme"]').forEach(radio => {
    radio.addEventListener('change', async (e) => {
        const theme = e.target.value;

        // اعمال تم به صورت لحظه‌ای
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);

        const formData = new FormData();
        formData.append('type', 'theme');
        formData.append('value', theme);

        try {
            const response = await fetch('api/update_settings.php', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();
            if (!result.success) alert(result.message);
        } catch (error) {
            alert('خطا در ذخیره تم');
        }
    });
});

/**
 * تغییر زبان
 */
document.querySelectorAll('input[name="language"]').forEach(radio => {
    radio.addEventListener('change', async (e) => {
        const lang = e.target.value;

        const formData = new FormData();
        formData.append('type', 'language');
        formData.append('value', lang);

        showLoading(true);

        try {
            const response = await fetch('api/update_settings.php', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            if (result.success) {
                location.reload(); // برای اعمال زبان جدید صفحه باید ریلود شود
            } else {
                alert(result.message);
            }
        } catch (error) {
            alert('خطا در تغییر زبان');
        } finally {
            showLoading(false);
        }
    });
});

/**
 * فعال‌سازی اعلان‌ها
 */
document.getElementById('enableNotifications')?.addEventListener('change', async (e) => {
    if (e.target.checked && Notification.permission !== 'granted') {
        const permission = await Notification.requestPermission();
        if (permission !== 'granted') {
            e.target.checked = false;
            alert('اجازه نمایش اعلان داده نشد');
            return;
        }
    }

    const formData = new FormData();
    formData.append('type', 'notifications');
    formData.append('value', e.target.checked);

    try {
        const response = await fetch('api/update_settings.php', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        if (!result.success) alert(result.message);
        checkNotificationPermission();
    } catch (error) {
        alert('خطا در ذخیره تنظیمات اعلان');
    }
});

/**
 * تست اعلان
 */
document.getElementById('testNotification')?.addEventListener('click', () => {
    if (Notification.permission === 'granted') {
        new Notification('تست اعلان', {
            body: 'این یک اعلان تستی از وب‌چت است.',
            icon: 'favicon.ico'
        });
    } else {
        alert('ابتدا باید اعلان‌ها را فعال کنید');
    }
});

/**
 * تنظیم بیت‌ریت تماس
 */
const bitrateRange = document.getElementById('bitrateRange');
if (bitrateRange) {
    // بروزرسانی عدد نمایشی هنگام کشیدن اسلایدر
    bitrateRange.addEventListener('input', (e) => {
        const valueDisplay = document.getElementById('bitrateValue');
        if (valueDisplay) valueDisplay.textContent = e.target.value + ' kbps';
    });

    // ذخیره در دیتابیس هنگام اتمام تغییر
    bitrateRange.addEventListener('change', async (e) => {
        const value = e.target.value;
        const formData = new FormData();
        formData.append('type', 'bitrate');
        formData.append('value', value);

        try {
            const response = await fetch('api/update_settings.php', {
                method: 'POST',
                body: formData
            });
            const result = await response.json();

            if (result.success) {
                // آپدیت آنی webrtcManager اگر در حافظه است
                if (window.webrtcManager) {
                    window.webrtcManager.preferredBitrate = parseInt(value);
                    window.webrtcManager.maxBitrate = parseInt(value);
                    console.log('Live bitrate updated to:', value);
                }

                // نمایش نوتیفیکیشن موفقیت
                if (typeof showNotification === 'function') {
                    showNotification('بیت‌ریت تماس با موفقیت بروزرسانی شد', 'success');
                } else {
                    console.log('Bitrate updated to ' + value);
                }
            } else {
                alert(result.message);
            }
        } catch (error) {
            console.error('Error updating bitrate:', error);
        }
    });
}

/**
 * حذف حساب کاربری
 */
document.getElementById('deleteAccountBtn')?.addEventListener('click', () => {
    showConfirm('حذف حساب کاربری', 'آیا از حذف حساب کاربری خود اطمینان دارید؟ این عمل غیرقابل بازگشت است.', async () => {
        // در اینجا می‌توانید API حذف حساب را فراخوانی کنید
        alert('این قابلیت به زودی اضافه خواهد شد');
    });
});

/**
 * نمایش/مخفی سازی لودینگ
 */
function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) overlay.style.display = show ? 'flex' : 'none';
}

/**
 * نمایش مودال تأیید
 */
function showConfirm(title, message, onYes) {
    const modal = document.getElementById('confirmModal');
    const titleEl = document.getElementById('confirmTitle');
    const msgEl = document.getElementById('confirmMessage');
    const yesBtn = document.getElementById('confirmYes');
    const noBtn = document.getElementById('confirmNo');

    if (!modal) return;

    titleEl.textContent = title;
    msgEl.textContent = message;
    modal.style.display = 'flex';

    const cleanup = () => {
        modal.style.display = 'none';
        yesBtn.replaceWith(yesBtn.cloneNode(true));
        noBtn.replaceWith(noBtn.cloneNode(true));
    };

    document.getElementById('confirmYes').onclick = () => {
        cleanup();
        onYes();
    };

    document.getElementById('confirmNo').onclick = cleanup;
}

/**
 * بررسی وضعیت اجازه اعلان
 */
function checkNotificationPermission() {
    const statusEl = document.getElementById('notificationStatus');
    if (!statusEl) return;

    if (!('Notification' in window)) {
        statusEl.innerHTML = '<span class="status-error">مرورگر شما از اعلان‌ها پشتیبانی نمی‌کند</span>';
        return;
    }

    switch (Notification.permission) {
        case 'granted':
            statusEl.innerHTML = '<span class="status-success">✅ اعلان‌ها فعال هستند</span>';
            break;
        case 'denied':
            statusEl.innerHTML = '<span class="status-error">❌ اعلان‌ها بلاک شده‌اند</span>';
            break;
        default:
            statusEl.innerHTML = '<span class="status-warning">⚠️ نیاز به اجازه دسترسی</span>';
    }
}
