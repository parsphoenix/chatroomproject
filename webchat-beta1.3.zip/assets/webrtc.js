/**
 * WebRTC Implementation پیشرفته برای تماس صوتی و تصویری
 */

class WebRTCManager {
    constructor(targetUserId = 0, currentUserId = 0) {
        this.targetUserId = targetUserId;
        this.currentUserId = currentUserId;
        this.callerUsername = ''; // برای ذخیره نام تماس‌گیرنده
        this.peerConnection = null;
        this.localStream = null;
        this.remoteStream = null;
        this.isCallActive = false;
        this.isMuted = false;
        this.isVideoOff = false;
        this.isInitiator = false;
        this.callType = 'video'; // 'video' یا 'audio'
        this.callStartTime = null;
        this.callTimer = null;
        this.isMinimized = false;
        this.isFullscreen = false;

        // متغیرهای جدید
        this.isRecording = false;
        this.mediaRecorder = null;
        this.recordedChunks = [];
        this.isScreenSharing = false;
        this.originalVideoTrack = null;
        this.isSpeakerOn = true;
        this.incomingCallTimer = null;
        this.incomingCallStartTime = null;
        this.iceCandidatesQueue = []; // صف برای کاندیداهایی که قبل از Offer/Answer میرسند

        // تنظیمات کیفیت تصویر
        this.videoQuality = '360p'; // '240p', '360p', '480p'
        this.videoConstraints = {
            '240p': { width: 320, height: 240, frameRate: 15 },
            '360p': { width: 480, height: 360, frameRate: 20 },
            '480p': { width: 640, height: 480, frameRate: 25 }
        };

        // محدودیت پهنای باند بر اساس کیفیت
        this.bitrates = {
            '240p': 1000,
            '360p': 1500,
            '480p': 2000,
            'screen': 2000 // برای اشتراک‌گذاری صفحه
        };
        this.maxBitrate = this.bitrates[this.videoQuality]; // kbps

        // STUN servers برای NAT traversal
        this.iceServers = [
            { urls: 'stun:stun.l.google.com:19302' },
            { urls: 'stun:stun1.l.google.com:19302' },
            { urls: 'stun:stun2.l.google.com:19302' },
            { urls: 'stun:stun3.l.google.com:19302' },
            { urls: 'stun:stun4.l.google.com:19302' }
        ];

        // timeout تماس خروجی
        this.outgoingCallTimeout = null;

        // تنظیمات دلخواه کاربر (از سرور دریافت می‌شود)
        this.preferredBitrate = 500; // پیش‌فرض 500kbps

        this.init();
    }

    init() {
        // شروع polling برای دریافت سیگنال‌ها
        this.startSignalingPolling();

        // چک دسترسی به دستگاه‌ها
        this.checkDevicePermissions();

        // درخواست مجوز اعلان دسکتاپ
        this.requestNotificationPermission();

        // دریافت تنظیمات کاربر
        this.fetchUserSettings();

        // اضافه کردن رویداد بستن صفحه (استفاده از sendBeacon برای اطمینان از ارسال)
        window.addEventListener('beforeunload', () => {
            if (this.isCallActive) {
                const formData = new FormData();
                formData.append('to_user_id', this.targetUserId);
                formData.append('signal_type', 'end');
                formData.append('signal_data', 'page_closed');
                navigator.sendBeacon('api/send_signal.php', formData);
            }
        });
    }

    // دریافت تنظیمات کاربر از سرور
    async fetchUserSettings() {
        try {
            const response = await fetch('api/get_user_settings.php');
            const data = await response.json();
            if (data.success) {
                if (data.preferred_bitrate) {
                    this.preferredBitrate = data.preferred_bitrate;
                    this.maxBitrate = this.preferredBitrate;
                    console.log('User preferred bitrate loaded:', this.preferredBitrate, 'kbps');
                }
            }
        } catch (error) {
            console.error('Error fetching user settings:', error);
        }
    }

    // درخواست مجوز اعلان دسکتاپ
    async requestNotificationPermission() {
        if (!("Notification" in window)) {
            console.log("این مرورگر از اعلان‌های دسکتاپ پشتیبانی نمی‌کند");
            return;
        }

        if (Notification.permission !== "granted" && Notification.permission !== "denied") {
            try {
                await Notification.requestPermission();
            } catch (error) {
                console.error("خطا در درخواست مجوز اعلان:", error);
            }
        }
    }

    // نمایش اعلان دسکتاپ
    showDesktopNotification(title, body, icon = 'assets/img/call-icon.png') {
        if (!("Notification" in window) || Notification.permission !== "granted") {
            return;
        }

        const notification = new Notification(title, {
            body: body,
            icon: icon,
            tag: 'incoming-call',
            renotify: true,
            silent: false
        });

        notification.onclick = () => {
            window.focus();
            notification.close();
            // اگر هنوز تماسی فعال نشده، مودال را نشان بده
            if (!this.isCallActive) {
                this.showIncomingCallModal();
            }
        };
    }

    // چک مجوزهای دستگاه
    async checkDevicePermissions() {
        try {
            const permissions = await navigator.permissions.query({ name: 'camera' });
            const micPermissions = await navigator.permissions.query({ name: 'microphone' });

            if (permissions.state === 'denied' || micPermissions.state === 'denied') {
                this.showCallStatus('دسترسی به دوربین/میکروفون رد شده است', 'error');
            }
        } catch (error) {
            console.log('Permission API پشتیبانی نمی‌شود');
        }
    }

    // نمایش وضعیت تماس
    showCallStatus(message, type = 'info') {
        const statusElement = document.getElementById('callStatus');
        if (statusElement) {
            statusElement.textContent = message;
            statusElement.className = `call-status ${type}`;
        }

        const deviceStatus = document.getElementById('deviceStatus');
        if (deviceStatus) {
            deviceStatus.innerHTML = `<span class="${type}">${message}</span>`;
        }
    }

    // شروع تماس تصویری
    async startVideoCall(targetId = null) {
        if (targetId) this.targetUserId = targetId;

        if (!this.targetUserId || this.targetUserId <= 0) {
            this.showCallStatus('کاربر مقصد مشخص نشده است', 'error');
            return;
        }

        // جلوگیری از تماس با خود
        if (this.targetUserId == this.currentUserId) {
            this.showCallStatus('نمی‌توانید با خودتان تماس بگیرید', 'error');
            return;
        }

        if (this.isCallActive) {
            this.showCallStatus('تماس در حال انجام است', 'warning');
            return;
        }

        try {
            this.callType = 'video';
            this.isInitiator = true;
            this.showCallStatus('در حال دسترسی به دوربین و میکروفون...', 'info');

            // پاکسازی سیگنال‌های قدیمی قبل از شروع تماس جدید
            await this.cleanupOldSignals();

            // شروع نگهدارنده modal
            this.startModalKeeper();

            await this.initializeCall(true);
            await this.createOffer();

            this.showCallStatus('در انتظار پاسخ طرف مقابل...', 'info');

            // تایمر 30 ثانیه برای عدم پاسخگویی
            this.outgoingCallTimeout = setTimeout(() => {
                if (this.peerConnection && this.peerConnection.connectionState !== 'connected') {
                    this.showCallStatus('تماس بی‌پاسخ ماند', 'error');
                    this.endCall('no_answer');
                }
            }, 30000);

        } catch (error) {
            console.error('خطا در شروع تماس تصویری:', error);

            if (error.name === 'NotAllowedError') {
                this.showCallStatus('دسترسی به دوربین/میکروفون رد شد - می‌توانید فقط تصویر و صدا دریافت کنید', 'warning');
                await this.initializeCallReceiveOnly();
            } else if (error.name === 'NotFoundError') {
                this.showCallStatus('دوربین یا میکروفون یافت نشد - می‌توانید فقط تصویر و صدا دریافت کنید', 'warning');
                await this.initializeCallReceiveOnly();
            } else {
                this.showCallStatus('خطا در شروع تماس تصویری', 'error');
                this.endCall();
            }
        }
    }

    // شروع تماس صوتی
    async startAudioCall(targetId = null) {
        if (targetId) this.targetUserId = targetId;

        if (!this.targetUserId || this.targetUserId <= 0) {
            this.showCallStatus('کاربر مقصد مشخص نشده است', 'error');
            return;
        }

        if (this.isCallActive) {
            this.showCallStatus('تماس در حال انجام است', 'warning');
            return;
        }

        try {
            this.callType = 'audio';
            this.isInitiator = true;
            this.showCallStatus('در حال دسترسی به میکروفون...', 'info');

            // پاکسازی سیگنال‌های قدیمی قبل از شروع تماس جدید
            await this.cleanupOldSignals();

            // شروع نگهدارنده modal
            this.startModalKeeper();

            await this.initializeCall(false);
            await this.createOffer();

            this.showCallStatus('در انتظار پاسخ طرف مقابل...', 'info');

            // تایمر 30 ثانیه برای عدم پاسخگویی
            this.outgoingCallTimeout = setTimeout(() => {
                if (this.peerConnection && this.peerConnection.connectionState !== 'connected') {
                    this.showCallStatus('تماس بی‌پاسخ ماند', 'error');
                    this.endCall('no_answer');
                }
            }, 30000);

            // تایمر تماس بعد از اتصال واقعی شروع می‌شه (در onconnectionstatechange)

        } catch (error) {
            console.error('خطا در شروع تماس صوتی:', error);

            if (error.name === 'NotAllowedError') {
                this.showCallStatus('دسترسی به میکروفون رد شد - می‌توانید فقط صدا دریافت کنید', 'warning');
                await this.initializeCallReceiveOnly();
            } else if (error.name === 'NotFoundError') {
                this.showCallStatus('میکروفون یافت نشد - می‌توانید فقط صدا دریافت کنید', 'warning');
                await this.initializeCallReceiveOnly();
            } else {
                this.showCallStatus('خطا در شروع تماس صوتی: ' + (error.message || error), 'error');
                setTimeout(() => this.endCall(), 3000);
            }
        }
    }

    // شروع تایمر تماس
    startCallTimer() {
        this.callStartTime = Date.now();
        this.callTimer = setInterval(() => {
            const elapsed = Math.floor((Date.now() - this.callStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            const titleElement = document.getElementById('callTitle');
            if (titleElement && this.isCallActive) {
                titleElement.textContent = `تماس ${this.callType === 'video' ? 'تصویری' : 'صوتی'} - ${timeString}`;
            }
        }, 1000);
    }

    // توقف تایمر تماس
    stopCallTimer() {
        if (this.callTimer) {
            clearInterval(this.callTimer);
            this.callTimer = null;
        }
    }

    // شروع نگهدارنده modal - اطمینان از نمایش مداوم
    startModalKeeper() {
        // توقف نگهدارنده قبلی اگر وجود دارد
        this.stopModalKeeper();

        console.log('Starting modal keeper...');
        this.modalKeeperInterval = setInterval(() => {
            if (this.isCallActive) {
                const modal = document.getElementById('videoCallModal');
                if (modal && (modal.style.display === 'none' || !modal.classList.contains('active'))) {
                    console.log('Modal keeper: Re-showing hidden modal');
                    this.showCallModal();
                }
            } else {
                // اگر تماس فعال نیست، نگهدارنده را متوقف کن
                this.stopModalKeeper();
            }
        }, 500); // هر نیم ثانیه چک می‌کند
    }

    // توقف نگهدارنده modal
    stopModalKeeper() {
        if (this.modalKeeperInterval) {
            clearInterval(this.modalKeeperInterval);
            this.modalKeeperInterval = null;
            console.log('Modal keeper stopped');
        }
    }

    // مقداردهی اولیه تماس
    async initializeCall(includeVideo) {
        this.isCallActive = true;

        // نمایش modal تماس
        this.showCallModal();

        try {
            // تنظیمات کیفیت تصویر
            const videoConstraints = includeVideo ? {
                ...this.videoConstraints[this.videoQuality],
                facingMode: 'user'
            } : false;

            // تلاش برای دریافت stream از دوربین/میکروفون
            this.localStream = await navigator.mediaDevices.getUserMedia({
                video: videoConstraints,
                audio: {
                    echoCancellation: true,
                    noiseSuppression: true,
                    autoGainControl: true
                }
            });

            // نمایش local video
            const localVideo = document.getElementById('localVideo');
            localVideo.srcObject = this.localStream;

            this.showCallStatus('دوربین و میکروفون آماده است', 'success');

        } catch (error) {
            console.log('خطا در دسترسی به دوربین/میکروفون:', error);

            // تلاش برای دریافت فقط صدا
            try {
                this.localStream = await navigator.mediaDevices.getUserMedia({
                    video: false,
                    audio: {
                        echoCancellation: true,
                        noiseSuppression: true,
                        autoGainControl: true
                    }
                });
                this.showCallStatus('فقط میکروفون در دسترس است - می‌توانید صدا ارسال کنید', 'warning');
            } catch (audioError) {
                console.log('خطا در دسترسی به میکروفون:', audioError);
                // ادامه بدون local stream
                this.showCallStatus('دوربین و میکروفون در دسترس نیست - فقط می‌توانید تصویر و صدا دریافت کنید', 'warning');
            }
        }

        // ساخت peer connection
        this.createPeerConnection();

        // اضافه کردن local stream به peer connection (اگر موجود باشد)
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => {
                this.peerConnection.addTrack(track, this.localStream);
            });
        }
    }

    // مقداردهی تماس فقط برای دریافت
    async initializeCallReceiveOnly() {
        this.isCallActive = true;

        // نمایش modal تماس
        this.showCallModal();

        // شروع نگهدارنده modal
        if (this.isInitiator) {
            this.startModalKeeper();
        }

        // ساخت peer connection بدون local stream
        this.createPeerConnection();

        this.showCallStatus('آماده دریافت تصویر و صدا...', 'info');

        // ادامه فرآیند تماس
        if (this.isInitiator) {
            await this.createOffer();
            this.showCallStatus('در حال برقراری تماس (فقط دریافت)...', 'info');
            this.startCallTimer();
        }
    }

    // ساخت peer connection
    createPeerConnection() {
        this.peerConnection = new RTCPeerConnection({
            iceServers: this.iceServers
        });

        // مدیریت ICE candidates
        this.peerConnection.onicecandidate = (event) => {
            if (event.candidate) {
                console.log('Sending ICE candidate');
                this.sendSignal('ice', JSON.stringify(event.candidate));
            }
        };

        // مدیریت remote stream
        this.peerConnection.ontrack = (event) => {
            console.log('Remote track received:', event.track.kind);

            const remoteVideo = document.getElementById('remoteVideo');
            if (!remoteVideo) return;

            if (event.streams && event.streams[0]) {
                this.remoteStream = event.streams[0];
                remoteVideo.srcObject = this.remoteStream;
            } else {
                // ایجاد استریم صوری اگر استریم اصلی موجود نبود
                if (!this.remoteStream) {
                    this.remoteStream = new MediaStream();
                    remoteVideo.srcObject = this.remoteStream;
                }
                this.remoteStream.addTrack(event.track);
            }

            // نمایش پیام موفقیت
            this.showCallStatus('تماس برقرار شد', 'success');

            // اطمینان از نمایش کامل modal
            setTimeout(() => {
                this.ensureFullCallDisplay();
            }, 500);
        };

        // مدیریت تغییر وضعیت اتصال
        this.peerConnection.onconnectionstatechange = () => {
            if (!this.peerConnection) return;
            console.log('Connection state:', this.peerConnection.connectionState);

            if (this.peerConnection.connectionState === 'connected') {
                this.limitBandwidth();
                // شروع تایمر تماس فقط وقتی واقعاً متصل شد
                if (!this.callTimer) {
                    this.startCallTimer();
                }
                this.showCallStatus('تماس برقرار شد', 'success');
                // اطمینان مجدد از نمایش صفحه هنگام اتصال موفق
                this.ensureFullCallDisplay();
                // کاهش سرعت polling بعد از اتصال موفق
                this.setPollingSpeed('connected');

                // لغو تایمر عدم پاسخگویی
                if (this.outgoingCallTimeout) {
                    clearTimeout(this.outgoingCallTimeout);
                    this.outgoingCallTimeout = null;
                }
            } else if (this.peerConnection.connectionState === 'failed' || this.peerConnection.connectionState === 'closed') {
                this.endCall();
            }
        };

        // مدیریت تغییر وضعیت ICE
        this.peerConnection.oniceconnectionstatechange = () => {
            if (!this.peerConnection) return;
            const state = this.peerConnection.iceConnectionState;
            console.log('ICE Connection state:', state);

            if (state === 'connected' || state === 'completed') {
                console.log('ICE connected/completed successfully');
            } else if (state === 'failed') {
                console.log('ICE connection failed, attempting restart...');
                // تلاش برای restart قبل از قطع
                try {
                    this.peerConnection.restartIce();
                } catch (e) {
                    console.log('ICE restart failed, ending call');
                    this.endCall();
                }
            } else if (state === 'closed') {
                console.log('ICE connection closed, ending call');
                this.endCall();
            } else if (state === 'disconnected') {
                console.log('ICE connection disconnected - waiting for reconnection...');
                this.showCallStatus('اتصال قطع شد، در حال تلاش مجدد...', 'warning');
                setTimeout(() => {
                    if (this.peerConnection && this.peerConnection.iceConnectionState === 'disconnected') {
                        console.log('ICE connection timed out after being disconnected, ending call');
                        this.endCall();
                    }
                }, 10000);
            }
        };
    }

    // تغییر کیفیت ویدیو و محدودیت بیت‌ریت
    async setVideoQuality(quality) {
        if (!this.bitrates[quality]) return;

        this.videoQuality = quality;
        this.maxBitrate = this.bitrates[quality];

        // اگر تماس فعال است، محدودیت را اعمال کن
        if (this.isCallActive && this.peerConnection) {
            await this.limitBandwidth(this.isScreenSharing);

            // اگر استریم محلی داریم، کیفیت را تغییر بده
            if (this.localStream && !this.isScreenSharing) {
                const videoTrack = this.localStream.getVideoTracks()[0];
                if (videoTrack) {
                    try {
                        await videoTrack.applyConstraints(this.videoConstraints[quality]);
                        console.log('Video quality changed to:', quality);
                    } catch (e) {
                        console.error('Error applying video constraints:', e);
                    }
                }
            }
        }

        this.showCallStatus(`کیفیت به ${quality} تغییر یافت`, 'info');
    }

    // محدود کردن پهنای باند (Bitrate Limiting)
    async limitBandwidth(isScreen = false) {
        try {
            if (!this.peerConnection) return;

            const senders = this.peerConnection.getSenders();
            const videoSender = senders.find(s => s.track && s.track.kind === 'video');

            if (videoSender) {
                const parameters = videoSender.getParameters();
                if (!parameters.encodings) {
                    parameters.encodings = [{}];
                }

                // بیت‌ریت مورد نظر بر اساس کیفیت یا اشتراک صفحه یا تنظیمات کاربر
                // اولویت با تنظیمات کاربر است اگر Screen Sharing نباشد
                let bitrate = isScreen ? this.bitrates.screen : this.bitrates[this.videoQuality];

                // اعمال بیت‌ریت دلخواه کاربر اگر Screen Share نیست
                if (!isScreen && this.preferredBitrate) {
                    bitrate = this.preferredBitrate;
                }

                parameters.encodings[0].maxBitrate = bitrate * 1000; // تبدیل به bps

                await videoSender.setParameters(parameters);
                console.log('Bandwidth limited to:', bitrate, 'kbps', isScreen ? '(Screen Share)' : `(User Preferred: ${bitrate})`);
            }
        } catch (error) {
            console.error('خطا در محدود کردن پهنای باند:', error);
        }
    }

    // ساخت offer
    async createOffer() {
        try {
            const offer = await this.peerConnection.createOffer();
            await this.peerConnection.setLocalDescription(offer);

            // ارسال offer به طرف مقابل
            this.sendSignal('offer', JSON.stringify(offer));

        } catch (error) {
            console.error('خطا در ساخت offer:', error);
            throw error;
        }
    }

    // پردازش offer دریافتی
    async handleOffer(offerData) {
        try {
            console.log('Raw offer data:', offerData);
            // بررسی نوع داده و تبدیل در صورت نیاز
            if (typeof offerData === 'string') {
                try {
                    this.pendingOffer = JSON.parse(offerData);
                } catch (e) {
                    console.error('Error parsing offer string:', e);
                    return;
                }
            } else if (typeof offerData === 'object') {
                this.pendingOffer = offerData;
            } else {
                console.error('Invalid offer data type:', typeof offerData);
                return;
            }

            console.log('Parsed pending offer:', this.pendingOffer);

            // ذخیره در متغیر global و localStorage به عنوان پشتیبان پایدار
            window.lastWebRTCOffer = this.pendingOffer;
            window.lastRawOfferData = this.rawOfferData;
            try {
                localStorage.setItem('webrtc_pending_offer', JSON.stringify(this.pendingOffer));
                console.log('Offer saved to localStorage');
            } catch (e) {
                console.error('Failed to save offer to localStorage:', e);
            }

            // نمایش modal تماس ورودی فقط اگر offer معتبر باشد
            if (this.pendingOffer && this.pendingOffer.type === 'offer') {
                this.showIncomingCallModal();
            } else {
                console.error('Invalid offer received:', this.pendingOffer);
                // تلاش برای اصلاح ساختار اگر sdp موجود است اما type نیست
                if (this.pendingOffer && this.pendingOffer.sdp && !this.pendingOffer.type) {
                    console.log('Attempting to fix offer structure...');
                    this.pendingOffer.type = 'offer';
                    // آپدیت نسخه پشتیبان
                    window.lastWebRTCOffer = this.pendingOffer;
                    this.showIncomingCallModal();
                }
            }
        } catch (error) {
            console.error('خطا در پردازش offer:', error);
        }
    }

    // نمایش modal تماس ورودی
    showIncomingCallModal() {
        // بررسی اینکه آیا قبلاً تماسی فعال است یا نه
        if (this.isCallActive && this.isInitiator === false && this.pendingOffer === null) {
            return;
        }

        const modal = document.getElementById('incomingCallModal');
        if (modal) {
            // آپدیت نام تماس‌گیرنده در مودال
            const callerNameElement = modal.querySelector('.caller-name');
            if (callerNameElement && this.callerUsername) {
                callerNameElement.textContent = this.callerUsername;
            }

            const avatarElement = modal.querySelector('.caller-avatar');
            if (avatarElement && this.callerUsername) {
                avatarElement.textContent = this.callerUsername.charAt(0).toUpperCase();
            }

            // نمایش اعلان دسکتاپ
            this.showDesktopNotification(
                'تماس ورودی',
                `تماس ${this.callType === 'video' ? 'تصویری' : 'صوتی'} از طرف ${this.callerUsername || 'کاربر ناشناس'}`
            );

            // مخفی کردن modal اگر قبلاً نمایش داده شده
            modal.style.display = 'none';

            // نمایش modal با تأخیر کوتاه
            setTimeout(() => {
                modal.style.display = 'flex';

                // تنظیم نوع تماس
                const callTypeIndicator = document.getElementById('incomingCallType');
                if (callTypeIndicator) {
                    callTypeIndicator.textContent = this.callType === 'video' ? 'تماس تصویری' : 'تماس صوتی';
                }

                // شروع تایمر تماس ورودی
                this.startIncomingCallTimer();

                // پخش صدای زنگ (اختیاری)
                this.playRingtone();

                // اضافه کردن کلاس به body
                document.body.classList.add('modal-open');

                console.log('Modal تماس ورودی نمایش داده شد');
            }, 100);
        }
    }

    // شروع تایمر تماس ورودی
    startIncomingCallTimer() {
        this.incomingCallStartTime = Date.now();
        this.incomingCallTimer = setInterval(() => {
            const elapsed = Math.floor((Date.now() - this.incomingCallStartTime) / 1000);
            const minutes = Math.floor(elapsed / 60);
            const seconds = elapsed % 60;
            const timeString = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;

            const durationElement = document.getElementById('incomingCallDuration');
            if (durationElement) {
                durationElement.textContent = timeString;
            }
        }, 1000);
    }

    // توقف تایمر تماس ورودی
    stopIncomingCallTimer() {
        if (this.incomingCallTimer) {
            clearInterval(this.incomingCallTimer);
            this.incomingCallTimer = null;
        }
    }

    // پخش صدای زنگ
    playRingtone() {
        try {
            // اگر قبلاً در حال پخش است، متوقف کن
            if (this.ringtoneAudio) {
                this.ringtoneAudio.pause();
                this.ringtoneAudio = null;
            }
            if (this.audioCtx) {
                this.audioCtx.close();
                this.audioCtx = null;
            }

            // استفاده از مسیر نسبی برای فایل
            const audio = new Audio('assets/ringtone.mp3');
            audio.loop = true;

            // تلاش برای پخش
            const playPromise = audio.play();

            if (playPromise !== undefined) {
                playPromise.then(_ => {
                    this.ringtoneAudio = audio;
                    console.log('Ringtone playing from file');
                })
                    .catch(error => {
                        console.log('Autoplay prevented or file not found, falling back to AudioContext:', error);
                        this.playBeep();
                    });
            }
        } catch (error) {
            console.log('خطا در پخش زنگ فایل:', error);
            this.playBeep();
        }
    }

    // پخش صدای beep
    playBeep() {
        if (!window.AudioContext && !window.webkitAudioContext) return;

        try {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            this.audioCtx = new AudioContext();

            const oscillator = this.audioCtx.createOscillator();
            const gainNode = this.audioCtx.createGain();

            oscillator.type = 'sine';
            oscillator.frequency.setValueAtTime(440, this.audioCtx.currentTime); // A4
            oscillator.frequency.setValueAtTime(880, this.audioCtx.currentTime + 0.5); // A5

            gainNode.gain.setValueAtTime(0.1, this.audioCtx.currentTime);
            gainNode.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 1);

            oscillator.connect(gainNode);
            gainNode.connect(this.audioCtx.destination);

            oscillator.start();
            oscillator.stop(this.audioCtx.currentTime + 1);

            // تکرار
            this.beepInterval = setInterval(() => {
                if (!this.audioCtx) {
                    clearInterval(this.beepInterval);
                    return;
                }
                const osc = this.audioCtx.createOscillator();
                const gain = this.audioCtx.createGain();
                osc.type = 'sine';
                osc.frequency.setValueAtTime(440, this.audioCtx.currentTime);
                osc.frequency.setValueAtTime(880, this.audioCtx.currentTime + 0.5);
                gain.gain.setValueAtTime(0.1, this.audioCtx.currentTime);
                gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 1);
                osc.connect(gain);
                gain.connect(this.audioCtx.destination);
                osc.start();
                osc.stop(this.audioCtx.currentTime + 1);
            }, 1000); // هر 1.5 ثانیه

        } catch (e) {
            console.error('Error playing beep:', e);
        }
    }

    // توقف صدای زنگ
    stopRingtone() {
        if (this.ringtoneAudio) {
            this.ringtoneAudio.pause();
            this.ringtoneAudio.currentTime = 0;
            this.ringtoneAudio = null;
        }
        if (this.beepInterval) {
            clearInterval(this.beepInterval);
            this.beepInterval = null;
        }
        if (this.audioCtx) {
            this.audioCtx.close().catch(e => console.log(e));
            this.audioCtx = null;
        }
        console.log('Ringtone stopped');
    }

    // پذیرش تماس
    async acceptCall() {
        try {
            this.stopRingtone();
            this.stopIncomingCallTimer();

            // مخفی کردن modal تماس ورودی
            this.hideIncomingCallModal();

            this.isInitiator = false;
            this.callType = 'video'; // فرض بر تماس تصویری

            this.showCallStatus('در حال پذیرش تماس...', 'info');

            // شروع تماس برای پاسخ‌دهنده
            try {
                await this.initializeCall(true);
            } catch (error) {
                console.log('خطا در دسترسی به دوربین/میکروفون، ادامه با حالت دریافت:', error);
                await this.initializeCallReceiveOnly();
            }

            // بررسی pendingOffer قبل از استفاده
            console.log('Accepting call with pendingOffer:', this.pendingOffer);

            // بازیابی offer از متغیرهای پشتیبان اگر null شده باشد
            if (!this.pendingOffer) {
                if (window.lastWebRTCOffer) {
                    console.log('Recovering offer from window.lastWebRTCOffer');
                    this.pendingOffer = window.lastWebRTCOffer;
                } else if (this.rawOfferData || window.lastRawOfferData) {
                    console.log('Attempting to recover offer from raw data...');
                    await this.handleOffer(this.rawOfferData || window.lastRawOfferData);
                } else {
                    // تلاش برای بازیابی از localStorage
                    try {
                        const stored = localStorage.getItem('webrtc_pending_offer');
                        if (stored) {
                            this.pendingOffer = JSON.parse(stored);
                            console.log('Recovered offer from localStorage');
                        }
                    } catch (e) {
                        console.error('Failed to recover from localStorage:', e);
                    }
                }
            }

            // اگر به هر دلیلی pendingOffer رشته است، دوباره پارس کن
            if (typeof this.pendingOffer === 'string') {
                try {
                    this.pendingOffer = JSON.parse(this.pendingOffer);
                    // چک برای دابل انکودینگ
                    if (typeof this.pendingOffer === 'string') {
                        this.pendingOffer = JSON.parse(this.pendingOffer);
                    }
                    console.log('Reparsed pendingOffer string inside acceptCall');
                } catch (e) {
                    console.error('Failed to reparse pendingOffer inside acceptCall:', e);
                }
            }

            if (!this.pendingOffer || !this.pendingOffer.type) {
                console.error('Invalid pendingOffer state:', this.pendingOffer);
                throw new Error('پیشنهاد تماس نامعتبر است یا وجود ندارد. (Data: ' + JSON.stringify(this.pendingOffer) + ')');
            }

            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(this.pendingOffer));
            console.log('Remote description (offer) set successfully in acceptCall');

            // پردازش کاندیداهای صف شده (فقط یکبار)
            await this.processQueuedCandidates();

            // ساخت answer
            const answer = await this.peerConnection.createAnswer();
            await this.peerConnection.setLocalDescription(answer);
            console.log('Local description (answer) set successfully');

            // ارسال answer
            this.sendSignal('answer', JSON.stringify(answer));

            // حالا که کار تمام شد مودال را مخفی کن
            this.hideIncomingCallModal();

            this.showCallStatus('تماس برقرار شد', 'success');
            this.startCallTimer();

            // اطمینان از نمایش کامل modal بعد از پذیرش
            setTimeout(() => {
                this.ensureFullCallDisplay();
            }, 500);

        } catch (error) {
            console.error('خطا در پذیرش تماس:', error);
            this.showCallStatus('خطا در پذیرش تماس: ' + error.message, 'error');
            // قطع تماس با تأخیر برای دیدن خطا
            setTimeout(() => this.endCall(), 3000);
        }
    }

    // پذیرش تماس فقط با صدا
    async acceptCallAudioOnly() {
        try {
            this.stopRingtone();
            this.stopIncomingCallTimer();

            // مخفی کردن modal تماس ورودی
            this.hideIncomingCallModal();

            this.isInitiator = false;
            this.callType = 'audio'; // تماس صوتی

            this.showCallStatus('در حال پذیرش تماس صوتی...', 'info');

            // شروع تماس صوتی برای پاسخ‌دهنده
            try {
                await this.initializeCall(false); // بدون ویدیو
            } catch (error) {
                console.log('خطا در دسترسی به میکروفون، ادامه با حالت دریافت:', error);
                await this.initializeCallReceiveOnly();
            }

            // بررسی pendingOffer قبل از استفاده
            // بازیابی offer از متغیرهای پشتیبان اگر null شده باشد
            if (!this.pendingOffer) {
                if (window.lastWebRTCOffer) {
                    console.log('Recovering offer from window.lastWebRTCOffer (AudioOnly)');
                    this.pendingOffer = window.lastWebRTCOffer;
                } else if (this.rawOfferData || window.lastRawOfferData) {
                    console.log('Attempting to recover offer from raw data (AudioOnly)...');
                    await this.handleOffer(this.rawOfferData || window.lastRawOfferData);
                } else {
                    // تلاش برای بازیابی از localStorage
                    try {
                        const stored = localStorage.getItem('webrtc_pending_offer');
                        if (stored) {
                            this.pendingOffer = JSON.parse(stored);
                            console.log('Recovered offer from localStorage (AudioOnly)');
                        }
                    } catch (e) {
                        console.error('Failed to recover from localStorage:', e);
                    }
                }
            }

            // اگر به هر دلیلی pendingOffer رشته است، دوباره پارس کن
            if (typeof this.pendingOffer === 'string') {
                try {
                    this.pendingOffer = JSON.parse(this.pendingOffer);
                    if (typeof this.pendingOffer === 'string') {
                        this.pendingOffer = JSON.parse(this.pendingOffer);
                    }
                } catch (e) {
                    console.error('Failed to reparse pendingOffer inside acceptCallAudioOnly:', e);
                }
            }

            if (!this.pendingOffer || !this.pendingOffer.type) {
                console.error('Invalid pendingOffer state (AudioOnly):', this.pendingOffer);
                throw new Error('پیشنهاد تماس نامعتبر است یا وجود ندارد.');
            }

            await this.peerConnection.setRemoteDescription(new RTCSessionDescription(this.pendingOffer));

            // ساخت answer
            const answer = await this.peerConnection.createAnswer();
            await this.peerConnection.setLocalDescription(answer);

            // ارسال answer
            this.sendSignal('answer', JSON.stringify(answer));

            // حالا که کار تمام شد مودال را مخفی کن
            this.hideIncomingCallModal();

            this.showCallStatus('تماس صوتی برقرار شد', 'success');
            this.startCallTimer();

            // اطمینان از نمایش کامل modal بعد از پذیرش
            setTimeout(() => {
                this.ensureFullCallDisplay();
            }, 500);

        } catch (error) {
            console.error('خطا در پذیرش تماس صوتی:', error);
            this.showCallStatus('خطا در پذیرش تماس', 'error');
            this.endCall();
        }
    }

    // رد تماس
    rejectCall() {
        this.stopRingtone();
        this.stopIncomingCallTimer();

        // مخفی کردن modal تماس ورودی
        this.hideIncomingCallModal();

        // ارسال سیگنال رد تماس
        this.sendSignal('reject', 'declined');

        this.showCallStatus('تماس رد شد', 'info');
    }

    // مخفی کردن modal تماس ورودی
    hideIncomingCallModal() {
        const modal = document.getElementById('incomingCallModal');
        if (modal) {
            modal.style.display = 'none';
            modal.style.opacity = '0';
            modal.style.visibility = 'hidden';
        }
        document.body.classList.remove('modal-open');
        console.log('Modal تماس ورودی مخفی شد');
    }

    // بستن کامل تماس (برای رد یا قطع شدن)
    forceCloseCall() {
        console.log('forceCloseCall called - clearing state');

        // توقف نگهدارنده modal
        this.stopModalKeeper();

        // پاک کردن بکاپ localStorage
        localStorage.removeItem('webrtc_pending_offer');

        // توقف تمام تایمرها
        this.stopCallTimer();
        this.stopIncomingCallTimer();
        this.stopRingtone();

        // بستن streams
        if (this.localStream) {
            this.localStream.getTracks().forEach(track => track.stop());
            this.localStream = null;
        }

        // بستن peer connection
        if (this.peerConnection) {
            try {
                this.peerConnection.close();
            } catch (e) { }
            this.peerConnection = null;
        }

        // پاک کردن remote stream
        this.remoteStream = null;

        // مخفی کردن تمام modals
        this.hideIncomingCallModal();

        const videoModal = document.getElementById('videoCallModal');
        if (videoModal) {
            videoModal.classList.remove('active', 'minimized', 'fullscreen');
            videoModal.setAttribute('style', 'display: none !important; visibility: hidden !important; opacity: 0 !important;');

            const callChatSection = document.getElementById('callChatSection');
            if (callChatSection) callChatSection.style.display = 'none';
        }

        // پاک کردن video elements
        const localVideo = document.getElementById('localVideo');
        const remoteVideo = document.getElementById('remoteVideo');
        if (localVideo) localVideo.srcObject = null;
        if (remoteVideo) remoteVideo.srcObject = null;

        // حذف کلاس modal-open
        document.body.classList.remove('modal-open');
        document.body.style.overflow = '';

        // ریست متغیرها
        this.isCallActive = false;
        this.isMuted = false;
        this.isVideoOff = false;
        this.isInitiator = false;
        this.callStartTime = null;
        this.pendingOffer = null;
        this.isMinimized = false;
        this.isFullscreen = false;
        this.isRecording = false;
        this.isScreenSharing = false;
        this.isSpeakerOn = true;
        this.iceCandidatesQueue = []; // خالی کردن صف

        // ریست کردن دکمه‌ها
        this.resetCallButtons();

        const titleElement = document.getElementById('callTitle');
        if (titleElement) titleElement.textContent = 'تماس';

        console.log('تماس به طور کامل بسته شد');
    }

    // پردازش answer دریافتی
    async handleAnswer(answerData) {
        try {
            console.log('Processing answer signal, current signalingState:', this.peerConnection?.signalingState);
            // قطع صدای زنگ
            this.stopRingtone();

            if (!this.peerConnection) {
                console.error('PeerConnection does not exist in handleAnswer');
                return;
            }

            let answer;
            if (typeof answerData === 'string') {
                try {
                    answer = JSON.parse(answerData);
                    // چک برای دابل انکودینگ
                    if (typeof answer === 'string') {
                        answer = JSON.parse(answer);
                    }
                } catch (e) {
                    console.error('Error parsing answer data:', e);
                    return;
                }
            } else {
                answer = answerData;
            }

            console.log('Parsed answer:', answer?.type, 'signalingState:', this.peerConnection.signalingState);

            // باید در حالت have-local-offer باشد تا answer رو بپذیره
            if (this.peerConnection.signalingState === 'have-local-offer') {
                await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
                console.log('Remote description (answer) set successfully');

                // پردازش کاندیداهای صف شده
                await this.processQueuedCandidates();
            } else if (this.peerConnection.signalingState === 'stable') {
                console.log('Already stable, answer may have been processed already');
            } else {
                console.warn('Unexpected signalingState for answer:', this.peerConnection.signalingState);
                // تلاش برای ست کردن به هر حال
                try {
                    await this.peerConnection.setRemoteDescription(new RTCSessionDescription(answer));
                    console.log('Remote description (answer) set despite unexpected state');
                    await this.processQueuedCandidates();
                } catch (innerError) {
                    console.error('Failed to set answer in unexpected state:', innerError);
                }
            }
        } catch (error) {
            console.error('خطا در پردازش answer:', error);
            this.showCallStatus('خطا در برقراری ارتباط', 'error');
        }
    }

    // پردازش ICE candidate دریافتی
    async handleIceCandidate(candidateData) {
        try {
            if (!candidateData) return;

            const candidate = typeof candidateData === 'string' ? JSON.parse(candidateData) : candidateData;

            // اگر هنوز PeerConnection ساخته نشده یا RemoteDescription تنظیم نشده، در صف قرار بده
            // این حالت زمانی رخ می‌دهد که کاندیداها قبل از Offer/Answer یا قبل از زدن دکمه Accept برسند
            if (!this.peerConnection || !this.peerConnection.remoteDescription) {
                console.log('Queuing ICE candidate (connection or remote description not ready)');
                this.iceCandidatesQueue.push(candidate);
                return;
            }

            await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
        } catch (error) {
            console.error('خطا در پردازش ICE candidate:', error);
        }
    }

    // پردازش کاندیداهای موجود در صف
    async processQueuedCandidates() {
        if (!this.peerConnection || !this.peerConnection.remoteDescription || this.iceCandidatesQueue.length === 0) {
            return;
        }

        console.log(`Processing ${this.iceCandidatesQueue.length} queued ICE candidates`);

        while (this.iceCandidatesQueue.length > 0) {
            const candidate = this.iceCandidatesQueue.shift();
            try {
                await this.peerConnection.addIceCandidate(new RTCIceCandidate(candidate));
            } catch (error) {
                console.error('Error adding queued ICE candidate:', error);
            }
        }
    }

    // ارسال سیگنال
    sendSignal(type, data, toUserId = null) {
        const targetId = toUserId || this.targetUserId;
        if (!targetId || targetId <= 0) {
            console.error('شناسه کاربر مقصد نامعتبر است');
            return;
        }

        // استفاده از keepalive برای اطمینان از ارسال سیگنال هنگام بسته شدن صفحه
        // نکته: برای keepalive محدودیت حجم وجود دارد (64KB)
        const options = {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `to_user_id=${targetId}&signal_type=${type}&signal_data=${encodeURIComponent(data)}`,
            keepalive: true
        };

        // برای اطمینان بیشتر در هنگام بستن صفحه، از navigator.sendBeacon استفاده می‌کنیم اگر موجود باشد
        // اما چون sendBeacon فرمت application/x-www-form-urlencoded را به سختی پشتیبانی می‌کند (نیاز به Blob دارد)
        // و fetch keepalive مدرن‌تر است، همان fetch را نگه می‌داریم ولی لاگ می‌کنیم

        console.log(`Sending signal ${type} to ${targetId} (keepalive: true)`);

        fetch('api/send_signal.php', options)
            .then(response => response.json())
            .then(result => {
                if (!result.success) {
                    console.error('خطا در ارسال سیگنال:', result.message);
                }
            })
            .catch(error => {
                console.error('خطا در ارسال سیگنال:', error);
            });
    }

    // تنظیم سرعت polling بر اساس وضعیت
    setPollingSpeed(state) {
        if (this.signalingInterval) {
            clearInterval(this.signalingInterval);
        }
        let interval;
        if (state === 'calling') {
            interval = 500; // سریع‌تر هنگام تماس
        } else if (state === 'connected') {
            interval = 2000; // آهسته‌تر بعد از اتصال
        } else {
            interval = 1000; // پیش‌فرض
        }
        this.signalingInterval = setInterval(() => {
            this.checkForSignals();
        }, interval);
        console.log('Polling speed set to', interval, 'ms for state:', state);
    }

    // پاکسازی سیگنال‌های قدیمی قبل از شروع تماس جدید
    async cleanupOldSignals() {
        try {
            await fetch('api/cleanup_signals.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: `target_user_id=${this.targetUserId}`
            });
            console.log('Old signals cleaned up');
        } catch (e) {
            console.log('Signal cleanup failed (non-critical):', e);
        }
    }

    // شروع polling برای دریافت سیگنال‌ها
    startSignalingPolling() {
        this.checkForSignals(); // دریافت فوری
        this.signalingInterval = setInterval(() => {
            this.checkForSignals();
        }, 1000); // هر 1 ثانیه (پیش‌فرض)
    }

    // چک کردن سیگنال‌های جدید
    checkForSignals() {
        // همیشه برای تمام سیگنال‌های جدید کوئری می‌زنیم تا تماس‌های سراسری را دریافت کنیم
        fetch('api/get_signal.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: `from_user_id=0`
        })
            .then(response => response.json())
            .then(data => {
                if (data.success && data.signals.length > 0) {
                    data.signals.forEach(signal => {
                        this.processSignal(signal);
                    });
                }
            })
            .catch(error => {
                console.error('خطا در دریافت سیگنال‌ها:', error);
            });
    }

    // پردازش سیگنال دریافتی
    async processSignal(signal) {
        console.log('Processing signal:', signal.signal_type, 'from:', signal.from_username);

        // هدایت سیگنال‌های گروهی به منیجر مربوطه
        if (signal.signal_type.startsWith('group-') && window.groupCallManager) {
            window.groupCallManager.processSignal(signal);
            return;
        }

        switch (signal.signal_type) {
            case 'offer':
                if (this.isCallActive) {
                    // تماس در حال انجام - رد کردن offer جدید برای کاربر دیگر
                    this.sendSignal('reject', 'busy', signal.from_user_id);
                    return;
                }
                // تنظیم اطلاعات تماس‌گیرنده
                this.targetUserId = signal.from_user_id;
                this.callerUsername = signal.from_username;
                // افزایش سرعت polling برای تبادل سریع سیگنال‌ها
                this.setPollingSpeed('calling');
                await this.handleOffer(signal.signal_data);
                break;
            case 'answer':
                if (signal.from_user_id == this.targetUserId) {
                    console.log('Received answer from target user, processing...');
                    // افزایش سرعت polling برای ICE candidates
                    this.setPollingSpeed('calling');
                    await this.handleAnswer(signal.signal_data);
                }
                break;
            case 'ice':
                if (signal.from_user_id == this.targetUserId) {
                    await this.handleIceCandidate(signal.signal_data);
                }
                break;
            case 'reject':
                if (signal.from_user_id == this.targetUserId) {
                    this.handleReject(signal.signal_data);
                }
                break;
            case 'end': {
                // برای قطع تماس، یا باید از طرف مقابل اصلی باشد یا اگر در حال رینگ زدن هستیم
                const incomingModal = document.getElementById('incomingCallModal');
                const isRinging = incomingModal && incomingModal.style.display === 'flex';
                if (signal.from_user_id == this.targetUserId || isRinging) {
                    if (this.isCallActive || isRinging) {
                        this.handleCallEnd();
                    }
                }
                break;
            }
            default:
                console.log('Unknown signal type:', signal.signal_type);
        }
    }

    // مدیریت رد تماس
    handleReject(reason) {
        if (reason === 'busy') {
            this.showCallStatus('کاربر مشغول است', 'warning');
        } else if (reason === 'declined') {
            this.showCallStatus('تماس رد شد', 'warning');
        } else {
            this.showCallStatus('تماس رد شد', 'warning');
        }

        // بستن فوری صفحه تماس
        setTimeout(() => {
            this.forceCloseCall();
        }, 1500); // نمایش پیام برای 1.5 ثانیه سپس بستن فوری
    }

    // مدیریت قطع تماس
    handleCallEnd() {
        const incomingModal = document.getElementById('incomingCallModal');
        const isRinging = incomingModal && incomingModal.style.display === 'flex';
        if (!this.isCallActive && !isRinging) {
            return;
        }

        console.log('handleCallEnd: Call ended by remote');
        this.showCallStatus('تماس از طرف مقابل قطع شد', 'info');

        // بستن فوری صفحه تماس
        setTimeout(() => {
            this.forceCloseCall();
        }, 1500);
    }

    // خاموش/روشن کردن میکروفون
    toggleMute() {
        if (this.localStream) {
            const audioTrack = this.localStream.getAudioTracks()[0];
            if (audioTrack) {
                audioTrack.enabled = !audioTrack.enabled;
                this.isMuted = !audioTrack.enabled;

                const muteBtn = document.getElementById('muteBtn');
                if (muteBtn) {
                    if (this.isMuted) {
                        muteBtn.innerHTML = '🔇';
                        muteBtn.classList.add('muted');
                        muteBtn.title = 'روشن کردن میکروفون';
                        this.showCallStatus('میکروفون خاموش شد', 'warning');
                    } else {
                        muteBtn.innerHTML = '🎤';
                        muteBtn.classList.remove('muted');
                        muteBtn.title = 'خاموش کردن میکروفون';
                        this.showCallStatus('میکروفون روشن شد', 'success');
                    }
                }
            } else {
                this.showCallStatus('میکروفون در دسترس نیست', 'error');
            }
        } else {
            this.showCallStatus('هیچ stream فعالی وجود ندارد', 'error');
        }
    }

    // خاموش/روشن کردن دوربین
    toggleVideo() {
        if (this.localStream) {
            const videoTrack = this.localStream.getVideoTracks()[0];
            if (videoTrack) {
                videoTrack.enabled = !videoTrack.enabled;
                this.isVideoOff = !videoTrack.enabled;

                const videoBtn = document.getElementById('videoBtn');
                if (videoBtn) {
                    if (this.isVideoOff) {
                        videoBtn.innerHTML = '📷';
                        videoBtn.classList.add('muted');
                        videoBtn.title = 'روشن کردن دوربین';
                        this.showCallStatus('دوربین خاموش شد', 'warning');
                    } else {
                        videoBtn.innerHTML = '📹';
                        videoBtn.classList.remove('muted');
                        videoBtn.title = 'خاموش کردن دوربین';
                        this.showCallStatus('دوربین روشن شد', 'success');
                    }
                }
            } else {
                this.showCallStatus('دوربین در دسترس نیست', 'error');
            }
        } else {
            this.showCallStatus('هیچ stream فعالی وجود ندارد', 'error');
        }
    }

    // نمایش modal تماس
    showCallModal() {
        const modal = document.getElementById('videoCallModal');
        if (!modal) return;

        // اطمینان از نمایش (استفاده از !important برای اطمینان کامل)
        modal.classList.add('active');
        modal.setAttribute('style', 'display: flex !important; visibility: visible !important; opacity: 1 !important; position: fixed; top: 0; left: 0; right: 0; bottom: 0; width: 100%; height: 100%; z-index: 2147483647;');

        modal.classList.remove('minimized', 'fullscreen');
        this.isMinimized = false;
        this.isFullscreen = false;

        // نمایش قسمت چت در حین تماس
        const callChatSection = document.getElementById('callChatSection');
        if (callChatSection) {
            callChatSection.style.display = 'block';
        }

        // اضافه کردن کلاس به body برای جلوگیری از اسکرول
        document.body.classList.add('modal-open');

        this.updateCallControls();

        // فوکوس روی modal
        modal.focus();

        console.log('Call modal shown - active class added, isCallActive:', this.isCallActive);

        // اطمینان از نمایش مداوم تا زمانی که تماس فعال است
        // این کد از بسته شدن تصادفی modal جلوگیری می‌کند
        if (this.isCallActive && this.isInitiator) {
            setTimeout(() => {
                if (this.isCallActive && modal.style.display !== 'flex') {
                    console.log('Re-showing call modal after timeout');
                    this.showCallModal();
                }
            }, 1000);
        }
    }

    // اطمینان از نمایش کامل تماس
    ensureFullCallDisplay() {
        const modal = document.getElementById('videoCallModal');

        // شرط بررسی active بودن را برمی‌داریم تا همیشه اجرا شود
        // چون ممکن است کلاس active به دلیلی پریده باشد
        if (modal) {
            console.log('Ensuring full call display...');

            // اطمینان از فعال بودن
            if (!modal.classList.contains('active') || modal.style.display === 'none') {
                console.log('Modal was hidden/inactive, forcing show');
                modal.classList.add('active');
                modal.style.display = 'flex';
                modal.style.visibility = 'visible';
                modal.style.opacity = '1';
            }

            // اطمینان از حالت عادی (نه کوچک و نه تمام صفحه)
            modal.classList.remove('minimized', 'fullscreen');

            // تنظیم استایل‌های کامل با اولویت بالا
            modal.setAttribute('style', 'display: flex !important; visibility: visible !important; opacity: 1 !important; position: fixed; top: 0; left: 0; right: 0; bottom: 0; width: 100%; height: 100%; z-index: 2147483647;');

            this.isMinimized = false;
            this.isFullscreen = false;

            // اضافه کردن کلاس modal-open
            document.body.classList.add('modal-open');

            // بروزرسانی کنترل‌ها
            this.updateCallControls();

            console.log('Call display ensured to be full size and visible');
        }
    }

    // تغییر وضعیت کوچک/بزرگ کردن (Toggle)
    toggleMinimize() {
        const modal = document.getElementById('videoCallModal');
        if (!modal) return;

        const btn = modal.querySelector('.minimize-btn');

        if (this.isMinimized) {
            this.maximizeCall();
            if (btn) {
                btn.innerHTML = '&#x2212;'; // Minus sign
                btn.title = 'کوچک کردن';
            }
        } else {
            this.minimizeCall();
            if (btn) {
                btn.innerHTML = '&#x26F6;'; // Square/Expand like icon
                btn.title = 'بزرگ کردن';
            }
        }
    }

    // بزرگ کردن تماس (برگشت به حالت عادی)
    maximizeCall() {
        this.ensureFullCallDisplay();
    }

    // کوچک کردن تماس (نمایش در سایدبار)
    minimizeCall() {
        const modal = document.getElementById('videoCallModal');

        if (!modal) return;

        modal.classList.add('minimized');
        modal.classList.remove('fullscreen');

        // تنظیم استایل‌های مخصوص حالت کوچک با !important
        modal.setAttribute('style', 'display: flex !important; position: fixed !important; bottom: 20px !important; right: 20px !important; left: auto !important; top: auto !important; width: 300px !important; max-width: 90vw !important; height: 450px !important; max-height: 60vh !important; z-index: 2147483647 !important; opacity: 1 !important; visibility: visible !important;');

        this.isMinimized = true;
        this.isFullscreen = false;

        // حذف کلاس modal-open از body تا بتوان با صفحه کار کرد
        document.body.classList.remove('modal-open');

        console.log('Call minimized');
        this.updateCallControls();
    }

    // تمام صفحه کردن تماس
    toggleFullscreen() {
        const modal = document.getElementById('videoCallModal');

        if (this.isFullscreen) {
            // خروج از حالت تمام صفحه
            modal.classList.remove('fullscreen');
            modal.classList.remove('minimized');

            // بازگردانی استایل‌های عادی
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.right = '0';
            modal.style.bottom = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';

            this.isFullscreen = false;
            this.isMinimized = false;
        } else {
            // ورود به حالت تمام صفحه
            modal.classList.add('fullscreen');
            modal.classList.remove('minimized');

            // تنظیم استایل‌های تمام صفحه
            modal.style.position = 'fixed';
            modal.style.top = '0';
            modal.style.left = '0';
            modal.style.right = '0';
            modal.style.bottom = '0';
            modal.style.width = '100%';
            modal.style.height = '100%';

            this.isFullscreen = true;
            this.isMinimized = false;
        }

        // اطمینان از modal-open در هر دو حالت
        document.body.classList.add('modal-open');

        this.updateCallControls();
    }

    // تغییر کیفیت تصویر
    async changeVideoQuality(quality) {
        if (!['240p', '360p', '480p'].includes(quality)) return;

        this.videoQuality = quality;

        if (this.localStream && this.callType === 'video') {
            try {
                // توقف track فعلی
                const videoTrack = this.localStream.getVideoTracks()[0];
                if (videoTrack) {
                    videoTrack.stop();
                }

                // دریافت stream جدید با کیفیت جدید
                const newStream = await navigator.mediaDevices.getUserMedia({
                    video: {
                        ...this.videoConstraints[quality],
                        facingMode: 'user'
                    },
                    audio: false
                });

                // جایگزینی track
                const newVideoTrack = newStream.getVideoTracks()[0];
                const sender = this.peerConnection.getSenders().find(s =>
                    s.track && s.track.kind === 'video'
                );

                if (sender && newVideoTrack) {
                    await sender.replaceTrack(newVideoTrack);

                    // بروزرسانی local stream
                    this.localStream.removeTrack(videoTrack);
                    this.localStream.addTrack(newVideoTrack);

                    // بروزرسانی local video
                    const localVideo = document.getElementById('localVideo');
                    localVideo.srcObject = this.localStream;

                    this.showCallStatus(`کیفیت تصویر به ${quality} تغییر یافت`, 'success');
                }

            } catch (error) {
                console.error('خطا در تغییر کیفیت:', error);
                this.showCallStatus('خطا در تغییر کیفیت تصویر', 'error');
            }
        }
    }

    // ضبط تماس
    toggleRecording() {
        if (!this.isRecording) {
            this.startRecording();
        } else {
            this.stopRecording();
        }
    }

    // شروع ضبط
    async startRecording() {
        try {
            if (!this.localStream && !this.remoteStream) {
                this.showCallStatus('هیچ stream فعالی برای ضبط وجود ندارد', 'error');
                return;
            }

            // ترکیب local و remote streams
            const audioContext = new AudioContext();
            const destination = audioContext.createMediaStreamDestination();

            if (this.localStream) {
                const localAudio = audioContext.createMediaStreamSource(this.localStream);
                localAudio.connect(destination);
            }

            if (this.remoteStream) {
                const remoteAudio = audioContext.createMediaStreamSource(this.remoteStream);
                remoteAudio.connect(destination);
            }

            this.mediaRecorder = new MediaRecorder(destination.stream);
            this.recordedChunks = [];

            this.mediaRecorder.ondataavailable = (event) => {
                if (event.data.size > 0) {
                    this.recordedChunks.push(event.data);
                }
            };

            this.mediaRecorder.onstop = () => {
                const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
                const url = URL.createObjectURL(blob);

                // دانلود فایل ضبط شده
                const a = document.createElement('a');
                a.href = url;
                a.download = `call-recording-${new Date().toISOString().slice(0, 19)}.webm`;
                a.click();

                URL.revokeObjectURL(url);
                this.showCallStatus('ضبط تماس ذخیره شد', 'success');
            };

            this.mediaRecorder.start();
            this.isRecording = true;

            // بروزرسانی دکمه
            const recordBtn = document.querySelector('.record-btn');
            if (recordBtn) {
                recordBtn.innerHTML = '⏹️';
                recordBtn.title = 'توقف ضبط';
                recordBtn.classList.add('recording');
            }

            this.showCallStatus('ضبط تماس شروع شد', 'info');

        } catch (error) {
            console.error('خطا در شروع ضبط:', error);
            this.showCallStatus('خطا در شروع ضبط تماس', 'error');
        }
    }

    // توقف ضبط
    stopRecording() {
        if (this.mediaRecorder && this.isRecording) {
            this.mediaRecorder.stop();
            this.isRecording = false;

            // بروزرسانی دکمه
            const recordBtn = document.querySelector('.record-btn');
            if (recordBtn) {
                recordBtn.innerHTML = '⏺️';
                recordBtn.title = 'ضبط تماس';
                recordBtn.classList.remove('recording');
            }

            this.showCallStatus('ضبط تماس متوقف شد', 'info');
        }
    }

    // اشتراک صفحه
    async toggleScreenShare() {
        if (!this.isScreenSharing) {
            await this.startScreenShare();
        } else {
            await this.stopScreenShare();
        }
    }

    // شروع اشتراک صفحه
    async startScreenShare() {
        try {
            const screenStream = await navigator.mediaDevices.getDisplayMedia({
                video: true,
                audio: true
            });

            // جایگزینی video track
            const videoTrack = screenStream.getVideoTracks()[0];
            const sender = this.peerConnection.getSenders().find(s =>
                s.track && s.track.kind === 'video'
            );

            if (sender && videoTrack) {
                await sender.replaceTrack(videoTrack);

                // ذخیره track قبلی
                this.originalVideoTrack = this.localStream.getVideoTracks()[0];

                // بروزرسانی local video
                const localVideo = document.getElementById('localVideo');
                localVideo.srcObject = screenStream;

                this.isScreenSharing = true;

                // بروزرسانی دکمه
                const screenshareBtn = document.querySelector('.screenshare-btn');
                if (screenshareBtn) {
                    screenshareBtn.innerHTML = '📱';
                    screenshareBtn.title = 'توقف اشتراک صفحه';
                    screenshareBtn.classList.add('sharing');
                }

                this.showCallStatus('اشتراک صفحه شروع شد', 'success');

                // گوش دادن به توقف اشتراک صفحه
                videoTrack.onended = () => {
                    this.stopScreenShare();
                };
            }

        } catch (error) {
            console.error('خطا در اشتراک صفحه:', error);
            this.showCallStatus('خطا در اشتراک صفحه', 'error');
        }
    }

    // توقف اشتراک صفحه
    async stopScreenShare() {
        try {
            if (this.originalVideoTrack) {
                const sender = this.peerConnection.getSenders().find(s =>
                    s.track && s.track.kind === 'video'
                );

                if (sender) {
                    await sender.replaceTrack(this.originalVideoTrack);

                    // بازگردانی local video
                    const localVideo = document.getElementById('localVideo');
                    localVideo.srcObject = this.localStream;
                }
            }

            this.isScreenSharing = false;

            // بروزرسانی دکمه
            const screenshareBtn = document.querySelector('.screenshare-btn');
            if (screenshareBtn) {
                screenshareBtn.innerHTML = '🖥️';
                screenshareBtn.title = 'اشتراک صفحه';
                screenshareBtn.classList.remove('sharing');
            }

            this.showCallStatus('اشتراک صفحه متوقف شد', 'info');

        } catch (error) {
            console.error('خطا در توقف اشتراک صفحه:', error);
            this.showCallStatus('خطا در توقف اشتراک صفحه', 'error');
        }
    }

    // تغییر حالت بلندگو
    toggleSpeaker() {
        if (this.remoteStream) {
            const remoteVideo = document.getElementById('remoteVideo');

            if (!this.isSpeakerOn) {
                // روشن کردن بلندگو
                remoteVideo.volume = 1.0;
                this.isSpeakerOn = true;

                const speakerBtn = document.querySelector('.speaker-btn');
                if (speakerBtn) {
                    speakerBtn.innerHTML = '🔊';
                    speakerBtn.title = 'خاموش کردن بلندگو';
                    speakerBtn.classList.add('active');
                }

                this.showCallStatus('بلندگو روشن شد', 'success');
            } else {
                // خاموش کردن بلندگو
                remoteVideo.volume = 0.5;
                this.isSpeakerOn = false;

                const speakerBtn = document.querySelector('.speaker-btn');
                if (speakerBtn) {
                    speakerBtn.innerHTML = '🔉';
                    speakerBtn.title = 'روشن کردن بلندگو';
                    speakerBtn.classList.remove('active');
                }

                this.showCallStatus('بلندگو خاموش شد', 'info');
            }
        }
    }

    // بروزرسانی کنترل‌های تماس
    updateCallControls() {
        const modal = document.getElementById('videoCallModal');
        const controls = modal.querySelector('.call-controls');

        if (!controls) return;

        if (this.isMinimized) {
            // مخفی کردن تمام دکمه‌ها ابتدا
            const allBtns = controls.querySelectorAll('.call-control-btn');
            allBtns.forEach(btn => btn.style.display = 'none');

            // اضافه کردن یا نمایش دکمه بزرگ کردن
            let maximizeBtn = controls.querySelector('.maximize-btn');
            if (!maximizeBtn) {
                maximizeBtn = document.createElement('button');
                maximizeBtn.className = 'call-control-btn maximize-btn';
                maximizeBtn.innerHTML = '⬆️';
                maximizeBtn.title = 'بازگشت به حالت عادی';
                maximizeBtn.onclick = () => this.maximizeCall();
                controls.insertBefore(maximizeBtn, controls.firstChild);
            }
            maximizeBtn.style.display = 'flex';

            // نمایش دکمه قطع تماس
            const endBtn = controls.querySelector('.danger');
            if (endBtn) {
                endBtn.style.display = 'flex';
            }
        } else {
            // نمایش تمام دکمه‌ها در حالت عادی
            const allBtns = controls.querySelectorAll('.call-control-btn');
            allBtns.forEach(btn => {
                if (!btn.classList.contains('maximize-btn')) {
                    btn.style.display = 'flex';
                }
            });

            // مخفی کردن دکمه بزرگ کردن
            const maximizeBtn = controls.querySelector('.maximize-btn');
            if (maximizeBtn) {
                maximizeBtn.style.display = 'none';
            }

            // اضافه کردن دکمه‌های کنترل کامل اگر وجود ندارند
            if (!controls.querySelector('.minimize-btn')) {
                const minimizeBtn = document.createElement('button');
                minimizeBtn.className = 'call-control-btn minimize-btn';
                minimizeBtn.innerHTML = '🔽';
                minimizeBtn.title = 'کوچک کردن';
                minimizeBtn.onclick = () => this.minimizeCall();

                const fullscreenBtn = document.createElement('button');
                fullscreenBtn.className = 'call-control-btn fullscreen-btn';
                fullscreenBtn.innerHTML = this.isFullscreen ? '🔳' : '⛶';
                fullscreenBtn.title = this.isFullscreen ? 'خروج از تمام صفحه' : 'تمام صفحه';
                fullscreenBtn.onclick = () => this.toggleFullscreen();

                const qualityBtn = document.createElement('button');
                qualityBtn.className = 'call-control-btn quality-btn';
                qualityBtn.innerHTML = '⚙️';
                qualityBtn.title = 'تنظیمات کیفیت';
                qualityBtn.onclick = () => this.showQualityMenu();

                const chatBtn = document.createElement('button');
                chatBtn.className = 'call-control-btn chat-btn';
                chatBtn.innerHTML = '💬';
                chatBtn.title = 'چت در حین تماس';
                chatBtn.onclick = () => this.toggleCallChat();

                const recordBtn = document.createElement('button');
                recordBtn.className = 'call-control-btn record-btn';
                recordBtn.innerHTML = '⏺️';
                recordBtn.title = 'ضبط تماس';
                recordBtn.onclick = () => this.toggleRecording();

                const screenshareBtn = document.createElement('button');
                screenshareBtn.className = 'call-control-btn screenshare-btn';
                screenshareBtn.innerHTML = '🖥️';
                screenshareBtn.title = 'اشتراک صفحه';
                screenshareBtn.onclick = () => this.toggleScreenShare();

                const speakerBtn = document.createElement('button');
                speakerBtn.className = 'call-control-btn speaker-btn';
                speakerBtn.innerHTML = '🔊';
                speakerBtn.title = 'بلندگو';
                speakerBtn.onclick = () => this.toggleSpeaker();

                // اضافه کردن دکمه‌ها به ترتیب
                controls.appendChild(chatBtn);
                controls.appendChild(recordBtn);
                controls.appendChild(screenshareBtn);
                controls.appendChild(speakerBtn);
                controls.appendChild(minimizeBtn);
                controls.appendChild(fullscreenBtn);
                controls.appendChild(qualityBtn);
            }
        }

        // بروزرسانی دکمه تمام صفحه
        const fullscreenBtn = controls.querySelector('.fullscreen-btn');
        if (fullscreenBtn) {
            fullscreenBtn.innerHTML = this.isFullscreen ? '🔳' : '⛶';
            fullscreenBtn.title = this.isFullscreen ? 'خروج از تمام صفحه' : 'تمام صفحه';
        }
    }

    // تغییر وضعیت چت در حین تماس
    toggleCallChat() {
        const chatSection = document.getElementById('callChatSection');
        const chatBtn = document.querySelector('.chat-btn');

        if (chatSection && chatBtn) {
            if (chatSection.style.display === 'none' || !chatSection.style.display) {
                chatSection.style.display = 'block';
                chatBtn.classList.add('active');
                chatBtn.title = 'مخفی کردن چت';
            } else {
                chatSection.style.display = 'none';
                chatBtn.classList.remove('active');
                chatBtn.title = 'نمایش چت';
            }
        }
    }

    // نمایش منوی کیفیت
    showQualityMenu() {
        const qualities = ['240p', '360p', '480p'];
        const currentQuality = this.videoQuality;

        let menu = `
            <div class="quality-menu">
                <h4>انتخاب کیفیت تصویر</h4>
        `;

        qualities.forEach(quality => {
            const selected = quality === currentQuality ? 'selected' : '';
            menu += `
                <button class="quality-option ${selected}" onclick="webrtcManager.changeVideoQuality('${quality}')">
                    ${quality} ${quality === currentQuality ? '✓' : ''}
                </button>
            `;
        });

        menu += '</div>';

        // نمایش منو
        const existingMenu = document.querySelector('.quality-menu');
        if (existingMenu) {
            existingMenu.remove();
        }

        const modal = document.getElementById('videoCallModal');
        modal.insertAdjacentHTML('beforeend', menu);

        // حذف منو بعد از 5 ثانیه
        setTimeout(() => {
            const menu = document.querySelector('.quality-menu');
            if (menu) menu.remove();
        }, 5000);
    }

    // قطع تماس
    endCall(reason = 'completed') {
        console.log('endCall initiated, reason:', reason);

        // پاک کردن تایمر تماس خروجی در صورت وجود (مثلاً قطع زودهنگام توسط کاربر)
        if (this.outgoingCallTimeout) {
            clearTimeout(this.outgoingCallTimeout);
            this.outgoingCallTimeout = null;
        }

        // محاسبه مدت زمان
        let duration = 0;
        if (this.callStartTime) {
            duration = Math.floor((Date.now() - this.callStartTime) / 1000);
        }

        // ارسال سیگنال قطع تماس به طرف مقابل
        if (this.isCallActive) {
            this.sendSignal('end', reason);
        }

        // ثبت لاگ تماس در سرور
        if (this.targetUserId && this.targetUserId > 0) {
            const formData = new FormData();
            formData.append('target_user_id', this.targetUserId);
            formData.append('call_type', this.callType);
            formData.append('duration', duration);

            // تعیین وضعیت نهایی برای لاگ (completed, missed, rejected, no_answer)
            let logStatus = 'completed';
            if (duration === 0) {
                if (reason === 'no_answer') logStatus = 'no_answer';
                else if (reason === 'rejected') logStatus = 'rejected'; // سمت گیرنده، rejected است اگه دکمه رد بزنه
                else if (reason === 'missed') logStatus = 'missed';
                else logStatus = 'missed'; // Default short call without connect = missed/cancelled
            }

            // اگر من Initiator بودم و تماس وصل نشد، شاید 'cancelled' است
            if (this.isInitiator && duration === 0 && reason === 'completed') {
                logStatus = 'no_answer'; // یا cancelled
            }

            formData.append('status', logStatus);

            fetch('api/log_call.php', {
                method: 'POST',
                body: formData
            }).then(r => r.json()).then(d => console.log('Call log saved:', d)).catch(e => console.error('Error saving call log:', e));
        }

        // نمایش وضعیت نهایی
        if (duration > 0) {
            const minutes = Math.floor(duration / 60);
            const seconds = duration % 60;
            const durationText = `${minutes}:${seconds.toString().padStart(2, '0')}`;
            this.showCallStatus(`تماس قطع شد - مدت: ${durationText}`, 'info');
        } else {
            this.showCallStatus('تماس پایان یافت', 'info');
        }

        // انجام تمام پاکسازی‌ها از طریق تابع متمرکز forceCloseCall
        setTimeout(() => {
            this.forceCloseCall();
        }, 500);

        // پاک کردن وضعیت پیام بعد از 3 ثانیه
        setTimeout(() => {
            const deviceStatus = document.getElementById('deviceStatus');
            if (deviceStatus) {
                deviceStatus.innerHTML = '';
            }
        }, 3000);
    }

    // ریست کردن دکمه‌های تماس
    resetCallButtons() {
        const muteBtn = document.getElementById('muteBtn');
        const videoBtn = document.getElementById('videoBtn');

        if (muteBtn) {
            muteBtn.innerHTML = '🎤';
            muteBtn.classList.remove('muted');
            muteBtn.title = 'خاموش کردن میکروفون';
        }

        if (videoBtn) {
            videoBtn.innerHTML = '📹';
            videoBtn.classList.remove('muted');
            videoBtn.title = 'خاموش کردن دوربین';
        }
    }
}

// متغیر global برای مدیریت WebRTC
let webrtcManager = null;

// توابع global برای استفاده در HTML
function initWebRTC(targetUserId, currentUserId) {
    webrtcManager = new WebRTCManager(targetUserId, currentUserId);
}

function startVideoCall() {
    if (webrtcManager) {
        webrtcManager.startVideoCall();
    }
}

function startAudioCall() {
    if (webrtcManager) {
        webrtcManager.startAudioCall();
    }
}

function toggleMute() {
    if (webrtcManager) {
        webrtcManager.toggleMute();
    }
}

function toggleVideo() {
    if (webrtcManager) {
        webrtcManager.toggleVideo();
    }
}

function endCall() {
    if (webrtcManager) {
        webrtcManager.endCall();
    }
}

function acceptCall() {
    if (webrtcManager) {
        webrtcManager.acceptCall();
    }
}

function rejectCall() {
    if (webrtcManager) {
        webrtcManager.rejectCall();
    }
}

function acceptCallAudioOnly() {
    if (webrtcManager) {
        webrtcManager.acceptCallAudioOnly();
    }
}

function minimizeCall() {
    if (webrtcManager) {
        webrtcManager.minimizeCall();
    }
}

function maximizeCall() {
    if (webrtcManager) {
        webrtcManager.maximizeCall();
    }
}

function toggleMinimize() {
    if (webrtcManager) {
        webrtcManager.toggleMinimize();
    }
}

// مدیریت چت در حین تماس
function toggleCallChat() {
    const chatMessages = document.getElementById('callChatMessages');
    const toggleBtn = document.querySelector('.toggle-chat-btn');

    if (chatMessages.style.display === 'none') {
        chatMessages.style.display = 'block';
        toggleBtn.textContent = '🔽';
    } else {
        chatMessages.style.display = 'none';
        toggleBtn.textContent = '🔼';
    }
}

function toggleCallControlsPanel() {
    const panel = document.getElementById('callControlsPanel');
    if (!panel) return;
    panel.classList.toggle('collapsed');
}

function sendCallMessage() {
    const input = document.getElementById('callMessageInput');
    const message = input.value.trim();

    if (message === '') return;

    // اضافه کردن پیام به چت تماس
    addCallMessage(message, true);

    // ارسال پیام از طریق chatManager اصلی
    if (window.chatManager) {
        // استفاده از تابع ارسال پیام موجود
        const messageInput = document.getElementById('messageInput');
        const originalValue = messageInput.value;
        messageInput.value = `📞 ${message}`;

        // ارسال پیام
        chatManager.sendMessage().then(() => {
            messageInput.value = originalValue;
        });
    }

    input.value = '';
}

function addCallMessage(message, isSent = false) {
    const chatMessages = document.getElementById('callChatMessages');
    const messageDiv = document.createElement('div');
    messageDiv.className = `call-message ${isSent ? 'sent' : 'received'}`;
    messageDiv.textContent = message;

    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// توابع جدید برای امکانات اضافی modal تماس ورودی

// نمایش پیام‌های سریع
function showQuickMessage() {
    const quickMessages = document.getElementById('quickMessages');
    if (quickMessages) {
        quickMessages.style.display = 'block';
    }
}

// مخفی کردن پیام‌های سریع
function hideQuickMessage() {
    const quickMessages = document.getElementById('quickMessages');
    if (quickMessages) {
        quickMessages.style.display = 'none';
    }
}

// ارسال پیام سریع
function sendQuickMessage(message) {
    if (window.chatManager) {
        // استفاده از تابع ارسال پیام موجود
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            const originalValue = messageInput.value;
            messageInput.value = message;

            // ارسال پیام
            chatManager.sendMessage().then(() => {
                messageInput.value = originalValue;
            });
        }
    }

    // رد تماس بعد از ارسال پیام
    setTimeout(() => {
        if (webrtcManager) {
            webrtcManager.rejectCall();
        }
    }, 500);

    hideQuickMessage();
}

// یادآوری بعداً
function remindLater() {
    // ارسال پیام یادآوری
    if (window.chatManager) {
        const messageInput = document.getElementById('messageInput');
        if (messageInput) {
            const originalValue = messageInput.value;
            messageInput.value = '⏰ الان نمی‌تونم جواب بدم، بعداً تماس بگیر';

            chatManager.sendMessage().then(() => {
                messageInput.value = originalValue;
            });
        }
    }

    // رد تماس
    setTimeout(() => {
        if (webrtcManager) {
            webrtcManager.rejectCall();
        }
    }, 500);
}

// Event listener برای Enter در input چت تماس
document.addEventListener('DOMContentLoaded', function () {
    const callMessageInput = document.getElementById('callMessageInput');
    if (callMessageInput) {
        callMessageInput.addEventListener('keypress', function (e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                sendCallMessage();
            }
        });
    }

    // بستن پیام‌های سریع با کلیک خارج از آن
    document.addEventListener('click', function (e) {
        const quickMessages = document.getElementById('quickMessages');
        const messageBtn = document.querySelector('.message-btn');

        if (quickMessages && quickMessages.style.display === 'block') {
            if (!quickMessages.contains(e.target) && !messageBtn.contains(e.target)) {
                hideQuickMessage();
            }
        }
    });
});
