<?php
/**
 * فایل نمونه تنظیمات دیتابیس
 * این فایل توسط installer به config/db.php تبدیل می‌شود
 */

// تنظیمات اتصال به دیتابیس
define('DB_HOST', 'localhost');
define('DB_NAME', 'your_database_name');
define('DB_USER', 'your_database_user');
define('DB_PASS', 'your_database_password');
define('DB_PORT', '3306');

// ساخت اتصال PDO
try {
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO($dsn, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('خطا در اتصال به دیتابیس: ' . $e->getMessage());
}
?>