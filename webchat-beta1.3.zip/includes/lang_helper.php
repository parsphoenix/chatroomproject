<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// لیست زبان‌های پشتیبانی شده
$supported_langs = ['fa', 'en'];

// تعیین زبان پیش‌فرض
$default_lang = 'fa';

// دریافت زبان از سشن یا کوکی یا مقدار پیش‌فرض
if (isset($_GET['lang']) && in_array($_GET['lang'], $supported_langs)) {
    $_SESSION['lang'] = $_GET['lang'];
    setcookie('app_lang', $_GET['lang'], time() + (86400 * 30), "/"); // 30 days
} 

$current_lang = $_SESSION['lang'] ?? ($_COOKIE['app_lang'] ?? $default_lang);
if (!in_array($current_lang, $supported_langs)) {
    $current_lang = $default_lang;
}
$_SESSION['lang'] = $current_lang;

// بارگذاری فایل ترجمه
$lang_file = dirname(__DIR__) . "/lang/{$current_lang}.php";
$translations = file_exists($lang_file) ? require $lang_file : require dirname(__DIR__) . "/lang/fa.php";

/**
 * تابع ترجمه
 * @param string $key کلید ترجمه
 * @param array $replace مقادیری که باید جایگزین شوند
 * @return string متن ترجمه شده
 */
function __($key, $replace = []) {
    global $translations;
    $text = $translations[$key] ?? $key;
    
    foreach ($replace as $search => $value) {
        $text = str_replace(":{$search}", $value, $text);
    }
    
    return $text;
}

/**
 * دریافت جهت صفحه (rtl یا ltr)
 * @return string
 */
function get_direction() {
    return __('direction');
}

/**
 * دریافت کد زبان
 * @return string
 */
function get_lang_code() {
    return __('lang_code');
}
