<?php
/**
 * لودر WebRTC برای فعال‌سازی تماس سراسری
 */
if (isset($_SESSION['user_id'])):
    // تشخیص اینکه آیا در صفحه چت هستیم (chat.php خودش WebRTC رو مقداردهی می‌کنه)
    $currentPage = basename($_SERVER['SCRIPT_NAME'] ?? '');
    $isChatPage = ($currentPage === 'chat.php');
?>
<!-- WebRTC Assets -->
<script src="assets/webrtc.js"></script>
<?php include 'includes/call_modals.php'; ?>
<?php if (!$isChatPage): ?>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // فقط در صفحات غیر چت مقداردهی اولیه انجام بده
        // صفحه چت خودش با targetUserId صحیح این کار رو انجام می‌ده
        if (typeof WebRTCManager !== 'undefined' && !webrtcManager) {
            initWebRTC(0, <?= $_SESSION['user_id'] ?>);
            console.log('WebRTC Global Signaling initialized');
        }
    });
</script>
<?php endif; ?>
<?php endif; ?>
