<?php
/**
 * Authentication helper functions
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Check if user is logged in via Session or Remember Me cookie
 * 
 * @param PDO $pdo Database connection
 * @return bool True if logged in, False otherwise
 */
function checkAuth($pdo) {
    // 1. Check Session
    if (isset($_SESSION['user_id'])) {
        return true;
    }

    // 2. Check Remember Token
    if (isset($_COOKIE['remember_token'])) {
        $token = $_COOKIE['remember_token'];
        $token_hash = hash('sha256', $token);

        try {
            $stmt = $pdo->prepare("SELECT id, username FROM users WHERE remember_token = ?");
            $stmt->execute([$token_hash]);
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Regenerate session ID to prevent fixation
                session_regenerate_id(true);
                
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                
                // Update last seen
                $update = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
                $update->execute([$user['id']]);
                
                return true;
            }
        } catch (PDOException $e) {
            // Log error or ignore
        }
    }

    return false;
}

/**
 * Handle Remember Me functionality during login
 * 
 * @param PDO $pdo Database connection
 * @param int $user_id User ID
 */
function setRememberMe($pdo, $user_id) {
    // Generate secure random token
    $token = bin2hex(random_bytes(32)); // 64 chars
    $token_hash = hash('sha256', $token);

    try {
        $stmt = $pdo->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
        $stmt->execute([$token_hash, $user_id]);

        // Set cookie for 30 days
        setcookie('remember_token', $token, time() + (30 * 24 * 60 * 60), '/', '', false, true); // Secure=false for local dev, HttpOnly=true
    } catch (PDOException $e) {
        // Log error
    }
}

/**
 * Clear Remember Me token during logout
 * 
 * @param PDO $pdo Database connection
 */
function clearRememberMe($pdo) {
    if (isset($_SESSION['user_id'])) {
        try {
            $stmt = $pdo->prepare("UPDATE users SET remember_token = NULL WHERE id = ?");
            $stmt->execute([$_SESSION['user_id']]);
        } catch (PDOException $e) {
            // Ignore
        }
    }
    
    // Delete cookie
    if (isset($_COOKIE['remember_token'])) {
        setcookie('remember_token', '', time() - 3600, '/');
    }
}
?>
