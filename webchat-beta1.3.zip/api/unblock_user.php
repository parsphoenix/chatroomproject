<?php
/**
 * API آنبلاک کردن کاربر
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$username = trim($_POST['username'] ?? '');

if (empty($username)) {
    echo json_encode(['success' => false, 'message' => 'نام کاربری الزامی است']);
    exit;
}

try {
    // پیدا کردن کاربر مقصد
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $target_user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$target_user) {
        echo json_encode(['success' => false, 'message' => 'کاربر یافت نشد']);
        exit;
    }
    
    if ($target_user['id'] == $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'نمی‌توانید خودتان را آنبلاک کنید']);
        exit;
    }
    
    // چک کردن اینکه آیا بلاک شده است
    $stmt = $pdo->prepare("SELECT id FROM user_blocks WHERE blocker_id = ? AND blocked_id = ?");
    $stmt->execute([$_SESSION['user_id'], $target_user['id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'این کاربر بلاک نشده است']);
        exit;
    }
    
    // آنبلاک کردن کاربر
    $stmt = $pdo->prepare("DELETE FROM user_blocks WHERE blocker_id = ? AND blocked_id = ?");
    $stmt->execute([$_SESSION['user_id'], $target_user['id']]);
    
    echo json_encode([
        'success' => true,
        'message' => 'کاربر با موفقیت آنبلاک شد'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در آنبلاک کردن: ' . $e->getMessage()
    ]);
}
?>