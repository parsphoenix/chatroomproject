<?php
/**
 * API دریافت لیست کاربران ممنوع
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

// چک دسترسی ادمین
try {
    $stmt = $pdo->prepare("SELECT user_role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || $user['user_role'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در بررسی دسترسی']);
    exit;
}

try {
    // دریافت کاربران ممنوع
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            ub.ban_reason,
            ub.banned_at,
            admin.username as banned_by_admin
        FROM user_bans ub
        INNER JOIN users u ON ub.banned_user_id = u.id
        INNER JOIN users admin ON ub.banned_by_admin_id = admin.id
        WHERE ub.is_active = TRUE
        ORDER BY ub.banned_at DESC
        LIMIT 50
    ");
    
    $stmt->execute();
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // فرمت کردن تاریخ‌ها
    foreach ($users as &$user) {
        $user['banned_at_formatted'] = date('Y/m/d H:i', strtotime($user['banned_at']));
    }
    
    echo json_encode([
        'success' => true,
        'users' => $users,
        'count' => count($users)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت اطلاعات: ' . $e->getMessage()
    ]);
}
?>