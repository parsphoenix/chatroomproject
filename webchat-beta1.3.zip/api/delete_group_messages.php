<?php
/**
 * API حذف پیام‌های گروهی
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

// دریافت message_ids به صورت آرایه
$message_ids = [];
if (isset($_POST['message_ids'])) {
    if (is_array($_POST['message_ids'])) {
        $message_ids = $_POST['message_ids'];
    } else {
        // اگر به صورت رشته ارسال شده، تبدیل به آرایه
        $message_ids = explode(',', $_POST['message_ids']);
    }
}

$delete_type = $_POST['delete_type'] ?? 'for_me'; // 'for_me' یا 'for_all'
$group_id = intval($_POST['group_id'] ?? 0);

// اعتبارسنجی
if (empty($message_ids)) {
    echo json_encode(['success' => false, 'message' => 'پیامی انتخاب نشده است']);
    exit;
}

// فیلتر کردن message_ids خالی
$message_ids = array_filter($message_ids, function($id) {
    return !empty(trim($id));
});

if (empty($message_ids)) {
    echo json_encode(['success' => false, 'message' => 'شناسه پیام‌های معتبر یافت نشد']);
    exit;
}

if (!in_array($delete_type, ['for_me', 'for_all'])) {
    echo json_encode(['success' => false, 'message' => 'نوع حذف نامعتبر است']);
    exit;
}

if ($group_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه گروه نامعتبر است']);
    exit;
}

// تبدیل به اعداد صحیح
$message_ids = array_map('intval', $message_ids);
$message_ids = array_filter($message_ids, function($id) { return $id > 0; });

if (empty($message_ids)) {
    echo json_encode(['success' => false, 'message' => 'شناسه پیام‌های نامعتبر']);
    exit;
}

try {
    // چک عضویت در گروه
    $stmt = $pdo->prepare("
        SELECT status FROM group_members 
        WHERE group_id = ? AND user_id = ? AND status = 'accepted'
    ");
    $stmt->execute([$group_id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما عضو این گروه نیستید']);
        exit;
    }
    
    $pdo->beginTransaction();
    
    if ($delete_type === 'for_all') {
        // حذف برای همه - فقط پیام‌های ارسالی توسط کاربر جاری
        $placeholders = str_repeat('?,', count($message_ids) - 1) . '?';
        
        // ابتدا چک کنیم که تمام پیام‌ها متعلق به کاربر جاری هستند
        $stmt = $pdo->prepare("
            SELECT id FROM group_messages 
            WHERE id IN ($placeholders) AND sender_id = ? AND group_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id'], $group_id]));
        $validMessages = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (count($validMessages) !== count($message_ids)) {
            throw new Exception('فقط می‌توانید پیام‌های خودتان را برای همه حذف کنید');
        }
        
        // حذف فایل‌های مرتبط
        $stmt = $pdo->prepare("
            SELECT file_path FROM group_files gf
            INNER JOIN group_messages gm ON gm.id = gf.message_id
            WHERE gm.id IN ($placeholders) AND gm.sender_id = ? AND gm.group_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id'], $group_id]));
        $files = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // حذف فایل‌ها از دیسک
        foreach ($files as $filePath) {
            if (file_exists('../' . $filePath)) {
                unlink('../' . $filePath);
            }
        }
        
        // حذف رکوردهای فایل
        $stmt = $pdo->prepare("
            DELETE gf FROM group_files gf
            INNER JOIN group_messages gm ON gm.id = gf.message_id
            WHERE gm.id IN ($placeholders) AND gm.sender_id = ? AND gm.group_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id'], $group_id]));
        
        // حذف پیام‌ها
        $stmt = $pdo->prepare("
            DELETE FROM group_messages 
            WHERE id IN ($placeholders) AND sender_id = ? AND group_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id'], $group_id]));
        
    } else {
        // حذف فقط برای کاربر جاری - تبدیل پیام به "حذف شده"
        $placeholders = str_repeat('?,', count($message_ids) - 1) . '?';
        
        $stmt = $pdo->prepare("
            UPDATE group_messages 
            SET message = 'این پیام حذف شده است'
            WHERE id IN ($placeholders) AND group_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$group_id]));
    }
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'deleted_count' => count($message_ids),
        'message' => 'پیام‌ها با موفقیت حذف شدند'
    ]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در حذف پیام‌ها: ' . $e->getMessage()
    ]);
}
?>