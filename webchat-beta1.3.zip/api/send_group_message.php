<?php
/**
 * API ارسال پیام گروهی
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$group_id = intval($_POST['group_id'] ?? 0);
$message = trim($_POST['message'] ?? '');

// اعتبارسنجی
if ($group_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه گروه نامعتبر']);
    exit;
}

if (empty($message)) {
    echo json_encode(['success' => false, 'message' => 'پیام نمی‌تواند خالی باشد']);
    exit;
}

if (strlen($message) > 1000) {
    echo json_encode(['success' => false, 'message' => 'پیام نمی‌تواند بیش از 1000 کاراکتر باشد']);
    exit;
}

try {
    // چک کردن عضویت در گروه
    $stmt = $pdo->prepare("
        SELECT status FROM group_members 
        WHERE group_id = ? AND user_id = ? AND status = 'accepted'
    ");
    $stmt->execute([$group_id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما عضو این گروه نیستید']);
        exit;
    }
    
    // ارسال پیام گروهی
    $stmt = $pdo->prepare("
        INSERT INTO group_messages (group_id, sender_id, message, created_at) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$group_id, $_SESSION['user_id'], $message]);
    
    // آپدیت آخرین فعالیت
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'message_id' => $pdo->lastInsertId(),
        'message' => 'پیام با موفقیت ارسال شد'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ارسال پیام: ' . $e->getMessage()
    ]);
}
?>