<?php
/**
 * API بروزرسانی وضعیت عمومی کاربر
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$is_public = isset($_POST['is_public']) && $_POST['is_public'] === '1';

try {
    // بروزرسانی وضعیت عمومی
    $stmt = $pdo->prepare("UPDATE users SET is_public = ? WHERE id = ?");
    $stmt->execute([$is_public ? 1 : 0, $_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'is_public' => $is_public,
        'message' => 'تنظیمات با موفقیت بروزرسانی شد'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در بروزرسانی: ' . $e->getMessage()
    ]);
}
?>