<?php
/**
 * API ارسال WebRTC signal
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$to_user_id = intval($_POST['to_user_id'] ?? 0);
$signal_type = trim($_POST['signal_type'] ?? '');
$signal_data = trim($_POST['signal_data'] ?? '');

// اعتبارسنجی
if ($to_user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'کاربر مقصد نامعتبر']);
    exit;
}

if (!in_array($signal_type, ['offer', 'answer', 'ice', 'reject', 'end', 'group-offer', 'group-answer', 'group-ice'])) {
    echo json_encode(['success' => false, 'message' => 'نوع سیگنال نامعتبر']);
    exit;
}

if (empty($signal_data)) {
    echo json_encode(['success' => false, 'message' => 'داده سیگنال الزامی است']);
    exit;
}

if ($to_user_id == $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'message' => 'نمی‌توانید به خودتان سیگنال بفرستید']);
    exit;
}

try {
    // چک کردن وجود کاربر مقصد
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->execute([$to_user_id]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'کاربر مقصد یافت نشد']);
        exit;
    }
    
    // ارسال سیگنال
    $stmt = $pdo->prepare("
        INSERT INTO webrtc_signals (from_user_id, to_user_id, signal_type, signal_data, created_at) 
        VALUES (?, ?, ?, ?, NOW())
    ");
    $stmt->execute([$_SESSION['user_id'], $to_user_id, $signal_type, $signal_data]);
    
    // آپدیت آخرین فعالیت
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'signal_id' => $pdo->lastInsertId(),
        'message' => 'سیگنال با موفقیت ارسال شد'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ارسال سیگنال: ' . $e->getMessage()
    ]);
}
?>