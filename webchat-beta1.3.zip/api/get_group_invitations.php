<?php
/**
 * API دریافت دعوت‌نامه‌های گروهی
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

try {
    // دریافت دعوت‌نامه‌های در انتظار
    $stmt = $pdo->prepare("
        SELECT 
            g.id as group_id,
            g.name as group_name,
            g.description,
            u.username as creator_name,
            gm.joined_at as invited_at
        FROM group_members gm
        INNER JOIN groups_table g ON gm.group_id = g.id
        INNER JOIN users u ON g.creator_id = u.id
        WHERE gm.user_id = ? AND gm.status = 'pending'
        ORDER BY gm.joined_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $invitations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'invitations' => $invitations,
        'count' => count($invitations)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت دعوت‌نامه‌ها: ' . $e->getMessage()
    ]);
}
?>