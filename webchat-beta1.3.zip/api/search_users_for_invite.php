<?php
/**
 * API جستجوی کاربران برای دعوت به گروه
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$query = trim($_POST['query'] ?? '');
$groupId = intval($_POST['group_id'] ?? 0);

// اعتبارسنجی
if (empty($query)) {
    echo json_encode(['success' => false, 'message' => 'کلمه جستجو الزامی است']);
    exit;
}

if (strlen($query) < 2) {
    echo json_encode(['success' => false, 'message' => 'حداقل 2 کاراکتر برای جستجو لازم است']);
    exit;
}

if ($groupId <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه گروه نامعتبر است']);
    exit;
}

try {
    // چک کردن اینکه کاربر سازنده گروه است
    $stmt = $pdo->prepare("SELECT id FROM groups_table WHERE id = ? AND creator_id = ?");
    $stmt->execute([$groupId, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما مجاز به دعوت در این گروه نیستید']);
        exit;
    }
    
    // جستجوی کاربران که:
    // 1. نام کاربری‌شان شامل کلمه جستجو باشد
    // 2. خود کاربر جاری نباشند
    // 3. قبلاً عضو گروه نباشند
    // 4. بلاک نشده باشند
    $stmt = $pdo->prepare("
        SELECT 
            u.id, 
            u.username
        FROM users u
        WHERE u.username LIKE ? 
        AND u.id != ? 
        AND u.id NOT IN (
            SELECT user_id FROM group_members WHERE group_id = ?
        )
        AND u.id NOT IN (
            SELECT blocked_id FROM user_blocks WHERE blocker_id = ?
        )
        AND u.id NOT IN (
            SELECT blocker_id FROM user_blocks WHERE blocked_id = ?
        )
        ORDER BY u.username ASC 
        LIMIT 20
    ");
    
    $searchTerm = '%' . $query . '%';
    $stmt->execute([
        $searchTerm, 
        $_SESSION['user_id'], 
        $groupId, 
        $_SESSION['user_id'], 
        $_SESSION['user_id']
    ]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'users' => $users,
        'count' => count($users)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در جستجو: ' . $e->getMessage()
    ]);
}
?>