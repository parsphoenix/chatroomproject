<?php
/**
 * API حذف کامل تاریخچه چت
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$username = trim($_POST['username'] ?? '');

if (empty($username)) {
    echo json_encode(['success' => false, 'message' => 'نام کاربری الزامی است']);
    exit;
}

try {
    // پیدا کردن کاربر مقصد
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $target_user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$target_user) {
        echo json_encode(['success' => false, 'message' => 'کاربر یافت نشد']);
        exit;
    }
    
    if ($target_user['id'] == $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'نمی‌توانید چت با خودتان را حذف کنید']);
        exit;
    }
    
    $pdo->beginTransaction();
    
    // حذف فایل‌های مرتبط با چت
    $stmt = $pdo->prepare("
        SELECT file_path FROM chat_files 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $target_user['id'], $target_user['id'], $_SESSION['user_id']]);
    $files = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // حذف فایل‌ها از دیسک
    foreach ($files as $filePath) {
        if (file_exists('../' . $filePath)) {
            unlink('../' . $filePath);
        }
    }
    
    // حذف رکوردهای فایل
    $stmt = $pdo->prepare("
        DELETE FROM chat_files 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $target_user['id'], $target_user['id'], $_SESSION['user_id']]);
    
    // حذف تمام پیام‌ها بین دو کاربر
    $stmt = $pdo->prepare("
        DELETE FROM messages 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $target_user['id'], $target_user['id'], $_SESSION['user_id']]);
    $deleted_messages = $stmt->rowCount();
    
    // حذف از چت‌های اخیر
    $stmt = $pdo->prepare("
        DELETE FROM recent_chats 
        WHERE (user_id = ? AND chat_with_id = ?) OR (user_id = ? AND chat_with_id = ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $target_user['id'], $target_user['id'], $_SESSION['user_id']]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'deleted_messages' => $deleted_messages,
        'message' => 'تاریخچه چت با موفقیت حذف شد'
    ]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در حذف تاریخچه چت: ' . $e->getMessage()
    ]);
}
?>