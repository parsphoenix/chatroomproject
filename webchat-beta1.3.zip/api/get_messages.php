<?php
/**
 * API دریافت پیام‌ها
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$target_user_id = intval($_POST['target_user_id'] ?? 0);
$last_message_id = intval($_POST['last_message_id'] ?? 0);
$before_message_id = intval($_POST['before_message_id'] ?? 0);
$after_message_id = intval($_POST['after_message_id'] ?? 0);
$limit = intval($_POST['limit'] ?? 30);
if ($limit <= 0 || $limit > 100) {
    $limit = 30;
}

// اعتبارسنجی
if ($target_user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'کاربر مقصد نامعتبر']);
    exit;
}

if ($target_user_id == $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'message' => 'نمی‌توانید با خودتان چت کنید']);
    exit;
}

try {
    // چک کردن وجود کاربر مقصد و اینکه بلاک نشده باشد
    $stmt = $pdo->prepare("
        SELECT u.id 
        FROM users u
        WHERE u.id = ?
        AND u.id NOT IN (
            SELECT blocked_id FROM user_blocks WHERE blocker_id = ?
        )
        AND u.id NOT IN (
            SELECT blocker_id FROM user_blocks WHERE blocked_id = ?
        )
    ");
    $stmt->execute([$target_user_id, $_SESSION['user_id'], $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'کاربر مقصد یافت نشد یا بلاک شده است']);
        exit;
    }
    
    // دریافت پیام‌ها
    if ($before_message_id > 0) {
        $stmt = $pdo->prepare("
            SELECT id, sender_id, receiver_id, message, created_at, status, type, metadata
            FROM messages 
            WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
            AND id < ?
            ORDER BY created_at DESC, id DESC
            LIMIT $limit
        ");
        $stmt->execute([$_SESSION['user_id'], $target_user_id, $target_user_id, $_SESSION['user_id'], $before_message_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $messages = array_reverse($messages);
    } elseif ($after_message_id > 0) {
        $stmt = $pdo->prepare("
            SELECT id, sender_id, receiver_id, message, created_at, status, type, metadata
            FROM messages 
            WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
            AND id > ?
            ORDER BY created_at ASC, id ASC
            LIMIT $limit
        ");
        $stmt->execute([$_SESSION['user_id'], $target_user_id, $target_user_id, $_SESSION['user_id'], $after_message_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($last_message_id == 0) {
        $stmt = $pdo->prepare("
            SELECT id, sender_id, receiver_id, message, created_at, status, type, metadata
            FROM messages 
            WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
            ORDER BY created_at DESC, id DESC
            LIMIT $limit
        ");
        $stmt->execute([$_SESSION['user_id'], $target_user_id, $target_user_id, $_SESSION['user_id']]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $messages = array_reverse($messages);
    } else {
        $stmt = $pdo->prepare("
            SELECT id, sender_id, receiver_id, message, created_at, status, type, metadata
            FROM messages 
            WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?))
            AND id > ?
            ORDER BY created_at ASC, id ASC
        ");
        $stmt->execute([$_SESSION['user_id'], $target_user_id, $target_user_id, $_SESSION['user_id'], $last_message_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // 1. علامت‌گذاری پیام‌های دریافتی جدید به عنوان "DELIVERED" (تحویل داده شده)
    // اگر هنوز خوانده نشده‌اند ولی دریافت شدند
    // پیام‌هایی که is_read=0 هستند و receiver من هستم
    try {
        $stmt = $pdo->prepare("
            UPDATE messages 
            SET status = 'delivered' 
            WHERE receiver_id = ? 
            AND sender_id = ? 
            AND status = 'sent'
        ");
        $stmt->execute([$_SESSION['user_id'], $target_user_id]);
    } catch (PDOException $e) {
        // Ignored (column might not exist yet if migration failed)
    }

    // 2. علامت‌گذاری پیام‌های دریافتی به عنوان "READ" (خوانده شده)
    // چون کاربر دارد چت را می‌بیند (get_messages صدا زده شده)
    if (!empty($messages)) {
        $messageIds = array_column($messages, 'id');
        $placeholders = str_repeat('?,', count($messageIds) - 1) . '?';
        
        // آپدیت وضعیت به 'read' و is_read به TRUE
        $sql = "UPDATE messages SET is_read = TRUE, status = 'read' 
                WHERE id IN ($placeholders) AND receiver_id = ? AND sender_id = ?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute(array_merge($messageIds, [$_SESSION['user_id'], $target_user_id]));
    }
    
    // 3. دریافت وضعیت پیام‌های ارسالی من (برای آپدیت تیک‌ها)
    $status_updates = [];
    try {
        $stmt = $pdo->prepare("
            SELECT id, status 
            FROM messages 
            WHERE sender_id = ? 
            AND receiver_id = ? 
            AND status IN ('sent', 'delivered', 'read')
            ORDER BY id DESC
            LIMIT 50
        ");
        $stmt->execute([$_SESSION['user_id'], $target_user_id]);
        $status_updates = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        // Column might not exist
    }

    // آپدیت آخرین فعالیت
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'messages' => $messages,
        'status_updates' => $status_updates,
        'count' => count($messages)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت پیام‌ها: ' . $e->getMessage()
    ]);
}
?>
