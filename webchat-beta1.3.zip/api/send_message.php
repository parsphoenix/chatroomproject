<?php
/**
 * API ارسال پیام
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$target_user_id = intval($_POST['target_user_id'] ?? 0);
$message = trim($_POST['message'] ?? '');

// اعتبارسنجی
if ($target_user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'کاربر مقصد نامعتبر']);
    exit;
}

if (empty($message)) {
    echo json_encode(['success' => false, 'message' => 'پیام نمی‌تواند خالی باشد']);
    exit;
}

if (strlen($message) > 1000) {
    echo json_encode(['success' => false, 'message' => 'پیام نمی‌تواند بیش از 1000 کاراکتر باشد']);
    exit;
}

if ($target_user_id == $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'message' => 'نمی‌توانید به خودتان پیام بفرستید']);
    exit;
}

try {
    // چک کردن وجود کاربر مقصد و اینکه بلاک نشده باشد
    $stmt = $pdo->prepare("
        SELECT u.id 
        FROM users u
        WHERE u.id = ?
        AND u.id NOT IN (
            SELECT blocked_id FROM user_blocks WHERE blocker_id = ?
        )
        AND u.id NOT IN (
            SELECT blocker_id FROM user_blocks WHERE blocked_id = ?
        )
    ");
    $stmt->execute([$target_user_id, $_SESSION['user_id'], $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'کاربر مقصد یافت نشد یا بلاک شده است']);
        exit;
    }
    
    // ارسال پیام
    $stmt = $pdo->prepare("
        INSERT INTO messages (sender_id, receiver_id, message, created_at) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$_SESSION['user_id'], $target_user_id, $message]);
    
    // آپدیت آخرین فعالیت فرستنده
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'message_id' => $pdo->lastInsertId(),
        'message' => 'پیام با موفقیت ارسال شد'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ارسال پیام: ' . $e->getMessage()
    ]);
}
?>