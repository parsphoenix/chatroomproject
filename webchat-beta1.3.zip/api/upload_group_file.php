<?php
/**
 * API آپلود فایل در گروه
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$group_id = intval($_POST['group_id'] ?? 0);

// اعتبارسنجی
if ($group_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه گروه نامعتبر']);
    exit;
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'فایل آپلود نشده یا خطا در آپلود']);
    exit;
}

$file = $_FILES['file'];

// بررسی حجم فایل (5 مگابایت)
$maxSize = 5 * 1024 * 1024; // 5MB
if ($file['size'] > $maxSize) {
    echo json_encode(['success' => false, 'message' => 'حجم فایل نباید بیش از 5 مگابایت باشد']);
    exit;
}

// بررسی نوع فایل
$allowedTypes = [
    'image/jpeg', 'image/png', 'image/gif', 'image/webp',
    'application/pdf', 'text/plain', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/zip', 'application/x-rar-compressed'
];

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mimeType, $allowedTypes)) {
    echo json_encode(['success' => false, 'message' => 'نوع فایل مجاز نیست']);
    exit;
}

try {
    // چک کردن عضویت در گروه
    $stmt = $pdo->prepare("
        SELECT status FROM group_members 
        WHERE group_id = ? AND user_id = ? AND status = 'accepted'
    ");
    $stmt->execute([$group_id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما عضو این گروه نیستید']);
        exit;
    }
    
    // چک کردن تعداد فایل‌های موجود در گروه (حداکثر 10 فایل)
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as file_count 
        FROM group_files 
        WHERE group_id = ?
    ");
    $stmt->execute([$group_id]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['file_count'] >= 10) {
        echo json_encode(['success' => false, 'message' => 'حداکثر 10 فایل در هر گروه مجاز است']);
        exit;
    }
    
    // ساخت نام فایل منحصر به فرد
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = 'group_' . $group_id . '_' . uniqid() . '_' . time() . '.' . $extension;
    $uploadPath = '../uploads/chat_files/' . $fileName;
    
    // آپلود فایل
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        echo json_encode(['success' => false, 'message' => 'خطا در آپلود فایل']);
        exit;
    }
    
    // ذخیره اطلاعات فایل در دیتابیس
    $stmt = $pdo->prepare("
        INSERT INTO group_files (group_id, sender_id, original_name, file_name, file_size, file_type, file_path) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $group_id,
        $_SESSION['user_id'],
        $file['name'],
        $fileName,
        $file['size'],
        $mimeType,
        'uploads/chat_files/' . $fileName
    ]);
    
    $fileId = $pdo->lastInsertId();
    
    // ارسال پیام حاوی فایل
    $message = "📎 فایل ارسال شد: " . $file['name'];
    $stmt = $pdo->prepare("
        INSERT INTO group_messages (group_id, sender_id, message, created_at) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$group_id, $_SESSION['user_id'], $message]);
    
    // آپدیت آخرین فعالیت
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'file_id' => $fileId,
        'file_name' => $file['name'],
        'file_size' => $file['size'],
        'message' => 'فایل با موفقیت آپلود شد'
    ]);
    
} catch (PDOException $e) {
    // حذف فایل در صورت خطا در دیتابیس
    if (file_exists($uploadPath)) {
        unlink($uploadPath);
    }
    
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در آپلود فایل: ' . $e->getMessage()
    ]);
}
?>