<?php
/**
 * API لغو ممنوعیت کاربر توسط ادمین
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

// چک دسترسی ادمین
try {
    $stmt = $pdo->prepare("SELECT user_role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || $user['user_role'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در بررسی دسترسی']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$user_id = intval($_POST['user_id'] ?? 0);

// اعتبارسنجی
if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه کاربر نامعتبر']);
    exit;
}

try {
    // چک کردن وجود کاربر
    $stmt = $pdo->prepare("SELECT id, username FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $target_user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$target_user) {
        echo json_encode(['success' => false, 'message' => 'کاربر یافت نشد']);
        exit;
    }
    
    // چک کردن اینکه کاربر ممنوع باشد
    $stmt = $pdo->prepare("SELECT id FROM user_bans WHERE banned_user_id = ? AND is_active = TRUE");
    $stmt->execute([$user_id]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'این کاربر ممنوع نیست']);
        exit;
    }
    
    $pdo->beginTransaction();
    
    // لغو ممنوعیت
    $stmt = $pdo->prepare("UPDATE user_bans SET is_active = FALSE WHERE banned_user_id = ? AND is_active = TRUE");
    $stmt->execute([$user_id]);
    
    // ثبت لاگ
    $stmt = $pdo->prepare("
        INSERT INTO admin_logs (admin_id, action_type, target_user_id, action_details) 
        VALUES (?, 'unban_user', ?, ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $user_id, 'لغو ممنوعیت کاربر']);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'ممنوعیت کاربر با موفقیت لغو شد',
        'unbanned_user' => $target_user['username']
    ]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در لغو ممنوعیت: ' . $e->getMessage()
    ]);
}
?>