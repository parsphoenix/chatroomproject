<?php
/**
 * API دانلود فایل گروهی
 */

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    die('سیستم نصب نشده است');
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    die('لطفاً وارد شوید');
}

require_once '../config/db.php';

$message_id = intval($_GET['id'] ?? 0);

if ($message_id <= 0) {
    die('شناسه پیام نامعتبر');
}

try {
    // پیدا کردن فایل مرتبط با پیام گروهی
    $stmt = $pdo->prepare("
        SELECT gf.*, gm.group_id
        FROM group_files gf
        INNER JOIN group_messages gm ON gf.group_id = gm.group_id
        WHERE gm.id = ? 
        AND gm.message LIKE CONCAT('%', gf.original_name, '%')
        AND EXISTS (
            SELECT 1 FROM group_members gmem 
            WHERE gmem.group_id = gf.group_id 
            AND gmem.user_id = ? 
            AND gmem.status = 'accepted'
        )
        LIMIT 1
    ");
    $stmt->execute([$message_id, $_SESSION['user_id']]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$file) {
        die('فایل یافت نشد یا دسترسی ندارید');
    }
    
    $filePath = '../' . $file['file_path'];
    
    if (!file_exists($filePath)) {
        die('فایل در سرور موجود نیست');
    }
    
    // تنظیم header های دانلود
    header('Content-Type: ' . $file['file_type']);
    header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    // خواندن و ارسال فایل
    readfile($filePath);
    
} catch (PDOException $e) {
    die('خطا در دسترسی به فایل: ' . $e->getMessage());
}
?>