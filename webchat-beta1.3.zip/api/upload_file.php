<?php
/**
 * API آپلود فایل در چت
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$target_user_id = intval($_POST['target_user_id'] ?? 0);

// اعتبارسنجی
if ($target_user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'کاربر مقصد نامعتبر']);
    exit;
}

if (!isset($_FILES['file']) || $_FILES['file']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'فایل آپلود نشده یا خطا در آپلود']);
    exit;
}

$file = $_FILES['file'];

// بررسی حجم فایل (5 مگابایت)
$maxSize = 5 * 1024 * 1024; // 5MB
if ($file['size'] > $maxSize) {
    echo json_encode(['success' => false, 'message' => 'حجم فایل نباید بیش از 5 مگابایت باشد']);
    exit;
}

// بررسی نوع فایل (فقط فایل‌های امن)
$allowedTypes = [
    'image/jpeg', 'image/png', 'image/gif', 'image/webp',
    'application/pdf', 'text/plain', 'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/zip', 'application/x-rar-compressed'
];

$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mimeType, $allowedTypes)) {
    echo json_encode(['success' => false, 'message' => 'نوع فایل مجاز نیست']);
    exit;
}

try {
    // چک کردن وجود کاربر مقصد
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ?");
    $stmt->execute([$target_user_id]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'کاربر مقصد یافت نشد']);
        exit;
    }
    
    // چک کردن تعداد فایل‌های موجود (حداکثر 6 فایل)
    $stmt = $pdo->prepare("
        SELECT COUNT(*) as file_count 
        FROM chat_files 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $target_user_id, $target_user_id, $_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['file_count'] >= 6) {
        echo json_encode(['success' => false, 'message' => 'حداکثر 6 فایل در هر چت مجاز است. لطفاً ابتدا فایل‌های قدیمی را حذف کنید']);
        exit;
    }
    
    // ساخت نام فایل منحصر به فرد
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $fileName = uniqid() . '_' . time() . '.' . $extension;
    $uploadPath = '../uploads/chat_files/' . $fileName;
    
    // آپلود فایل
    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        echo json_encode(['success' => false, 'message' => 'خطا در آپلود فایل']);
        exit;
    }
    
    // ذخیره اطلاعات فایل در دیتابیس
    $stmt = $pdo->prepare("
        INSERT INTO chat_files (sender_id, receiver_id, original_name, file_name, file_size, file_type, file_path) 
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $_SESSION['user_id'],
        $target_user_id,
        $file['name'],
        $fileName,
        $file['size'],
        $mimeType,
        'uploads/chat_files/' . $fileName
    ]);
    
    $fileId = $pdo->lastInsertId();
    
    // ارسال پیام حاوی فایل
    $message = "📎 فایل ارسال شد: " . $file['name'];
    $stmt = $pdo->prepare("
        INSERT INTO messages (sender_id, receiver_id, message, created_at) 
        VALUES (?, ?, ?, NOW())
    ");
    $stmt->execute([$_SESSION['user_id'], $target_user_id, $message]);
    
    // آپدیت آخرین فعالیت
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'file_id' => $fileId,
        'file_name' => $file['name'],
        'file_size' => $file['size'],
        'message' => 'فایل با موفقیت آپلود شد'
    ]);
    
} catch (PDOException $e) {
    // حذف فایل در صورت خطا در دیتابیس
    if (file_exists($uploadPath)) {
        unlink($uploadPath);
    }
    
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در آپلود فایل: ' . $e->getMessage()
    ]);
}
?>