<?php
/**
 * API برای تغییر رمز عبور
 */

require_once '../includes/lang_helper.php';
require_once '../config/db.php';

session_start();

header('Content-Type: application/json');

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => __('please_login')]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => __('invalid_request')]);
    exit;
}

$oldPassword = $_POST['oldPassword'] ?? '';
$newPassword = $_POST['newPassword'] ?? '';
$confirmPassword = $_POST['confirmPassword'] ?? '';
$userId = $_SESSION['user_id'];

if (empty($oldPassword) || empty($newPassword) || empty($confirmPassword)) {
    echo json_encode(['success' => false, 'message' => __('error_all_fields')]);
    exit;
}

if ($newPassword !== $confirmPassword) {
    echo json_encode(['success' => false, 'message' => __('error_password_match')]);
    exit;
}

if (strlen($newPassword) < 6) {
    echo json_encode(['success' => false, 'message' => __('error_password_length')]);
    exit;
}

try {
    // چک رمز عبور فعلی
    $stmt = $pdo->prepare("SELECT password_hash FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user || !password_verify($oldPassword, $user['password_hash'])) {
        echo json_encode(['success' => false, 'message' => __('error_current_password')]);
        exit;
    }

    // آپدیت رمز عبور
    $newHash = password_hash($newPassword, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
    $stmt->execute([$newHash, $userId]);

    echo json_encode(['success' => true, 'message' => __('password_changed_success')]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => __('database_error') . ': ' . $e->getMessage()]);
}
