<?php
/**
 * API ثبت‌نام کاربر جدید
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

// اعتبارسنجی
if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'نام کاربری و رمز عبور الزامی هستند']);
    exit;
}

if (strlen($username) < 3 || strlen($username) > 50) {
    echo json_encode(['success' => false, 'message' => 'نام کاربری باید بین 3 تا 50 کاراکتر باشد']);
    exit;
}

if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'رمز عبور باید حداقل 6 کاراکتر باشد']);
    exit;
}

if (!preg_match('/^[a-zA-Z0-9_]+$/', $username)) {
    echo json_encode(['success' => false, 'message' => 'نام کاربری فقط می‌تواند شامل حروف انگلیسی، اعداد و _ باشد']);
    exit;
}

try {
    // چک کردن تکراری نبودن نام کاربری
    $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ?");
    $stmt->execute([$username]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'این نام کاربری قبلاً استفاده شده است']);
        exit;
    }
    
    // ثبت کاربر جدید
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, password_hash) VALUES (?, ?)");
    $stmt->execute([$username, $password_hash]);
    
    $user_id = $pdo->lastInsertId();
    
    echo json_encode([
        'success' => true,
        'user_id' => $user_id,
        'message' => 'ثبت‌نام با موفقیت انجام شد'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ثبت‌نام: ' . $e->getMessage()
    ]);
}
?>