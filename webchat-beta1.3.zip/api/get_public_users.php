<?php
/**
 * API دریافت کاربران عمومی
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

try {
    // دریافت کاربران عمومی (به جز خود کاربر و کاربران بلاک شده)
    $stmt = $pdo->prepare("
        SELECT 
            u.id, 
            u.username, 
            u.last_seen,
            CASE 
                WHEN u.last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE) THEN 1 
                ELSE 0 
            END as is_online
        FROM users u
        WHERE u.is_public = 1 
        AND u.id != ? 
        AND u.id NOT IN (
            SELECT blocked_id FROM user_blocks WHERE blocker_id = ?
        )
        AND u.id NOT IN (
            SELECT blocker_id FROM user_blocks WHERE blocked_id = ?
        )
        ORDER BY is_online DESC, u.username ASC 
        LIMIT 50
    ");
    
    $stmt->execute([$_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تبدیل is_online به boolean و حذف اطلاعات حساس
    foreach ($users as &$user) {
        $user['is_online'] = (bool)$user['is_online'];
        unset($user['last_seen']);
        unset($user['id']);
    }
    
    echo json_encode([
        'success' => true,
        'users' => $users,
        'count' => count($users)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت کاربران: ' . $e->getMessage()
    ]);
}
?>