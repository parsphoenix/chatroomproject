<?php
/**
 * API پاکسازی سیگنال‌های قدیمی WebRTC
 * این API قبل از شروع تماس جدید فراخوانی می‌شود
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$target_user_id = intval($_POST['target_user_id'] ?? 0);
$current_user_id = $_SESSION['user_id'];

try {
    // حذف سیگنال‌های قدیمی‌تر از 60 ثانیه (برای تمام کاربران)
    $stmt = $pdo->prepare("
        DELETE FROM webrtc_signals 
        WHERE created_at < DATE_SUB(NOW(), INTERVAL 60 SECOND)
    ");
    $stmt->execute();
    $deletedOld = $stmt->rowCount();
    
    // حذف سیگنال‌های خوانده شده قدیمی‌تر از 10 ثانیه
    $stmt = $pdo->prepare("
        DELETE FROM webrtc_signals 
        WHERE is_read = TRUE AND created_at < DATE_SUB(NOW(), INTERVAL 10 SECOND)
    ");
    $stmt->execute();
    $deletedRead = $stmt->rowCount();
    
    // اگر target_user_id مشخص شده، سیگنال‌های قبلی بین این دو کاربر رو هم پاک کن
    if ($target_user_id > 0) {
        $stmt = $pdo->prepare("
            DELETE FROM webrtc_signals 
            WHERE (
                (from_user_id = ? AND to_user_id = ?) 
                OR (from_user_id = ? AND to_user_id = ?)
            )
            AND is_read = TRUE
        ");
        $stmt->execute([$current_user_id, $target_user_id, $target_user_id, $current_user_id]);
        $deletedBetween = $stmt->rowCount();
    } else {
        $deletedBetween = 0;
    }
    
    echo json_encode([
        'success' => true,
        'deleted_old' => $deletedOld,
        'deleted_read' => $deletedRead,
        'deleted_between' => $deletedBetween,
        'message' => 'سیگنال‌های قدیمی پاکسازی شدند'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'message' => 'خطا در پاکسازی: ' . $e->getMessage()
    ]);
}
?>
