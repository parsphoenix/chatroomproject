<?php
/**
 * API ممنوع کردن کاربر توسط ادمین
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

// چک دسترسی ادمین
try {
    $stmt = $pdo->prepare("SELECT user_role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || $user['user_role'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در بررسی دسترسی']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$user_id = intval($_POST['user_id'] ?? 0);
$reason = trim($_POST['reason'] ?? '');

// اعتبارسنجی
if ($user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه کاربر نامعتبر']);
    exit;
}

if (empty($reason)) {
    echo json_encode(['success' => false, 'message' => 'دلیل ممنوعیت الزامی است']);
    exit;
}

if ($user_id == $_SESSION['user_id']) {
    echo json_encode(['success' => false, 'message' => 'نمی‌توانید خودتان را ممنوع کنید']);
    exit;
}

try {
    // چک کردن وجود کاربر و اینکه ادمین نباشد
    $stmt = $pdo->prepare("SELECT id, username, user_role FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $target_user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$target_user) {
        echo json_encode(['success' => false, 'message' => 'کاربر یافت نشد']);
        exit;
    }
    
    if ($target_user['user_role'] === 'admin') {
        echo json_encode(['success' => false, 'message' => 'نمی‌توانید ادمین دیگری را ممنوع کنید']);
        exit;
    }
    
    // چک کردن اینکه قبلاً ممنوع نشده باشد
    $stmt = $pdo->prepare("SELECT id FROM user_bans WHERE banned_user_id = ? AND is_active = TRUE");
    $stmt->execute([$user_id]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'این کاربر قبلاً ممنوع شده است']);
        exit;
    }
    
    // دریافت اطلاعات مرورگر و IP
    $browser_fingerprint = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $ip_address = $_SERVER['REMOTE_ADDR'] ?? '';
    
    // اگر از پروکسی استفاده می‌شود
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip_address = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (!empty($_SERVER['HTTP_X_REAL_IP'])) {
        $ip_address = $_SERVER['HTTP_X_REAL_IP'];
    }
    
    $pdo->beginTransaction();
    
    // ممنوع کردن کاربر
    $stmt = $pdo->prepare("
        INSERT INTO user_bans (banned_user_id, banned_by_admin_id, ban_reason, browser_fingerprint, ip_address) 
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([$user_id, $_SESSION['user_id'], $reason, $browser_fingerprint, $ip_address]);
    
    // ثبت لاگ
    $stmt = $pdo->prepare("
        INSERT INTO admin_logs (admin_id, action_type, target_user_id, action_details) 
        VALUES (?, 'ban_user', ?, ?)
    ");
    $stmt->execute([$_SESSION['user_id'], $user_id, $reason]);
    
    // قطع تمام session های کاربر
    $stmt = $pdo->prepare("UPDATE users SET last_seen = '1970-01-01 00:00:00' WHERE id = ?");
    $stmt->execute([$user_id]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'کاربر با موفقیت ممنوع شد',
        'banned_user' => $target_user['username']
    ]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ممنوع کردن کاربر: ' . $e->getMessage()
    ]);
}
?>