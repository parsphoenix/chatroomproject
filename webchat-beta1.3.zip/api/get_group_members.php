<?php
/**
 * API دریافت اعضای گروه
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$group_id = intval($_POST['group_id'] ?? 0);

// اعتبارسنجی
if ($group_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه گروه نامعتبر']);
    exit;
}

try {
    // چک کردن عضویت در گروه
    $stmt = $pdo->prepare("
        SELECT status FROM group_members 
        WHERE group_id = ? AND user_id = ? AND status = 'accepted'
    ");
    $stmt->execute([$group_id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما عضو این گروه نیستید']);
        exit;
    }
    
    // دریافت اعضای گروه
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            u.last_seen,
            CASE 
                WHEN u.last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE) THEN 1 
                ELSE 0 
            END as is_online,
            CASE 
                WHEN g.creator_id = u.id THEN 1 
                ELSE 0 
            END as is_creator,
            gm.joined_at
        FROM group_members gm
        INNER JOIN users u ON gm.user_id = u.id
        INNER JOIN groups_table g ON gm.group_id = g.id
        WHERE gm.group_id = ? AND gm.status = 'accepted'
        ORDER BY is_creator DESC, u.username ASC
    ");
    $stmt->execute([$group_id]);
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تبدیل boolean ها
    foreach ($members as &$member) {
        $member['is_online'] = (bool)$member['is_online'];
        $member['is_creator'] = (bool)$member['is_creator'];
        unset($member['last_seen']);
    }
    
    echo json_encode([
        'success' => true,
        'members' => $members,
        'count' => count($members)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت اعضا: ' . $e->getMessage()
    ]);
}
?>