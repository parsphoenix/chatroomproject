<?php
/**
 * API دریافت گروه‌های ساخته شده توسط کاربر
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

try {
    // دریافت گروه‌های ساخته شده توسط کاربر
    $stmt = $pdo->prepare("
        SELECT 
            g.id,
            g.name,
            g.description,
            g.created_at,
            COUNT(gm.user_id) as member_count
        FROM groups_table g
        LEFT JOIN group_members gm ON g.id = gm.group_id AND gm.status = 'accepted'
        WHERE g.creator_id = ?
        GROUP BY g.id
        ORDER BY g.created_at DESC
    ");
    $stmt->execute([$_SESSION['user_id']]);
    $groups = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'groups' => $groups,
        'count' => count($groups)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت گروه‌ها: ' . $e->getMessage()
    ]);
}
?>