<?php
/**
 * API حذف گروه
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$group_id = intval($_POST['group_id'] ?? 0);

// اعتبارسنجی
if ($group_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه گروه نامعتبر']);
    exit;
}

try {
    // چک کردن اینکه کاربر سازنده گروه است
    $stmt = $pdo->prepare("
        SELECT id, name, creator_id 
        FROM groups_table 
        WHERE id = ?
    ");
    $stmt->execute([$group_id]);
    $group = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$group) {
        echo json_encode(['success' => false, 'message' => 'گروه یافت نشد']);
        exit;
    }
    
    if ($group['creator_id'] != $_SESSION['user_id']) {
        echo json_encode(['success' => false, 'message' => 'فقط سازنده گروه می‌تواند آن را حذف کند']);
        exit;
    }
    
    $pdo->beginTransaction();
    
    // حذف فایل‌های گروه از دیسک
    $stmt = $pdo->prepare("SELECT file_path FROM group_files WHERE group_id = ?");
    $stmt->execute([$group_id]);
    $files = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    foreach ($files as $filePath) {
        if (file_exists('../' . $filePath)) {
            unlink('../' . $filePath);
        }
    }
    
    // حذف فایل‌های گروه از دیتابیس
    $stmt = $pdo->prepare("DELETE FROM group_files WHERE group_id = ?");
    $stmt->execute([$group_id]);
    
    // حذف پیام‌های گروه
    $stmt = $pdo->prepare("DELETE FROM group_messages WHERE group_id = ?");
    $stmt->execute([$group_id]);
    
    // حذف اعضای گروه
    $stmt = $pdo->prepare("DELETE FROM group_members WHERE group_id = ?");
    $stmt->execute([$group_id]);
    
    // حذف گروه
    $stmt = $pdo->prepare("DELETE FROM groups_table WHERE id = ?");
    $stmt->execute([$group_id]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'message' => 'گروه با موفقیت حذف شد',
        'group_name' => $group['name']
    ]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در حذف گروه: ' . $e->getMessage()
    ]);
}
?>