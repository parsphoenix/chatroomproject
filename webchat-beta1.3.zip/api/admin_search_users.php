<?php
/**
 * API جستجوی کاربران برای ادمین
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

// چک دسترسی ادمین
try {
    $stmt = $pdo->prepare("SELECT user_role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || $user['user_role'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در بررسی دسترسی']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$query = trim($_POST['query'] ?? '');

if (empty($query)) {
    echo json_encode(['success' => false, 'message' => 'کلمه جستجو الزامی است']);
    exit;
}

if (strlen($query) < 2) {
    echo json_encode(['success' => false, 'message' => 'حداقل 2 کاراکتر وارد کنید']);
    exit;
}

try {
    // جستجوی کاربران (غیر از ادمین‌ها)
    $stmt = $pdo->prepare("
        SELECT 
            u.id,
            u.username,
            u.last_seen,
            CASE 
                WHEN u.last_seen >= DATE_SUB(NOW(), INTERVAL 5 MINUTE) THEN 1 
                ELSE 0 
            END as is_online,
            CASE 
                WHEN ub.banned_user_id IS NOT NULL THEN 1 
                ELSE 0 
            END as is_banned
        FROM users u
        LEFT JOIN user_bans ub ON u.id = ub.banned_user_id AND ub.is_active = TRUE
        WHERE u.username LIKE ? 
        AND u.user_role = 'user'
        ORDER BY u.username ASC 
        LIMIT 20
    ");
    
    $searchTerm = '%' . $query . '%';
    $stmt->execute([$searchTerm]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // فرمت کردن تاریخ‌ها
    foreach ($users as &$user) {
        $user['last_seen_formatted'] = $user['last_seen'] ? 
            date('Y/m/d H:i', strtotime($user['last_seen'])) : 
            'هرگز';
        $user['is_online'] = (bool)$user['is_online'];
        $user['is_banned'] = (bool)$user['is_banned'];
    }
    
    // ثبت لاگ
    $stmt = $pdo->prepare("
        INSERT INTO admin_logs (admin_id, action_type, action_details) 
        VALUES (?, 'view_users', ?)
    ");
    $stmt->execute([$_SESSION['user_id'], "جستجو برای: $query"]);
    
    echo json_encode([
        'success' => true,
        'users' => $users,
        'count' => count($users)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در جستجو: ' . $e->getMessage()
    ]);
}
?>