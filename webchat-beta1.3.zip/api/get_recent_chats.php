<?php
/**
 * API دریافت چت‌های اخیر
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

try {
    $userId = $_SESSION['user_id'];
    
    // پارامترهای صفحه‌بندی
    $page = isset($_POST['page']) ? max(1, (int)$_POST['page']) : 1;
    $limit = 7;
    $offset = ($page - 1) * $limit;

    // دریافت تعداد کل برای صفحه‌بندی
    $countStmt = $pdo->prepare("
        SELECT COUNT(*) 
        FROM (
            SELECT 
                CASE 
                    WHEN sender_id = ? THEN receiver_id 
                    ELSE sender_id 
                END as chat_with_id
            FROM messages 
            WHERE sender_id = ? OR receiver_id = ?
            GROUP BY chat_with_id
        ) recent
        INNER JOIN users u ON u.id = recent.chat_with_id
        WHERE u.id NOT IN (SELECT blocked_id FROM user_blocks WHERE blocker_id = ?)
        AND u.id NOT IN (SELECT blocker_id FROM user_blocks WHERE blocked_id = ?)
    ");
    $countStmt->execute([$userId, $userId, $userId, $userId, $userId]);
    $totalChats = $countStmt->fetchColumn();
    $totalPages = ceil($totalChats / $limit);

    // دریافت چت‌های اخیر با صفحه‌بندی
    $stmt = $pdo->prepare("
        SELECT 
            u.username,
            u.id as user_id,
            CASE 
                WHEN u.last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE) THEN 1 
                ELSE 0 
            END as is_online,
            m.message as last_message,
            m.created_at as last_message_time,
            (
                SELECT COUNT(*) 
                FROM messages m2 
                WHERE m2.sender_id = u.id 
                AND m2.receiver_id = ? 
                AND m2.is_read = FALSE
            ) as unread_count
        FROM users u
        INNER JOIN (
            SELECT 
                CASE 
                    WHEN sender_id = ? THEN receiver_id 
                    ELSE sender_id 
                END as chat_with_id,
                MAX(created_at) as last_time
            FROM messages 
            WHERE sender_id = ? OR receiver_id = ?
            GROUP BY chat_with_id
        ) recent ON u.id = recent.chat_with_id
        LEFT JOIN messages m ON (
            (m.sender_id = u.id AND m.receiver_id = ?) OR 
            (m.sender_id = ? AND m.receiver_id = u.id)
        ) AND m.created_at = recent.last_time
        WHERE u.id NOT IN (
            SELECT blocked_id FROM user_blocks WHERE blocker_id = ?
        )
        AND u.id NOT IN (
            SELECT blocker_id FROM user_blocks WHERE blocked_id = ?
        )
        ORDER BY recent.last_time DESC
        LIMIT ? OFFSET ?
    ");
    
    $stmt->bindValue(1, $userId, PDO::PARAM_INT);
    $stmt->bindValue(2, $userId, PDO::PARAM_INT);
    $stmt->bindValue(3, $userId, PDO::PARAM_INT);
    $stmt->bindValue(4, $userId, PDO::PARAM_INT);
    $stmt->bindValue(5, $userId, PDO::PARAM_INT);
    $stmt->bindValue(6, $userId, PDO::PARAM_INT);
    $stmt->bindValue(7, $userId, PDO::PARAM_INT);
    $stmt->bindValue(8, $userId, PDO::PARAM_INT);
    $stmt->bindValue(9, $limit, PDO::PARAM_INT);
    $stmt->bindValue(10, $offset, PDO::PARAM_INT);
    
    $stmt->execute();
    $chats = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تبدیل is_online به boolean و فرمت کردن پیام
    foreach ($chats as &$chat) {
        $chat['is_online'] = (bool)$chat['is_online'];
        $chat['unread_count'] = (int)$chat['unread_count'];
        
        // کوتاه کردن پیام طولانی
        if ($chat['last_message'] && mb_strlen($chat['last_message']) > 50) {
            $chat['last_message'] = mb_substr($chat['last_message'], 0, 50) . '...';
        }
        
        // حذف اطلاعات اضافی
        unset($chat['user_id']);
        unset($chat['last_message_time']);
    }
    
    echo json_encode([
        'success' => true,
        'chats' => $chats,
        'count' => count($chats),
        'total_pages' => $totalPages,
        'current_page' => $page
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت چت‌ها: ' . $e->getMessage()
    ]);
}
?>