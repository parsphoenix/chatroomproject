<?php
/**
 * API دریافت پیام‌های گروهی
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$group_id = intval($_POST['group_id'] ?? 0);
$last_message_id = intval($_POST['last_message_id'] ?? 0);
$before_message_id = intval($_POST['before_message_id'] ?? 0);
$after_message_id = intval($_POST['after_message_id'] ?? 0);
$limit = intval($_POST['limit'] ?? 30);
if ($limit <= 0 || $limit > 100) {
    $limit = 30;
}

// اعتبارسنجی
if ($group_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'شناسه گروه نامعتبر']);
    exit;
}

try {
    // چک کردن عضویت در گروه
    $stmt = $pdo->prepare("
        SELECT status FROM group_members 
        WHERE group_id = ? AND user_id = ? AND status = 'accepted'
    ");
    $stmt->execute([$group_id, $_SESSION['user_id']]);
    
    if (!$stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما عضو این گروه نیستید']);
        exit;
    }
    
    // دریافت پیام‌های گروهی
    if ($before_message_id > 0) {
        $stmt = $pdo->prepare("
            SELECT 
                gm.id,
                gm.sender_id,
                gm.message,
                gm.created_at,
                u.username as sender_name
            FROM group_messages gm
            INNER JOIN users u ON gm.sender_id = u.id
            WHERE gm.group_id = ? AND gm.id < ?
            ORDER BY gm.created_at DESC, gm.id DESC
            LIMIT $limit
        ");
        $stmt->execute([$group_id, $before_message_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $messages = array_reverse($messages);
    } elseif ($after_message_id > 0) {
        $stmt = $pdo->prepare("
            SELECT 
                gm.id,
                gm.sender_id,
                gm.message,
                gm.created_at,
                u.username as sender_name
            FROM group_messages gm
            INNER JOIN users u ON gm.sender_id = u.id
            WHERE gm.group_id = ? AND gm.id > ?
            ORDER BY gm.created_at ASC, gm.id ASC
            LIMIT $limit
        ");
        $stmt->execute([$group_id, $after_message_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($last_message_id == 0) {
        $stmt = $pdo->prepare("
            SELECT 
                gm.id,
                gm.sender_id,
                gm.message,
                gm.created_at,
                u.username as sender_name
            FROM group_messages gm
            INNER JOIN users u ON gm.sender_id = u.id
            WHERE gm.group_id = ?
            ORDER BY gm.created_at DESC, gm.id DESC
            LIMIT $limit
        ");
        $stmt->execute([$group_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
        $messages = array_reverse($messages);
    } else {
        $stmt = $pdo->prepare("
            SELECT 
                gm.id,
                gm.sender_id,
                gm.message,
                gm.created_at,
                u.username as sender_name
            FROM group_messages gm
            INNER JOIN users u ON gm.sender_id = u.id
            WHERE gm.group_id = ? AND gm.id > ?
            ORDER BY gm.created_at ASC, gm.id ASC
        ");
        $stmt->execute([$group_id, $last_message_id]);
        $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // آپدیت آخرین فعالیت
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'messages' => $messages,
        'count' => count($messages)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت پیام‌ها: ' . $e->getMessage()
    ]);
}
?>
