<?php
/**
 * API ساخت گروه جدید
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$groupName = trim($_POST['groupName'] ?? '');
$groupDescription = trim($_POST['groupDescription'] ?? '');

// اعتبارسنجی
if (empty($groupName)) {
    echo json_encode(['success' => false, 'message' => 'نام گروه الزامی است']);
    exit;
}

if (strlen($groupName) < 3 || strlen($groupName) > 100) {
    echo json_encode(['success' => false, 'message' => 'نام گروه باید بین 3 تا 100 کاراکتر باشد']);
    exit;
}

if (strlen($groupDescription) > 500) {
    echo json_encode(['success' => false, 'message' => 'توضیحات نباید بیش از 500 کاراکتر باشد']);
    exit;
}

try {
    // چک کردن تعداد گروه‌های کاربر (حداکثر 2 گروه)
    $stmt = $pdo->prepare("SELECT COUNT(*) as group_count FROM groups_table WHERE creator_id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['group_count'] >= 2) {
        echo json_encode(['success' => false, 'message' => 'شما حداکثر می‌توانید 2 گروه بسازید']);
        exit;
    }
    
    // چک کردن تکراری نبودن نام گروه برای این کاربر
    $stmt = $pdo->prepare("SELECT id FROM groups_table WHERE name = ? AND creator_id = ?");
    $stmt->execute([$groupName, $_SESSION['user_id']]);
    
    if ($stmt->fetch()) {
        echo json_encode(['success' => false, 'message' => 'شما قبلاً گروهی با این نام ساخته‌اید']);
        exit;
    }
    
    $pdo->beginTransaction();
    
    // ساخت گروه جدید
    $stmt = $pdo->prepare("
        INSERT INTO groups_table (name, description, creator_id) 
        VALUES (?, ?, ?)
    ");
    $stmt->execute([$groupName, $groupDescription, $_SESSION['user_id']]);
    
    $groupId = $pdo->lastInsertId();
    
    // اضافه کردن سازنده به عنوان عضو گروه
    $stmt = $pdo->prepare("
        INSERT INTO group_members (group_id, user_id, status) 
        VALUES (?, ?, 'accepted')
    ");
    $stmt->execute([$groupId, $_SESSION['user_id']]);
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'group_id' => $groupId,
        'message' => 'گروه با موفقیت ساخته شد'
    ]);
    
} catch (PDOException $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ساخت گروه: ' . $e->getMessage()
    ]);
}
?>