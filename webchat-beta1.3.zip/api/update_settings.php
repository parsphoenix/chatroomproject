<?php
/**
 * API برای بروزرسانی تنظیمات عمومی کاربر
 */

require_once '../includes/lang_helper.php';
require_once '../config/db.php';

session_start();

header('Content-Type: application/json');

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => __('please_login')]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => __('invalid_request')]);
    exit;
}

$userId = $_SESSION['user_id'];
$type = $_POST['type'] ?? '';
$value = $_POST['value'] ?? '';

try {
    switch ($type) {
        case 'theme':
            $allowedThemes = ['light', 'dark'];
            if (in_array($value, $allowedThemes)) {
                $stmt = $pdo->prepare("UPDATE users SET theme_preference = ? WHERE id = ?");
                $stmt->execute([$value, $userId]);
                echo json_encode(['success' => true, 'message' => __('theme_updated')]);
            } else {
                echo json_encode(['success' => false, 'message' => __('invalid_value')]);
            }
            break;

        case 'language':
            $allowedLangs = ['fa', 'en'];
            if (in_array($value, $allowedLangs)) {
                $stmt = $pdo->prepare("UPDATE users SET language_preference = ? WHERE id = ?");
                $stmt->execute([$value, $userId]);
                echo json_encode(['success' => true, 'message' => __('language_updated')]);
            } else {
                echo json_encode(['success' => false, 'message' => __('invalid_value')]);
            }
            break;

        case 'privacy':
            $showOnline = $value === 'true' ? 1 : 0;
            $stmt = $pdo->prepare("UPDATE users SET show_online_status = ? WHERE id = ?");
            $stmt->execute([$showOnline, $userId]);
            echo json_encode(['success' => true, 'message' => __('privacy_updated')]);
            break;

        case 'notifications':
            $enableNotify = ($value === 'true' || $value === '1') ? 1 : 0;
            $stmt = $pdo->prepare("UPDATE users SET enable_notifications = ? WHERE id = ?");
            $stmt->execute([$enableNotify, $userId]);
            echo json_encode(['success' => true, 'message' => __('notifications_updated')]);
            break;

        case 'bitrate':
            $bitrate = intval($value);
            if ($bitrate < 100 || $bitrate > 5000) {
                 echo json_encode(['success' => false, 'message' => __('invalid_bitrate')]);
            } else {
                $stmt = $pdo->prepare("UPDATE users SET preferred_bitrate = ? WHERE id = ?");
                $stmt->execute([$bitrate, $userId]);
                echo json_encode(['success' => true, 'message' => __('bitrate_updated')]);
            }
            break;

        case 'account':
            $newUsername = trim($_POST['newUsername'] ?? '');
            $currentPassword = $_POST['currentPassword'] ?? '';

            if (empty($newUsername) || empty($currentPassword)) {
                echo json_encode(['success' => false, 'message' => __('error_all_fields')]);
                exit;
            }

            // چک پسورد فعلی
            $stmt = $pdo->prepare("SELECT password_hash, username FROM users WHERE id = ?");
            $stmt->execute([$userId]);
            $user = $stmt->fetch();

            if (!password_verify($currentPassword, $user['password_hash'])) {
                echo json_encode(['success' => false, 'message' => __('error_current_password')]);
                exit;
            }

            // اگر نام کاربری تغییر کرده، چک یونیک بودن
            if ($newUsername !== $user['username']) {
                $stmt = $pdo->prepare("SELECT id FROM users WHERE username = ? AND id != ?");
                $stmt->execute([$newUsername, $userId]);
                if ($stmt->fetch()) {
                    echo json_encode(['success' => false, 'message' => __('error_username_taken')]);
                    exit;
                }
            }

            $stmt = $pdo->prepare("UPDATE users SET username = ? WHERE id = ?");
            $stmt->execute([$newUsername, $userId]);
            echo json_encode(['success' => true, 'message' => __('account_updated_success')]);
            break;

        default:
            echo json_encode(['success' => false, 'message' => __('invalid_type')]);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => __('database_error') . ': ' . $e->getMessage()]);
}
