<?php
/**
 * API جستجوی کاربران
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$query = trim($_POST['query'] ?? '');

if (empty($query)) {
    echo json_encode(['success' => false, 'message' => 'کلمه جستجو الزامی است']);
    exit;
}

if (strlen($query) < 2) {
    echo json_encode(['success' => false, 'message' => 'حداقل 2 کاراکتر برای جستجو لازم است']);
    exit;
}

try {
    // جستجوی کاربران (به جز خود کاربر جاری و کاربران بلاک شده)
    $stmt = $pdo->prepare("
        SELECT 
            u.id, 
            u.username, 
            u.last_seen,
            CASE 
                WHEN u.last_seen >= DATE_SUB(NOW(), INTERVAL 2 MINUTE) THEN 1 
                ELSE 0 
            END as is_online
        FROM users u
        WHERE u.username LIKE ? 
        AND u.id != ? 
        AND u.id NOT IN (
            SELECT blocked_id FROM user_blocks WHERE blocker_id = ?
        )
        AND u.id NOT IN (
            SELECT blocker_id FROM user_blocks WHERE blocked_id = ?
        )
        ORDER BY is_online DESC, u.username ASC 
        LIMIT 20
    ");
    
    $searchTerm = '%' . $query . '%';
    $stmt->execute([$searchTerm, $_SESSION['user_id'], $_SESSION['user_id'], $_SESSION['user_id']]);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // تبدیل is_online به boolean
    foreach ($users as &$user) {
        $user['is_online'] = (bool)$user['is_online'];
        // حذف last_seen از خروجی برای امنیت
        unset($user['last_seen']);
        unset($user['id']);
    }
    
    echo json_encode([
        'success' => true,
        'users' => $users,
        'count' => count($users)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در جستجو: ' . $e->getMessage()
    ]);
}
?>