<?php
/**
 * API حذف پیام‌ها
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

// دریافت message_ids به صورت آرایه
$message_ids = [];
if (isset($_POST['message_ids'])) {
    if (is_array($_POST['message_ids'])) {
        $message_ids = $_POST['message_ids'];
    } else {
        // اگر به صورت رشته ارسال شده، تبدیل به آرایه
        $message_ids = explode(',', $_POST['message_ids']);
    }
}

$delete_type = $_POST['delete_type'] ?? 'for_me'; // 'for_me' یا 'for_both'
$target_user_id = intval($_POST['target_user_id'] ?? 0);

// اعتبارسنجی
if (empty($message_ids)) {
    echo json_encode(['success' => false, 'message' => 'پیامی انتخاب نشده است']);
    exit;
}

// فیلتر کردن message_ids خالی
$message_ids = array_filter($message_ids, function($id) {
    return !empty(trim($id));
});

if (empty($message_ids)) {
    echo json_encode(['success' => false, 'message' => 'شناسه پیام‌های معتبر یافت نشد']);
    exit;
}

if (!in_array($delete_type, ['for_me', 'for_both'])) {
    echo json_encode(['success' => false, 'message' => 'نوع حذف نامعتبر است']);
    exit;
}

// تبدیل به اعداد صحیح
$message_ids = array_map('intval', $message_ids);
$message_ids = array_filter($message_ids, function($id) { return $id > 0; });

if (empty($message_ids)) {
    echo json_encode(['success' => false, 'message' => 'شناسه پیام‌های نامعتبر']);
    exit;
}

try {
    $pdo->beginTransaction();
    
    if ($delete_type === 'for_both') {
        // حذف برای هر دو طرف - فقط پیام‌های ارسالی توسط کاربر جاری
        $placeholders = str_repeat('?,', count($message_ids) - 1) . '?';
        
        // ابتدا چک کنیم که تمام پیام‌ها متعلق به کاربر جاری هستند
        $stmt = $pdo->prepare("
            SELECT id FROM messages 
            WHERE id IN ($placeholders) AND sender_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id']]));
        $validMessages = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        if (count($validMessages) !== count($message_ids)) {
            throw new Exception('فقط می‌توانید پیام‌های خودتان را برای هر دو طرف حذف کنید');
        }
        
        // حذف فایل‌های مرتبط
        $stmt = $pdo->prepare("
            SELECT file_path FROM chat_files cf
            INNER JOIN messages m ON m.sender_id = cf.sender_id AND m.receiver_id = cf.receiver_id
            WHERE m.id IN ($placeholders) AND m.sender_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id']]));
        $files = $stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // حذف فایل‌ها از دیسک
        foreach ($files as $filePath) {
            if (file_exists('../' . $filePath)) {
                unlink('../' . $filePath);
            }
        }
        
        // حذف رکوردهای فایل
        $stmt = $pdo->prepare("
            DELETE cf FROM chat_files cf
            INNER JOIN messages m ON m.sender_id = cf.sender_id AND m.receiver_id = cf.receiver_id
            WHERE m.id IN ($placeholders) AND m.sender_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id']]));
        
        // حذف پیام‌ها
        $stmt = $pdo->prepare("
            DELETE FROM messages 
            WHERE id IN ($placeholders) AND sender_id = ?
        ");
        $stmt->execute(array_merge($message_ids, [$_SESSION['user_id']]));
        
    } else {
        // حذف فقط برای کاربر جاری - اضافه کردن فیلد deleted_for
        // ابتدا باید ساختار جدول را تغییر دهیم
        
        // برای سادگی، فعلاً پیام‌ها را به "پیام حذف شده" تبدیل می‌کنیم
        $placeholders = str_repeat('?,', count($message_ids) - 1) . '?';
        
        $stmt = $pdo->prepare("
            UPDATE messages 
            SET message = CASE 
                WHEN sender_id = ? THEN 'شما این پیام را حذف کردید'
                ELSE 'این پیام حذف شده است'
            END
            WHERE id IN ($placeholders) 
            AND (sender_id = ? OR receiver_id = ?)
        ");
        $stmt->execute(array_merge(
            [$_SESSION['user_id']], 
            $message_ids, 
            [$_SESSION['user_id'], $_SESSION['user_id']]
        ));
    }
    
    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'deleted_count' => count($message_ids),
        'message' => 'پیام‌ها با موفقیت حذف شدند'
    ]);
    
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در حذف پیام‌ها: ' . $e->getMessage()
    ]);
}
?>