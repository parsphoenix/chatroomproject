<?php
/**
 * API برای آپلود تصویر پروفایل
 */

require_once '../includes/lang_helper.php';
require_once '../config/db.php';

session_start();

header('Content-Type: application/json');

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => __('please_login')]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_FILES['profile_pic'])) {
    echo json_encode(['success' => false, 'message' => __('invalid_request')]);
    exit;
}

$file = $_FILES['profile_pic'];
$userId = $_SESSION['user_id'];

// چک خطا در آپلود
if ($file['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => __('upload_error')]);
    exit;
}

// چک حجم فایل (حداکثر 3 مگابایت)
$maxSize = 3 * 1024 * 1024; // 3MB
if ($file['size'] > $maxSize) {
    echo json_encode(['success' => false, 'message' => __('file_too_large_3mb')]);
    exit;
}

// چک نوع فایل
$allowedTypes = ['image/jpeg', 'image/png', 'image/webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mimeType, $allowedTypes)) {
    echo json_encode(['success' => false, 'message' => __('invalid_image_type')]);
    exit;
}

// ایجاد پوشه آپلود اگر وجود ندارد
$uploadDir = '../uploads/profile_pics/';
if (!is_dir($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// تولید نام فایل منحصر به فرد
$extension = pathinfo($file['name'], PATHINFO_EXTENSION);
if (empty($extension)) {
    $extension = $mimeType === 'image/jpeg' ? 'jpg' : ($mimeType === 'image/png' ? 'png' : 'webp');
}
$fileName = 'profile_' . $userId . '_' . time() . '.' . $extension;
$uploadPath = $uploadDir . $fileName;

try {
    // دریافت تصویر قبلی برای حذف
    $stmt = $pdo->prepare("SELECT profile_picture FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $oldPic = $stmt->fetchColumn();

    // جابجایی فایل
    if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
        // آپدیت دیتابیس
        $stmt = $pdo->prepare("UPDATE users SET profile_picture = ? WHERE id = ?");
        $stmt->execute([$fileName, $userId]);

        // حذف تصویر قبلی اگر وجود داشت
        if ($oldPic && file_exists($uploadDir . $oldPic)) {
            @unlink($uploadDir . $oldPic);
        }

        echo json_encode([
            'success' => true,
            'message' => __('profile_updated_success'),
            'profile_picture' => $fileName
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => __('upload_failed')]);
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => __('database_error') . ': ' . $e->getMessage()]);
}
