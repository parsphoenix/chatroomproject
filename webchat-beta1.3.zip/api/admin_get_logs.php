<?php
/**
 * API دریافت لاگ فعالیت‌های ادمین
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

// چک دسترسی ادمین
try {
    $stmt = $pdo->prepare("SELECT user_role FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user || $user['user_role'] !== 'admin') {
        echo json_encode(['success' => false, 'message' => 'دسترسی غیرمجاز']);
        exit;
    }
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'message' => 'خطا در بررسی دسترسی']);
    exit;
}

try {
    // دریافت لاگ‌های فعالیت
    $stmt = $pdo->prepare("
        SELECT 
            al.id,
            al.action_type,
            al.action_details,
            al.created_at,
            admin.username as admin_username,
            target.username as target_username
        FROM admin_logs al
        INNER JOIN users admin ON al.admin_id = admin.id
        LEFT JOIN users target ON al.target_user_id = target.id
        ORDER BY al.created_at DESC
        LIMIT 100
    ");
    
    $stmt->execute();
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // فرمت کردن تاریخ‌ها
    foreach ($logs as &$log) {
        $log['created_at_formatted'] = date('Y/m/d H:i:s', strtotime($log['created_at']));
    }
    
    echo json_encode([
        'success' => true,
        'logs' => $logs,
        'count' => count($logs)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت لاگ‌ها: ' . $e->getMessage()
    ]);
}
?>