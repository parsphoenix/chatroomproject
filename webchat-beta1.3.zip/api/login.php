<?php
/**
 * API ورود کاربر
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

// تنظیمات نشست برای ماندگاری (Remember Me)
$lifetime = 0; // پیش‌فرض: تا بسته شدن مرورگر
if (isset($_POST['remember_me']) && $_POST['remember_me'] === 'true') {
    $lifetime = 30 * 24 * 60 * 60; // 30 روز
}
session_set_cookie_params($lifetime);
session_start();
require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$username = trim($_POST['username'] ?? '');
$password = $_POST['password'] ?? '';

// اعتبارسنجی
if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'نام کاربری و رمز عبور الزامی هستند']);
    exit;
}

try {
    // جستجوی کاربر
    $stmt = $pdo->prepare("SELECT id, username, password_hash FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($user && password_verify($password, $user['password_hash'])) {
        // ورود موفق
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        
        // آپدیت آخرین فعالیت
        $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
        $stmt->execute([$user['id']]);
        
        echo json_encode([
            'success' => true,
            'user_id' => $user['id'],
            'username' => $user['username'],
            'message' => 'ورود موفق'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'نام کاربری یا رمز عبور اشتباه است']);
    }
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ورود: ' . $e->getMessage()
    ]);
}
?>