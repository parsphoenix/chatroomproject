<?php
/**
 * API ثبت لاگ تماس
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$target_user_id = intval($_POST['target_user_id'] ?? 0);
$call_type = $_POST['call_type'] ?? 'audio'; // audio, video
$duration = intval($_POST['duration'] ?? 0);
$status = $_POST['status'] ?? 'completed'; // completed, missed, rejected, no_answer

// اعتبارسنجی
if ($target_user_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'کاربر مقصد نامعتبر']);
    exit;
}

try {
    // ساخت پیام متناسب با نوع تماس
    $messageText = '';
    if ($status === 'missed') {
        $messageText = ($call_type === 'video') ? '📞 تماس تصویری از دست رفته' : '📞 تماس صوتی از دست رفته';
    } else if ($status === 'rejected') {
        $messageText = ($call_type === 'video') ? '📞 تماس تصویری رد شد' : '📞 تماس صوتی رد شد';
    } else if ($status === 'no_answer') {
        $messageText = ($call_type === 'video') ? '📞 تماس تصویری بی‌پاسخ' : '📞 تماس صوتی بی‌پاسخ';
    } else {
        $minutes = floor($duration / 60);
        $seconds = $duration % 60;
        $durationText = sprintf("%02d:%02d", $minutes, $seconds);
        $typeText = ($call_type === 'video') ? 'تصویری' : 'صوتی';
        $messageText = "📞 پایان تماس $typeText ($durationText)";
    }

    $metadata = json_encode([
        'call_type' => $call_type,
        'duration' => $duration,
        'status' => $status, 
        'timestamp' => time()
    ]);

    // ثبت در دیتابیس به عنوان پیام
    $stmt = $pdo->prepare("
        INSERT INTO messages (sender_id, receiver_id, message, type, metadata, created_at, status) 
        VALUES (?, ?, ?, 'call_log', ?, NOW(), 'read')
    ");
    // برای تماس از دست رفته، sender کسی است که زنگ زده (کاربر فعلی اگر ما زنگ زدیم)
    // اما اگر تماس از دست رفته باشد، یعنی طرف مقابل جواب نداده.
    // اگر ما (Caller) لاگ می‌کنیم: "تماس بی‌پاسخ با X".
    // اگر Receiver لاگ می‌کند: "تماس از دست رفته از Y".

    // منطق سمت کلاینت:
    // Caller sends log for 'no_answer' or 'rejected'.
    // Both send log for 'completed'? Or just one?
    // Usually system logs it. Since we don't have a signaling server logic persistency, the client must trigger it.
    // Ideally only one side triggers it effectively.
    // Let's assume the Caller triggers the log for 'no_answer' and 'completed'.
    // If 'missed' (receiver missed it), caller logs 'no_answer'. Receiver might not know unless they were online.
    
    // For simplicity: The client (Caller) logs the call result.
    $stmt->execute([$_SESSION['user_id'], $target_user_id, $messageText, $metadata]);
    
    echo json_encode([
        'success' => true,
        'message_id' => $pdo->lastInsertId(),
        'message' => 'لاگ تماس ثبت شد'
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در ثبت لاگ: ' . $e->getMessage()
    ]);
}
?>
