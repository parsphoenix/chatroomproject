<?php
/**
 * API دریافت WebRTC signals
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'متد نامعتبر']);
    exit;
}

$from_user_id = intval($_POST['from_user_id'] ?? -1);
$signal_type_prefix = trim($_POST['signal_type_prefix'] ?? '');

// اعتبارسنجی
if ($from_user_id < 0) {
    echo json_encode(['success' => false, 'message' => 'کاربر فرستنده نامعتبر']);
    exit;
}

if ($from_user_id == $_SESSION['user_id'] && $from_user_id != 0) {
    echo json_encode(['success' => false, 'message' => 'نمی‌توانید سیگنال خودتان را دریافت کنید']);
    exit;
}

try {
    // پاکسازی خودکار سیگنال‌های خیلی قدیمی (بیش از 2 دقیقه)
    $pdo->exec("DELETE FROM webrtc_signals WHERE created_at < DATE_SUB(NOW(), INTERVAL 120 SECOND)");

    // دریافت سیگنال‌های خوانده نشده
    $sql = "SELECT id, from_user_id, signal_type, signal_data, created_at
            FROM webrtc_signals 
            WHERE to_user_id = ? AND is_read = FALSE";
    $params = [$_SESSION['user_id']];

    if ($from_user_id > 0) {
        $sql .= " AND from_user_id = ?";
        $params[] = $from_user_id;
    }

    if ($signal_type_prefix !== '') {
        $sql .= " AND signal_type LIKE ?";
        $params[] = $signal_type_prefix . '%';
    }

    $sql .= " ORDER BY created_at ASC, id ASC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $signals = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // اضافه کردن نام فرستنده به سیگنال‌ها برای نمایش در اعلان
    if (!empty($signals)) {
        foreach ($signals as &$signal) {
            $stmtUser = $pdo->prepare("SELECT username FROM users WHERE id = ?");
            $stmtUser->execute([$signal['from_user_id']]);
            $sender = $stmtUser->fetch();
            $signal['from_username'] = $sender ? $sender['username'] : 'کاربر ناشناس';
        }
    }
    
    // علامت‌گذاری سیگنال‌ها به عنوان خوانده شده
    if (!empty($signals)) {
        $signalIds = array_column($signals, 'id');
        $placeholders = str_repeat('?,', count($signalIds) - 1) . '?';
        
        $stmt = $pdo->prepare("
            UPDATE webrtc_signals 
            SET is_read = TRUE 
            WHERE id IN ($placeholders)
        ");
        $stmt->execute($signalIds);
    }
    
    // آپدیت آخرین فعالیت
    $stmt = $pdo->prepare("UPDATE users SET last_seen = NOW() WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    
    echo json_encode([
        'success' => true,
        'signals' => $signals,
        'count' => count($signals)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت سیگنال‌ها: ' . $e->getMessage()
    ]);
}
?>
