<?php
/**
 * API دریافت تنظیمات کاربر
 */

header('Content-Type: application/json; charset=utf-8');

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    echo json_encode(['success' => false, 'message' => 'سیستم نصب نشده است']);
    exit;
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['success' => false, 'message' => 'لطفاً وارد شوید']);
    exit;
}

require_once '../config/db.php';

try {
    // دریافت تنظیمات کاربر
    $stmt = $pdo->prepare("SELECT is_public, enable_notifications, preferred_bitrate FROM users WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$user) {
        echo json_encode(['success' => false, 'message' => 'کاربر یافت نشد']);
        exit;
    }
    
    echo json_encode([
        'success' => true,
        'is_public' => (bool)$user['is_public'],
        'enable_notifications' => (bool)$user['enable_notifications'],
        'preferred_bitrate' => (int)($user['preferred_bitrate'] ?? 500)
    ]);
    
} catch (PDOException $e) {
    echo json_encode([
        'success' => false, 
        'message' => 'خطا در دریافت تنظیمات: ' . $e->getMessage()
    ]);
}
?>