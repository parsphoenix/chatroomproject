<?php
/**
 * API دانلود فایل
 */

// چک نصب
if (!file_exists('../installed.lock') || !file_exists('../config/db.php')) {
    die('سیستم نصب نشده است');
}

session_start();

// چک لاگین
if (!isset($_SESSION['user_id'])) {
    die('لطفاً وارد شوید');
}

require_once '../config/db.php';

$message_id = intval($_GET['id'] ?? 0);

if ($message_id <= 0) {
    die('شناسه پیام نامعتبر');
}

try {
    // پیدا کردن فایل مرتبط با پیام
    $stmt = $pdo->prepare("
        SELECT cf.* 
        FROM chat_files cf
        INNER JOIN messages m ON (
            (m.sender_id = cf.sender_id AND m.receiver_id = cf.receiver_id) OR
            (m.sender_id = cf.receiver_id AND m.receiver_id = cf.sender_id)
        )
        WHERE m.id = ? 
        AND (cf.sender_id = ? OR cf.receiver_id = ?)
        AND m.message LIKE CONCAT('%', cf.original_name, '%')
        LIMIT 1
    ");
    $stmt->execute([$message_id, $_SESSION['user_id'], $_SESSION['user_id']]);
    $file = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$file) {
        die('فایل یافت نشد یا دسترسی ندارید');
    }
    
    $filePath = '../' . $file['file_path'];
    
    if (!file_exists($filePath)) {
        die('فایل در سرور موجود نیست');
    }
    
    // تنظیم header های دانلود
    header('Content-Type: ' . $file['file_type']);
    header('Content-Disposition: attachment; filename="' . $file['original_name'] . '"');
    header('Content-Length: ' . filesize($filePath));
    header('Cache-Control: no-cache, must-revalidate');
    header('Expires: 0');
    
    // خواندن و ارسال فایل
    readfile($filePath);
    
} catch (PDOException $e) {
    die('خطا در دسترسی به فایل: ' . $e->getMessage());
}
?>